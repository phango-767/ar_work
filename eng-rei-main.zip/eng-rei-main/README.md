## REI Data Pipeline Repository

This repository is dedicated to managing the data pipeline for REI, focusing on loading, transforming, and curating data effectively. It's structured to align with the Medallion Architecture, encompassing layers for Raw, Trusted, and Curated data, ensuring a streamlined and efficient data processing workflow.

Repository Structure
The repository is organized into distinct layers, each representing a stage in the data pipeline:

**Raw: This layer includes scripts for initial data loading. It's the entry point for raw data coming into the pipeline.**

**Trusted: Here, data is cleaned, processed, and transformed. This stage ensures data quality and prepares it for further analytics.**

**Curated: The final layer where data is fully prepared, modeled, and made ready for business intelligence tools and data analytics.**

## Getting Started
### Prerequisites
- Python 3.8 or later
- Access to Databricks workspace
- Necessary permissions to access data sources

### Installation
1. Clone the repository to your local machine or Databricks workspace.
2. Navigate to each layer's directory and install the required dependencies using the requirements.txt file:
`pip install -r requirements.txt` (dependencies versions: %pip install botocore==1.34.70 aiobotocore==2.13.3 boto3==1.24.0 s3fs==2021.8.1)
3. Configure your environment with the necessary credentials and settings in config.py.

### Running the Pipeline
- Locally: Run the main.py script in your local environment. Ensure all dependencies and environment variables are set correctly. This includes access to the Databricks cluster - *a guide on this is WIP!*

- On Databricks: [clone the repo](https://docs.databricks.com/en/repos/git-operations-with-repos.html#clone-a-repo-connected-to-a-remote-repo) in databricks, and you are good to go to the main.py on a cluster.

## Development Workflow
- [Clone the repository to databricks](https://docs.databricks.com/en/repos/git-operations-with-repos.html#clone-a-repo-connected-to-a-remote-repo) or to your local and create a feature branch for your changes.
- Make changes, commit them, and push to your branch.
- Create a pull request against the main branch for review.