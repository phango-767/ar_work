## Reinsw Trusted

This project focuses on processing and analyzing data for the Real Estate Institute of New South Wales (Reinsw), an influential organization in the Australian real estate sector. The objective is to enhance and automate the data processing workflows, ensuring the delivery of refined and valuable data insights for the real estate market in New South Wales.

## Folder Structure
- `main.py:` The central script that orchestrates the entire data processing flow.
- data_processing/:
  - `data_cleaning.py:` Implements data cleaning techniques to ensure data quality and accuracy.
  - `data_transformation.py:` Transforms data into a suitable format for analysis, including normalization and restructuring.
  - `data_integration.py:` Integrates and consolidates data from multiple sources, preparing it for advanced processing.
- classification/: 
  - `contextual_classification.py:` Classifies data based on contextual information, enhancing its interpretability and usefulness.


<pre>
Reinsw/
├── __init__.py                        # Initializes the main package
├── main.py                            # Main script to run the data processing pipeline
├── data_processing/                   # Package for data processing modules
│   ├── __init__.py                    # Initializes the data_processing package
│   ├── data_cleaning.py               # Module for data cleaning functions
│   ├── data_transformation.py         # Module for data transformation functions
│   └── data_integration.py            # Module for integrating and consolidating data
└── classification/                    # Package for classification-related modules
    ├── __init__.py                    # Initializes the classification package
    └── contextual_classification.py   # Module for contextual data classification functions
</pre>

## Setting Up
#### Prerequisites
- Python version 3.8 or higher.
- Apache Spark for distributed data processing.
- boto3 library for AWS S3 interaction.

#### Installation
1. Clone the repository to your local machine or Databricks workspace.
2. Install the required Python packages:
`pip install -r requirements.txt`
3. Configure necessary parameters such as AWS credentials, file paths, and Spark settings.

## Running the Pipeline
- Navigate to the src directory.
- Execute python main.py.
The main.py script will sequentially invoke other scripts, handling data from loading to transformation and enrichment.
