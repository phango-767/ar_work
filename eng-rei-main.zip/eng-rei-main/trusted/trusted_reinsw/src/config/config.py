# AWS Configuration
AWS_BUCKET_NAME = 'arealytics-data-lake-raw'
S3_FOLDER_PREFIX = 'source=rei/dataflow=reinsw/'

# Spark Configuration
SPARK_APP_NAME = "DataProcessing"

# Schema Fields
SCHEMA_FIELDS = [
    "form_id", "created", "updated", "term_start_date_month", "term_start_date_day", "term_start_date_year",
    "term_end_date_month", "term_end_date_day", "term_end_date_year", "rent_commencement_date", "rent_commencement_date_2",
    "rent_commencement_date_3", "parties_tenant_name_address_abn", "tenant_company_name", "tenant_namefull",
    "premises_addressfull", "premises_title", "rent_amount", "bond_amount", "rent_frequency",
    "outgoings_percentage_increases", "outgoings_percentage_to_be_paid", "outgoings_special_conditions",
    "Outgoings_Checkbox", "rent_review_cpi_cb", "rent_review_fixed_percentage_cb", "rent_review_market_cb",
    "rent_review_fixed_percentage_commencement_anniversary_cb", "rent_review_fixed_percentage_other_cb",
    "rent_review_fixed_amount_cb", "rent_review_market_commencement_anniversary_cb", "rent_review_cpi_commencement_anniversary_cb",
    "Parties_Landlord_Name_Address_ABN", "Principal_Director_NameFull_Signature",
    "Principal2_Director_NameFull_Signature", "Principal_NameFull_Signature", "Principal2_NameFull_Signature",
    "Tenant_Director_NameFull_Signature", "Tenant2_Director_NameFull_Signature", "Tenant_NameFull_Signature",
    "Tenant2_NameFull_Signature", "option_term_renewal","permitted_use","postcode","Term_Duration","Rent_Review_Fixed_Percentage"
]
