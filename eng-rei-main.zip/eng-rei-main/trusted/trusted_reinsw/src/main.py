import boto3
import logging
import sys
import traceback
from pyspark.sql import SparkSession
import importlib
import pandas as pd
import config

importlib.reload(config)

from data_processing.data_cleaning import standardize_date_component, convert_unix_timestamps, clean_tenant_name
from data_processing.data_transformation import add_unique_id, normalize_column_names
from data_processing.data_integration import process_files_and_categorize_fields, create_spark_view, list_json_files, create_delta_table
from data_processing.data_loading import load_and_process_files
from utils.contextual_classification import space_use_classification
from config import config

def setup_spark_session():
    """Set up Spark session."""
    spark_app_name = config.SPARK_APP_NAME
    return SparkSession.builder.appName(spark_app_name).getOrCreate()

def apply_classifications(main_df):
    """Apply classifications to DataFrame."""
    if 'permitted_use' in main_df.columns:
        print("Applying classification to 'permitted_use' column")
        classifications = main_df['permitted_use'].apply(space_use_classification)
        main_df = pd.concat([main_df, classifications.rename('permitted_use_classification')], axis=1)
    else:
        print("'permitted_use' column not found in main_df.")
    return main_df


def apply_data_cleaning_and_transformation(main_df):
    """Apply data cleaning and transformation to DataFrame."""

    timestamp_columns = ['created', 'updated']
    if any(col in main_df.columns for col in timestamp_columns):
        main_df = convert_unix_timestamps(main_df, *timestamp_columns)
    else:
        print(f"Some or all timestamp columns {timestamp_columns} not found in main_df.")

    date_columns = [
        ('term_start_date_month', 'term_start_date_day', 'term_start_date_year'),
        ('term_end_date_month', 'term_end_date_day', 'term_end_date_year'),
        ('rent_commencement_date_2','rent_commencement_date', 'rent_commencement_date_3')
    ]

    for month_col, day_col, year_col in date_columns:
        if {month_col, day_col, year_col}.issubset(set(main_df.columns)):
            main_df = standardize_date_component(main_df, month_col, day_col, year_col)
        else:
            missing = {month_col, day_col, year_col} - set(main_df.columns)
            print(f"Missing columns for standardization in group {month_col, day_col, year_col}: {missing}")

            available_cols = [col for col in [month_col, day_col, year_col] if col in main_df.columns]
            if available_cols:
                filled_cols = tuple((col if col in main_df.columns else None for col in [month_col, day_col, year_col]))
                main_df = standardize_date_component(main_df, *filled_cols)

    tenant_name_columns = ['parties_tenant_name_address_abn', 'tenant_company_name', 'tenant_namefull']
    for col in tenant_name_columns:
        if col in main_df.columns:
            main_df[col] = main_df[col].apply(clean_tenant_name)
        else:
            print(f"Column '{col}' not found in main_df.")

    return main_df

### 
# Main Function
###
def main():
    try:
        spark = setup_spark_session()
        df = load_and_process_files(spark, config.AWS_BUCKET_NAME, config.S3_FOLDER_PREFIX, config.SCHEMA_FIELDS)
        df = apply_classifications(df)
        df = apply_data_cleaning_and_transformation(df)efull']])
        create_delta_table(df, spark, "`arealytics-databricks_unity_catalog`.arealyticstrusted.reinsw_leasesnapshot")

        print("Data processing completed successfully")
    except Exception as e:
        print(f"An error occurred: {e}")
        raise

if __name__ == "__main__":
    main()
