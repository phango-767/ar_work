from pyspark.sql import SparkSession
from pyspark.sql.functions import col

def load_and_process_files(spark, aws_bucket_name, s3_folder_prefix, schema_fields):
    """
    Load multiple CSV files from an S3 bucket into a Spark DataFrame using the specified schema and file path,
    select the required fields dynamically, and convert to a pandas DataFrame.

    Args:
        spark (SparkSession): Spark session
        aws_bucket_name (str): Name of the S3 bucket
        s3_folder_prefix (str): Prefix path where the files are stored
        schema_fields (list): List of field names to select from the DataFrames

    Returns:
        pandas DataFrame containing the loaded and combined data from all CSV files
    """
    base_path = f"s3a://{aws_bucket_name}/{s3_folder_prefix}"
    files = list_files(aws_bucket_name, s3_folder_prefix)
    all_dfs = []

    print(f"Listing files from {base_path}")
    for file_name in files:
        file_path = f"s3a://{aws_bucket_name}/{file_name}"  # Fix path concatenation issue
        print(f"Loading data from {file_path}")
        df = spark.read.csv(file_path, header=True, inferSchema=True)
        
        # Dynamically select columns based on passed schema_fields
        selected_df = df.select([col(field) for field in schema_fields])
        
        all_dfs.append(selected_df)
        print(f"Data loaded with shape: {selected_df.count()} rows, {len(selected_df.columns)} columns")

    # Union all DataFrames to combine them into a single DataFrame
    final_df = all_dfs[0]
    for df in all_dfs[1:]:
        final_df = final_df.unionByName(df)

    # Convert to pandas DataFrame and print the final shape
    pandas_df = final_df.toPandas()
    print(f"Data combined and loaded into pandas DataFrame with shape: {pandas_df.shape}")
    return pandas_df

def list_files(bucket_name, prefix):
    """
    List all files in an S3 bucket folder using boto3.
    """
    import boto3
    s3 = boto3.client('s3')
    response = s3.list_objects_v2(Bucket=bucket_name, Prefix=prefix)
    return [item['Key'] for item in response.get('Contents', []) if item['Key'].endswith('.csv')]

# Example usage:
# spark = SparkSession.builder.appName("DataProcessing").getOrCreate()
# schema_fields = ['form_id','created', 'updated',]
# df = load_and_process_files(spark, 'arealytics-data-lake-raw', 'source=rei/dataflow=reinsw/', schema_fields)
# print(df)
