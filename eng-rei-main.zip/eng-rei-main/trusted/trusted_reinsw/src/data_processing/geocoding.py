import googlemaps
import pandas as pd
from tqdm import tqdm
from datetime import datetime
from typing import Any

def Perform_geocoding(transformed_df):
    # Initialize Google Maps Client
    GMAPS = googlemaps.Client(key="xxxx")

    transformed_df.columns = [col.lower() for col in transformed_df.columns]

    # Helper function for timestamped logging
    def timestamped_string(input_string: str = "") -> str:
        return datetime.now().strftime("%H:%M:%S.%f")[:-3] + " -- " + input_string

    def print_log(input: Any) -> None:
        try:
            print(timestamped_string() + f"{input}")
        except Exception as e:
            print(timestamped_string("print_log exception: ") + f"{e}")

    # Function to create final address for geocoding
    def create_final_address(row):
        unit = str(row['unitnumber']) if 'unitnumber' in row and pd.notna(row['unitnumber']) else ''
        street = str(row['streetnumber']) if 'streetnumber' in row and pd.notna(row['streetnumber']) else ''
        street_address = str(row['premises_addressfull']) if 'premises_addressfull' in row and pd.notna(row['premises_addressfull']) else ''
        property_address = str(row['premises_addressfull']) if 'premises_addressfull' in row and pd.notna(row['premises_addressfull']) else ''

        final_address = ""
        effective_address = street_address if street_address and street_address != 'nan' else property_address
        if unit and unit != 'nan':
            final_address += f"{unit}/ "
        if street and street != 'nan':
            final_address += f"{street} "
        final_address += effective_address if effective_address and effective_address != 'nan' else ""
        return final_address.strip()

    # Apply the function to create final addresses
    transformed_df['final_address'] = transformed_df.apply(create_final_address, axis=1)

    # Function for geocoding addresses
    def google_geocoder(input_series: pd.Series) -> pd.DataFrame:
        input_series = input_series.dropna()
        geocode_input = input_series.to_dict()

        data = {'id': [], 'formatted_address': [], 'unit': [], 'street_number': [], 'street_name': [], 'suburb': [], 'postal_code': [], 'latitude': [], 'longitude': []}
        with tqdm(total=len(geocode_input), desc="Geocoding", unit="addr", leave=False) as pbar:
            for index, address in geocode_input.items():
                try:
                    if address:
                        geocoded_address = GMAPS.geocode(address)
                        if geocoded_address:
                            address_components = geocoded_address[0]['address_components']
                            unit = next((item['short_name'] for item in address_components if 'subpremise' in item['types']), None)
                            street_number = next((item['short_name'] for item in address_components if 'street_number' in item['types']), None)
                            street_name = next((item['short_name'] for item in address_components if 'route' in item['types']), None)
                            suburb = next((item['short_name'] for item in address_components if 'locality' in item['types']), None)
                            postal_code = next((item['short_name'] for item in address_components if 'postal_code' in item['types']), None)
                            latitude = geocoded_address[0]['geometry']['location']['lat']
                            longitude = geocoded_address[0]['geometry']['location']['lng']
                            formatted_address = geocoded_address[0]['formatted_address']

                            data['id'].append(index)
                            data['formatted_address'].append(formatted_address)
                            data['unit'].append(unit)
                            data['street_number'].append(street_number)
                            data['street_name'].append(street_name)
                            data['suburb'].append(suburb)
                            data['postal_code'].append(postal_code)
                            data['latitude'].append(latitude)
                            data['longitude'].append(longitude)
                        else:
                            print_log(f"No result for address: {address}")
                    else:
                        print_log(f"Skipping geocoding for empty address at index {index}")
                    pbar.update(1)
                except Exception as e:
                    print_log(f"Error in geocoding address {address}: {e}")
                    pbar.update(1)

        return pd.DataFrame(data)

    # Perform geocoding
    geocoded_df = google_geocoder(transformed_df.set_index('id')["final_address"])

    # Debugging output
    # print("Sample geocoded results:", geocoded_df.head(10))

    return geocoded_df
    # # Debug: Check if geocoded results are as expected
    # print("Sample geocoded results:", geocoded_df.head(10))

    # return geocoded_df

data = spark.sql("Select form_id as id, premises_addressfull from `arealytics-databricks_unity_catalog`.arealyticstrusted.reinsw_leasesnapshot where premises_addressfull is not null")
data = data.toPandas()
geocoded_data = Perform_geocoding(data)
spark_df = spark.createDataFrame(geocoded_data)
spark_df.write.format("delta").mode("overwrite").option("mergeSchema", "true").saveAsTable("`arealytics-databricks_unity_catalog`.arealyticstrusted.reinsw_geocoded_data")