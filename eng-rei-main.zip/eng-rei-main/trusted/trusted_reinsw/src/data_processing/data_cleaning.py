import pandas as pd
import re
import calendar
from pyspark.sql import SparkSession

def convert_unix_timestamps(df, *timestamp_cols):
    """
    Converts Unix timestamp columns to datetime format.
    
    Args:
        df (pd.DataFrame): DataFrame containing the timestamp columns.
        timestamp_cols (tuple): Columns containing Unix timestamps in milliseconds.
    
    Returns:
        pd.DataFrame: DataFrame with converted datetime columns.
    """
    for col in timestamp_cols:
        if col in df.columns:
            df[col] = pd.to_datetime(df[col], unit='ms')
        else:
            print(f"Column '{col}' not found for timestamp conversion.")
    return df

def standardize_date_component(df, month_col, day_col, year_col):
    """
    Standardizes date components within a DataFrame.

    Args:
        df (pd.DataFrame): DataFrame containing the date columns.
        month_col (str): Name of the month column.
        day_col (str): Name of the day column.
        year_col (str): Name of the year column.

    Returns:
        pd.DataFrame: DataFrame with standardized date columns.
    """
    
    # Function to clean month values
    def clean_month(value):
        if pd.isna(value):
            return None 
        
        original_value = value
        value = str(value).strip().replace('.', '').capitalize()

        month_mapping = {month: str(index).zfill(2) for index, month in enumerate(calendar.month_abbr) if month}
        month_mapping.update({calendar.month_name[index]: str(index).zfill(2) for index in range(1, 13)})

        corrections = {
            'Jan': '01', 'Feb': '02', 'Mar': '03', 'Apr': '04', 'May': '05', 'Jun': '06',
            'Jul': '07', 'Aug': '08', 'Sep': '09', 'Oct': '10', 'Nov': '11', 'Dec': '12',
            'JAN': '01', 'eme': None, '-': None, '/': None
        }
        month_mapping.update(corrections)

        if value.isdigit() and int(value) in range(1, 13):
            cleaned_value = str(int(value)).zfill(2)  # Ensure it is two digits
        else:
            cleaned_value = month_mapping.get(value, None)

        if cleaned_value is None:
            print(f"Failed to clean month: original='{original_value}', processed='{value}'")
        return cleaned_value

    # Function to clean day values
    def clean_day(value):
        if pd.isna(value):
            return None
        original_value = value
        value = str(value).strip().split(' ')[0]

        if value.isdigit() and 1 <= int(value) <= 31:
            return str(int(value)).zfill(2)
        print(f"Failed to clean day: '{original_value}'")
        return None

    # Function to clean year values
    def clean_year(value):
        if pd.isna(value):
            return None
        original_value = value
        value = str(value).strip()

        if value.isdigit():
            if len(value) == 2:
                return '20' + value
            elif len(value) == 4:
                return value
        print(f"Failed to clean year: '{original_value}'")
        return None

    # Apply cleaning functions to each respective column if it exists
    if month_col in df.columns:
        df[month_col] = df[month_col].apply(clean_month)
    else:
        print(f"Column '{month_col}' not found in DataFrame.")
    if day_col in df.columns:
        df[day_col] = df[day_col].apply(clean_day)
    else:
        print(f"Column '{day_col}' not found in DataFrame.")
    if year_col in df.columns:
        df[year_col] = df[year_col].apply(clean_year)
    else:
        print(f"Column '{year_col}' not found in DataFrame.")

    return df

def clean_tenant_name(name):
    """
    Enhances the cleaning of tenant names by addressing specific patterns and inconsistencies observed in the data.
    
    Args:
        name (str): The tenant name to be cleaned.
    
    Returns:
        str: Cleaned tenant name.
    """

    if not isinstance(name, str):
        return None

    # Normalize space and remove leading/trailing whitespace
    normalized_name = ' '.join(name.split())
    

    # Enhanced patterns to remove
    patterns = [
        # Original patterns
        r"\bABN\b\s*[:]*\s*[\d\s]*",  # 'ABN' followed by optional colon and digits/spaces
        r"\bACN\b\s*[:]*\s*[\d\s]*",  # 'ACN' followed by optional colon and digits/spaces
        r"\([^)]*\)",                 # Anything in parentheses
        r"\bt/as\b[^a-zA-Z]*",        # 't/as' followed by non-alphabetic characters
        r"\btrading\s+as\b[^a-zA-Z]*",# 'trading as' followed by non-alphabetic characters
        r"\bATF\b[^a-zA-Z]*",         # 'ATF' followed by non-alphabetic characters
        r"\b[\w\s]+\b\s*[:]*\s*\d{2,}[\d\s]*", # Words followed by optional colon and digits
        r"\bABN\b[:]*",               # Standalone 'ABN' with optional colon
        r"\bACN\b[:]*",               # Standalone 'ACN' with optional colon
        r"\b[\w\.-]+@[\w\.-]+\.\w+",  # Email addresses
        r"\d{1,4}\s?[A-Za-z]+(\s[A-Za-z]+)+", # Address patterns (e.g., "123 Main St")
        r",\s+,",                     # Extra commas
        r"\s{2,}",                    # Extra spaces
        r"-\s*$",                     # Trailing hyphens
        r"Pty\s*\.?\s*Ltd",           # Standardizing 'Pty Ltd' format
        r"/$|-$|\.$",                 # Trailing '/', '-' and '.'
        r"\bT/A\b[^a-zA-Z]*",         # 'T/A' followed by non-alphabetic characters
        r"\bPty\s*ltd\b[^a-zA-Z]*",   # 'Pty ltd' followed by non-alphabetic characters
        r":\s*-|,\s*|^\s*:\s*",       # Various symbols and colons used inconsistently
        r"\b\d{1,3}[/,-]",            # Numbers likely indicating address or suite numbers
        # Unwanted characters and specific patterns
        r"@|^/|^-|&$|^,|,$|^and\s|^as\s|-$|email|sole|^\.$|^;$|^_$|^:$|^!$|^@$|^#$|^%$|^ $|^&$|^,$|^\)$|^1:$|^\|$|^/$|^A\s&|^A-|^J\.|^K\.|^L\.|^M\.|^M\s&|^F\.|^B\s&|^R\s&|^S\s&|^T\s&|^V\s&|^C\s&|^D\s&|^E\s&|^H\s&|^K\s&|^L\s&|^P\s&|^A\.|^V\.|^J\s&|^Y\s&|^and$"
    ]

    # Combine all patterns into a single regex pattern
    combined_pattern = '|'.join(patterns)
    cleaned_name = re.sub(combined_pattern, "", normalized_name, flags=re.IGNORECASE | re.VERBOSE).strip()

    # Set of unwanted names
    unwanted_names = {'!', '*', '-', '--', '.', '...', '0', '2', '4124', 'xxx'}
    if cleaned_name.lower() in unwanted_names or not cleaned_name or len(cleaned_name) < 3:
        return None 

    return cleaned_name