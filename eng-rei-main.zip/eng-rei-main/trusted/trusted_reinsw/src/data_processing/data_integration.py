import pandas as pd
import json
import re
from pyspark.sql import SparkSession
from io import BytesIO
from .data_transformation import add_unique_id, normalize_column_names
from .data_cleaning import standardize_date_component, clean_tenant_name

def list_json_files(bucket, prefix, s3_client):
    """
    List JSON files in an S3 bucket with a specified prefix.

    Args:
        bucket (str): The name of the S3 bucket.
        prefix (str): The prefix to filter the S3 keys.
        s3_client: The S3 client object. If None, a new client will be created.

    Returns:
        list: A list of keys (str) representing the JSON files in the bucket.
    """
    response = s3_client.list_objects_v2(Bucket=bucket, Prefix=prefix)
    return [item['Key'] for item in response.get('Contents', []) if item['Key'].endswith('.json')]

def create_spark_view(dataframe, view_name, spark):
    """
    Creates a temporary view of a Spark DataFrame.

    Args:
        spark (SparkSession): The Spark session.
        dataframe (DataFrame): The Spark DataFrame to create a view for.
        view_name (str): The name of the temporary view.

    Returns:
        None
    """
    valid_view_name = re.sub(r'[^A-Za-z0-9_]', '_', view_name)
    spark_df = spark.createDataFrame(dataframe)
    spark_df.createOrReplaceTempView(valid_view_name)
    print(f"Temporary view '{valid_view_name}' created.")

def process_files_and_categorize_fields(file_keys, s3_client, bucket_name):
    all_data_frames = []
    field_metadata = []
    categories = ['Tenant', 'Agent', 'Landlord', 'Property', 'Lease', 'Transactions', 'Legal', 'Other']
    category_fields = {cat: set(['code']) for cat in categories}

    for key in file_keys:
        try:
            obj = s3_client.get_object(Bucket=bucket_name, Key=key)
            json_content = json.load(BytesIO(obj['Body'].read()))
            flattened_data = pd.json_normalize(json_content)

            # Normalize column names
            flattened_data = normalize_column_names(flattened_data)
            # Add a unique identifier to each row
            flattened_data['nsw_id'] = flattened_data.apply(add_unique_id, axis=1)

            # Standardize date components if present
            date_columns = ['term_start_date_month', 'term_start_date_day', 'term_start_date_year',
                            'term_end_date_month', 'term_end_date_day', 'term_end_date_year']
            if all(col in flattened_data.columns for col in date_columns):
                flattened_data = standardize_date_component(flattened_data, 'term_start_date_month', 'term_start_date_day', 'term_start_date_year')
                flattened_data = standardize_date_component(flattened_data, 'term_end_date_month', 'term_end_date_day', 'term_end_date_year')

            # Clean tenant names if the column exists
            if 'parties_tenant_name_address_abn' in flattened_data.columns:
                flattened_data['parties_tenant_name_address_abn'] = flattened_data['parties_tenant_name_address_abn'].apply(clean_tenant_name)

            # Append the processed DataFrame to the list
            all_data_frames.append(flattened_data)

            # Categorize each field and store metadata
            for field in flattened_data.columns:
                category = categorize_fields(field)
                category_fields[category].add(field)
                field_metadata.append({'Key': key, 'Field': field, 'Category': category})

        except Exception as e:
            print(f"Error processing file {key}: {e}")

    # Concatenate all data frames into a single DataFrame
    main_df = pd.concat(all_data_frames, axis=0, ignore_index=True)

    # Adjust category fields
    for cat in category_fields:
        category_fields[cat].add('code')
        category_fields[cat].add('nsw_id')

    # Generate category-specific dataframes
    category_dataframes = {cat: main_df[list(category_fields[cat].intersection(main_df.columns))] for cat in categories}

    # Returning the main DataFrame and category-specific DataFrames
    return main_df, category_dataframes, field_metadata

def categorize_fields(field_name):
    categories = {
        'Tenant': r'(tenant_|lease)',
        'Agent': r'(agent_|agency)',
        'Landlord': r'(landlord_|principal)',
        'Property': r'(property_|premises|permitted)',
        'Lease': r'(lease_|rent|security|Term_)',
        'Transactions': r'(financial_|rent|bond)',
    }

    for category, pattern in categories.items():
        if re.search(pattern, field_name, re.IGNORECASE):
            return category
    return 'Other'

def create_delta_table(df, spark, table_name):
    """
    Converts a Pandas DataFrame to a Spark DataFrame and appends it as a Delta table.

    Args:
        df (pd.DataFrame): The Pandas DataFrame to be converted and saved.
        spark (SparkSession): Active Spark session.
        table_name (str): The name of the Delta table to save the data to.
    """

    spark_df = spark.createDataFrame(df)
    spark_df.write.format("delta").mode("overwrite").option("mergeSchema", "true").saveAsTable(f"{table_name}")

