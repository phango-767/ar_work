import pandas as pd
import hashlib
import re
from pyspark.sql import SparkSession

def add_unique_id(df, id_col_name='unique_id'):
    """
    Adds a unique identifier column to a DataFrame based on specified columns.

    Args:
        df (pd.DataFrame): DataFrame to which the unique ID will be added.
        id_col_name (str): Name of the new unique ID column.

    Returns:
        pd.DataFrame: DataFrame with the unique ID column added.
    """
    def generate_unique_id(row):
        code = str(row['code']) if 'code' in row else 'unknown'
        created = str(row['created']) if 'created' in row else 'unknown'
        premises_addressfull = str(row['premises_addressfull']) if 'premises_addressfull' in row else 'unknown'
        Premises_Title = str(row['premises_title']) if 'premises_title' in row else 'unknown'

        combined_string = '_'.join([code, created, premises_addressfull, Premises_Title])
        
        return hashlib.sha256(combined_string.encode()).hexdigest()

    # Apply the function row-wise to generate unique IDs
    df[id_col_name] = df.apply(generate_unique_id, axis=1)
    return df


def normalize_column_names(df):
    """
    Normalizes column names in a DataFrame to a consistent format.

    Args:
        df (pd.DataFrame): The DataFrame whose column names need to be normalized.

    Returns:
        pd.DataFrame: DataFrame with normalized column names.
    """
    valid_sql_column_pattern = re.compile(r'^[a-zA-Z_][a-zA-Z0-9_]*$')

    new_column_names = {}
    duplicates = {}
    
    for col in df.columns:
        new_col = col.lower().replace('values.', '').replace(' ', '_').replace('.', '_')
        new_col = re.sub(r'[^a-zA-Z0-9_]', '_', new_col)

        if new_col in new_column_names.values():
            count = duplicates.get(new_col, 0)
            duplicates[new_col] = count + 1
            unique_col = f"{new_col}_{count}"
            new_column_names[col] = unique_col
        else:
            new_column_names[col] = new_col

    return df.rename(columns=new_column_names)
