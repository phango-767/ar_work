import pandas as pd
import logging
import numpy as np
import re
import json
from dateutil import parser
from datetime import datetime
from contextual_classification import contextual_classification

######
# Apply transformations to the pandas DataFrame.
#####

def transform_data(pandas_df):
    logging.info(f"Initial DataFrame shape: {pandas_df.shape}")
    
    def standardise_comments(text):
        if pd.isna(text):
            return None  

        # Handle backslashes that are not part of an escape sequence for new lines
        text = re.sub(r'\\(?![rn])', r'\\', text)

        # Replace known line break characters and remove multiple spaces
        text_no_line_breaks = re.sub(r'\\r\\n|\\n|\\r|\s+', ' ', text).strip()
        text_no_line_breaks = re.sub(r'\.\s*\.', '', text_no_line_breaks)
        
        # Capitalize the first letter of each sentence and make the rest lower case
        sentences = re.split(r'(?<=\.)\s+', text_no_line_breaks)  # Split sentences on period followed by space
        capitalized_sentences = [sentence.capitalize().strip() for sentence in sentences]
        cleaned_text = ' '.join(capitalized_sentences)

        return cleaned_text
    
    def classify_permitted_use(pandas_df):
        pandas_df['permittedusetype'] = None  # Initialize the column
        batch_size = 100
        total_batches = len(pandas_df) // batch_size + (1 if len(pandas_df) % batch_size else 0)

        # Processing in batches with progress prints
        for i in range(0, len(pandas_df), batch_size):
            for index, row in pandas_df.iloc[i:i+batch_size].iterrows():
                result = contextual_classification(row['premisespermitteduse'])
                pandas_df.at[index, 'permittedusetype'] = result
                
    def standardize_date(row, col_name):
        date = row[col_name]
        if pd.isna(date) or str(date).strip().lower() in ['nan', 'nat', '']:
            return None
        try:
            # Attempt to convert the date to a datetime object
            parsed_date = pd.to_datetime(date, errors='coerce', dayfirst=True)
            if pd.isna(parsed_date):
                return None
            return parsed_date.date()  # Returning the date part only
        except Exception as e:
            print(f"Error processing date {date}: {e}")
            return None
    
    # Call the classification function
    classify_permitted_use(pandas_df)

    # Apply transformations to specific columns
    description_fields = ['leaseoutgoingsperc']
    for col in description_fields:
        if col in pandas_df.columns:
            pandas_df[col] = pandas_df[col].apply(standardise_comments)  # Apply directly without converting to string
        else:
            print(f"Warning: {col} does not exist in the DataFrame and will be skipped.")

    date_fields = ['agencyperiodstartdate' ,'agencyperiodenddate','AgreementDate','renewalfinaldate','rentreviewdate2','created'] 
    for col in date_fields:
        if col in pandas_df.columns:
            if col in date_fields:
                pandas_df[col] = pandas_df.apply(lambda row: standardize_date(row, col), axis=1)

    logging.info(f"DataFrame shape after transformation: {pandas_df.shape}")
    print(f"DataFrame shape after transformation: {pandas_df.shape}")
    return pandas_df