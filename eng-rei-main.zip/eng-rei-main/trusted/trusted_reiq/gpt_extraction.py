import openai
import config
import concurrent.futures

openai.api_key = config.openai_api_key

def parse_text(text):
    keywords = ["sqm", "m2", "square"]
    if not any(keyword in text.lower() for keyword in keywords):
        return None
    
    prompt = f"I am going to give you a string from a free text field, please extract ONLY the sqm or total sqm value from the provided string if available. I only expect a single numeric value in your output, if you don't find anything then return n/a: '{text}'"
    try:
        response = openai.ChatCompletion.create(
            model="gpt-3.5-turbo-0125",
            messages=[
                {"role": "system", "content": "Extract specific information from commercial real estate data."},
                {"role": "user", "content": prompt}
            ]
        )
        if response['choices'] and len(response['choices']) > 0:
            content = response['choices'][0]['message']['content'].strip()
            if content.lower() == 'n/a' or content == '':
                return None
            # Try to convert to float and validate the sqm value
            try:
                sqm = float(content)
                if 0 < sqm < 1:
                    return None 
                return sqm 
            except ValueError:
                # Return None if conversion to float fails, indicating no valid number was extracted
                return None
        else:
            print("No valid response found in GPT output.")
            return None
    except Exception as e:
        print(f"An error occurred: {e}")
        return None 

    return None

def gpt_escalation_rate(df):
    texts = df['premisestenancyno'].tolist()
    print(f"Processing total of {len(texts)} rows.")

    with concurrent.futures.ThreadPoolExecutor() as executor:
        future_to_index = {executor.submit(parse_text, text): i for i, text in enumerate(texts)}
        results = [None] * len(texts)

        for future in concurrent.futures.as_completed(future_to_index):
            index = future_to_index[future]
            try:
                result = future.result()
            except Exception as e:
                print(f"Error processing row {index}: {e}")
                result = None
            results[index] = result

            # Print progress update every 500 rows
            if (index + 1) % 500 == 0 or (index + 1) == len(texts):
                print(f"Processed {index + 1} rows out of {len(texts)}")

    df['extracted_sqm'] = results
    print(f"Assigned results back to DataFrame for {len(results)} rows.")
    return df