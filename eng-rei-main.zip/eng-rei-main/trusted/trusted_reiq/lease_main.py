# Databricks notebook source
import pandas as pd

with open('/dbfs/FileStore/EF024_Transposed_Format.csv', 'r', encoding='latin-1') as file:
    reiq_lease_df = pd.read_csv(file)
  
reiq_lease = spark.createDataFrame(reiq_lease_df)
reiq_lease.createOrReplaceTempView("reiq_lease")

# COMMAND ----------

# MAGIC %sql
# MAGIC -- drop table `arealytics-databricks_unity_catalog`.arealyticstrusted.reiq_geocoded_data
# MAGIC select * from `arealytics-databricks_unity_catalog`.arealyticstrusted.reiq_geocoded_data_v2

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT
# MAGIC id,
# MAGIC     formatted_address,
# MAGIC     REGEXP_SUBSTR(street_number, '\\d+') AS Street_Number_cleaned,
# MAGIC     street_number,
# MAGIC     CAST(
# MAGIC         SPLIT(street_number, '-')[0] AS INT
# MAGIC     ) AS StreetNumberMin,
# MAGIC     CAST(
# MAGIC         CASE 
# MAGIC             WHEN street_number LIKE '%-%' THEN
# MAGIC                 SPLIT(street_number, '-')[1]
# MAGIC             ELSE
# MAGIC                 NULL
# MAGIC         END AS INT
# MAGIC     ) AS StreetNumberMax,
# MAGIC     suburb,
# MAGIC     Unit,
# MAGIC     postal_code,
# MAGIC     latitude,
# MAGIC     longitude,
# MAGIC     CASE 
# MAGIC         WHEN unit = '00 00' OR unit IN ('00', '', '0') THEN NULL 
# MAGIC         ELSE REGEXP_EXTRACT(unit, '(\\d+)', 1)
# MAGIC     END as Cleaned_Unit,
# MAGIC     REGEXP_REPLACE(street_name, CONCAT('\\s+(', suffix_list.suffix_regex, ')$'), '') as Cleaned_Street_Name,
# MAGIC     CAST(NULL as INT) as PropertyID
# MAGIC FROM 
# MAGIC     `arealytics-databricks_unity_catalog`.arealyticstrusted.reiq_geocoded_data_v2
# MAGIC CROSS JOIN 
# MAGIC     (SELECT concat_ws('|', collect_list(suffix),'Cres','Parade') as suffix_regex FROM `arealytics-databricks_unity_catalog`.arealyticstrusted.propertysuffixmap) as suffix_list;

# COMMAND ----------

# MAGIC %sql
# MAGIC select
# MAGIC main.id,
# MAGIC
# MAGIC TRIM(TRAILING ', ' FROM
# MAGIC                                             CONCAT_WS(', ',
# MAGIC                                                 CONCAT_WS('/', 
# MAGIC                                                 NULLIF(TRIM(COALESCE(TRIM(NULL), '')), ''),
# MAGIC                                                 COALESCE(
# MAGIC                                                     -- Use premisesstreet2 if available; otherwise, use premisesstreet1
# MAGIC                                                     NULLIF(TRIM(COALESCE(main.premisesstreet2, '')), ''),
# MAGIC                                                     NULLIF(TRIM(COALESCE(, '')), '')
# MAGIC                                                 )
# MAGIC                                                 ),
# MAGIC                                                 NULLIF(TRIM(COALESCE(main.premisessuburb, '')), ''),
# MAGIC                                                 CONCAT_WS(' ',
# MAGIC                                                 COALESCE(main.premisesstate, 'QLD'),
# MAGIC                                                 TRIM(COALESCE(CAST(FLOOR(main.premisespostcode) AS STRING), ''))
# MAGIC                                                 )
# MAGIC                                             )
# MAGIC                                             ) AS raw_address
# MAGIC
# MAGIC FROM `arealytics-databricks_unity_catalog`.arealyticstrusted.reiq_leasesnapshot as main

# COMMAND ----------

# MAGIC %sql
# MAGIC select
# MAGIC main.id,
# MAGIC pid.PropertyId,
# MAGIC TRIM(TRAILING ', ' FROM
# MAGIC                                             CONCAT_WS(', ',
# MAGIC                                                 CONCAT_WS('/', 
# MAGIC                                                 NULLIF(TRIM(COALESCE(TRIM(main.premisestenancyno), '')), ''),
# MAGIC                                                 COALESCE(
# MAGIC                                                     -- Use premisesstreet2 if available; otherwise, use premisesstreet1
# MAGIC                                                     NULLIF(TRIM(COALESCE(main.premisesstreet2, '')), ''),
# MAGIC                                                     NULLIF(TRIM(COALESCE(main.premisesstreet1, '')), '')
# MAGIC                                                 )
# MAGIC                                                 ),
# MAGIC                                                 NULLIF(TRIM(COALESCE(main.premisessuburb, '')), ''),
# MAGIC                                                 CONCAT_WS(' ',
# MAGIC                                                 COALESCE(main.premisesstate, 'QLD'),
# MAGIC                                                 TRIM(COALESCE(CAST(FLOOR(main.premisespostcode) AS STRING), ''))
# MAGIC                                                 )
# MAGIC                                             )
# MAGIC                                             ) AS raw_address,
# MAGIC   geo.formatted_address,
# MAGIC   a.AddressText
# MAGIC
# MAGIC FROM `arealytics-databricks_unity_catalog`.arealyticstrusted.reiq_leasesnapshot as main
# MAGIC
# MAGIC left join `arealytics-databricks_unity_catalog`.arealyticstrusted.reiq_pid_link as pid
# MAGIC on main.id = pid.id
# MAGIC
# MAGIC LEFT JOIN `arealytics-databricks_unity_catalog`.arealyticstrusted.Address A 
# MAGIC on a.parentid = pid.PropertyID
# MAGIC
# MAGIC left join `arealytics-databricks_unity_catalog`.arealyticstrusted.reiq_geocoded_data_v2 as geo
# MAGIC on geo.id = main.id
# MAGIC

# COMMAND ----------

import pandas as pd

in_market_zip_df = pd.read_csv('/dbfs/FileStore/reiq/in_market_zip.csv', encoding='latin1')
in_market_zip = spark.createDataFrame(in_market_zip_df)
in_market_zip.createOrReplaceTempView("in_market_zip")

# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC
# MAGIC select premisestenancyno,extracted_sqm from `arealytics-databricks_unity_catalog`.arealyticstrusted.reiq_lease_sqm
