import logging
from pyspark.sql import SparkSession
spark = SparkSession.builder.appName("create_tables").getOrCreate()

######
# Load the pandas DataFrame into Spark and create a temporary table/view.
#####
def load_to_spark(pandas_df, view_name="lease_main"):
    if pandas_df.empty:
        print(f"The DataFrame is empty. Cannot load into Spark with view name: {view_name}")
        return  # Exit the function if the DataFrame is empty

    spark_df = spark.createDataFrame(pandas_df)
    spark_df.createOrReplaceTempView(view_name)
    print(f"DataFrame loaded into Spark, View Name: {view_name}")