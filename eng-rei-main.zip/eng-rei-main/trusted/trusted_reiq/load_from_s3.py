import boto3
import pandas as pd
from io import StringIO


def load_data(bucket_name, prefix, encoding='utf-8'):
    """
    Load all JSON data files from a specified prefix in an S3 bucket into a pandas DataFrame 
    and generate a unique 'id' for each row starting from 1.

    Parameters:
    - bucket_name (str): Name of the S3 bucket.
    - prefix (str): Prefix within the S3 bucket where the JSON files are stored.
    - encoding (str): Encoding of the file.

    Returns:
    - df_all (pandas.DataFrame): Data loaded into a pandas DataFrame.
    """
    s3_client = boto3.client('s3')
    response = s3_client.list_objects_v2(Bucket=bucket_name, Prefix=prefix)
    
    dfs = []
    for obj in response.get('Contents', []):
        file_key = obj['Key']
        if file_key.endswith('.json'):
            s3_response = s3_client.get_object(Bucket=bucket_name, Key=file_key)
            data = s3_response['Body'].read().decode(encoding)
            
            df = pd.read_json(StringIO(data))
            dfs.append(df)

    if dfs:
        df_all = pd.concat(dfs, ignore_index=True)
        df_all.reset_index(inplace=True, drop=False)
        df_all['index'] += 1
        df_all.rename(columns={'index': 'id'}, inplace=True)
    else:
        df_all = pd.DataFrame()

    return df_all

# df = load_data('arealytics-data-lake-raw', 'source=rei/dataflow=reiq/archive/EF024 Transposed Format.csv')
# df = load_data('arealytics-data-lake-raw', 'source=rei/dataflow=reiq/')
# # display(df.head(5))

# sdf = spark.createDataFrame(df)
# sdf.write.format("delta").mode("overwrite").saveAsTable("reiq_lease")