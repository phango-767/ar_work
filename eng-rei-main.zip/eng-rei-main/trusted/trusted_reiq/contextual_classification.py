# Office-related Keywords
office_keywords = [
    'office', 'administrative', 'corporate', 'clinic', 'studio', 
    'counselling', 'counseling', 'psychologist', 'medical', 'massage', 
    'therapist', 'legal', 'finance', 'accounting', 'education', 'school', 
    'immigration', 'tailor', 'agency', 'surgery', 'dental', 'law', 'consulting', 
    'therapy', 'psychiatry', 'design', 'architect', 'engineering', 'training', 
    'coaching', 'tutorial', 'tutoring', 'legal services', 'accountancy', 'medical practice', 
    'dental clinic', 'health services', 'therapy center', 'law office', 'financial services', 
    'consultancy', 'educational institution', 'learning center', 'therapy services', 'tutor'
]

# Industrial-related Keywords
industrial_keywords = [
    'warehouse', 'manufacturing', 'industrial', 'storage', 'car park', 
    'workshop', 'polishing', 'wholesaler', 'construction', 'engineering', 
    'fabrication', 'assembly', 'mechanic', 'repair', 'office and storage', 
    'office and warehouse', 'office administration and storage', 'stonemason', 
    'warehousing', 'office, warehouse', 'warehouse/storage', 'factory', 
    'production', 'logistics', 'distribution center', 'assembly line', 'work yard', 
    'industrial park', 'fabrication plant', 'mechanical', 'automotive', 'machinery', 
    'manufacture', 'industrial unit', 'industrial facility', 'industrial site','panel beating', 'spray painting', 'cabinet making', 'chemical lab',
    'car dealership', 'printing', 'manufacturing', 'distribution', 'lab', 'laboratory',
    'vehicle inspections', 'farm', 'farming', 'horticulture', 'construction'
]

# Retail-related Keywords
retail_keywords = [
    'retail', 'store', 'shop', 'restaurant', 'cafe', 'eatery', 'food', 
    'beverage', 'salon', 'beautician','beauty', 'tattoo', 'jewellery', 'clothing', 
    'boutique', 'market', 'grocery', 'convenience', 'shopping', 'mall', 
    'diner', 'bakery', 'coffee shop', 'snack bar', 'bistro', 'supermarket', 
    'food court', 'deli', 'delicatessen', 'fast food', 'pub', 'bar', 'nightclub', 
    'florist', 'gift shop', 'bookstore', 'furniture', 'hardware', 'electronics', 
    'apparel', 'footwear', 'sports store', 'toy store', 'pharmacy', 'drugstore',
    'medispa', 'gym', 'showroom', 'laundromat', 'nursery', 'pharmacy', 'healthcare',
    'psychology', 'chiropractic', 'fashion', 'hairdresser', 'beautician', 'salon',
    'restaurant', 'cafe', 'eatery', 'pub', 'bar', 'nightclub', 'florist', 'gift shop',
    'bookstore', 'furniture store', 'hardware store', 'electronics store', 'apparel store',
    'footwear store', 'sports store', 'toy store', 'drugstore','restuarant'
]

def contextual_classification(text):
    # Check if the input is a string, if not, return 'Unclassified'
    if not isinstance(text, str):
        return 'Unclassified'

    text_lower = text.lower()
    found_categories = set()

    # Function to check keywords in the text
    def check_keywords(keywords, category):
        for keyword in keywords:
            if keyword in text_lower:  # Checking if the keyword is a substring of the text
                found_categories.add(category)
                return  # Exit the function once a match is found

    # Check for negation phrases
    is_non_retail = "non-retail" in text_lower

    # Check each category
    check_keywords(office_keywords, "Office")
    check_keywords(industrial_keywords, "Industrial")
    if not is_non_retail:
        check_keywords(retail_keywords, "Retail")

    # Prioritize 'Industrial' if it's one of the found categories
    if "Industrial" in found_categories:
        return "Industrial"

    # Format the output correctly if multiple categories are found
    elif len(found_categories) > 1:
        return ', '.join(found_categories)  # Join categories as a string

    # Handle the case where only one category is found
    elif len(found_categories) == 1:
        return found_categories.pop()

    # Return 'Unclassified' if no match is found
    else:
        return 'Unclassified'