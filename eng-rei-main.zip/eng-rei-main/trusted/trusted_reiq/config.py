
bucket_name = "arealytics-data-lake-raw"
file_key = "source=rei/dataflow=reiq/"
api_key = "xxx"
openai_api_key = 'xxx'
perform_geocoding = True
perform_gpt_escaltion_extraction = False

# Upsert data into Delta tables
dataset_unique_cols = {
    "reiq_leasesnapshot": ["id"]
}
geo_dataset_unique_cols = {
    "reiq_geocoded_data": ["id"]
}
escaltion_dataset_unique_cols = {
    "reiq_escaltion_rate": ["id"]
}
