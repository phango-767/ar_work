import contextual_classification
from load_from_s3 import load_data
from cleaning import transform_data
from geocoding import Perform_geocoding
from spark_loading import load_to_spark
from delta_cdc import upsert_data
from gpt_extraction import gpt_escalation_rate
import config
import importlib
import logging

# reload modules
importlib.reload(config)

def main():
    try:
        raw_data = load_data(config.bucket_name, config.file_key)
        transformed_data = transform_data(raw_data)
        # display(transformed_data)

        # Peform geocoding
        if config.perform_geocoding:
            geocoded_data = Perform_geocoding(transformed_data)
            spark_df = spark.createDataFrame(geocoded_data)
            spark_df.write.format("delta").mode("overwrite").option("mergeSchema", "true").saveAsTable("`arealytics-databricks_unity_catalog`.arealyticstrusted.reiq_geocoded_data")

        # Extract escaltion rate using gpt
        if config.perform_gpt_escaltion_extraction:
            drop_na_df = transformed_data.dropna(subset=['premisestenancyno'])
            escaltion_rate = gpt_escalation_rate(drop_na_df)
            load_to_spark(escaltion_rate, "reiq_lease_sqm")
            for dataset_type, unique_cols in config.escaltion_dataset_unique_cols.items():
                upsert_data(spark, dataset_type, unique_cols)
        else:
        #  Load transformed data into Spark
            load_to_spark(transformed_data, "reiq_leasesnapshot")
            for dataset_type, unique_cols in config.dataset_unique_cols.items():
                upsert_data(spark, dataset_type, unique_cols)
            
    except ValueError as ve:
        logging.error("ValueError occurred: %s", ve)
    except Exception as e:
        logging.error("General Error occurred: %s", e)
if __name__ == "__main__":
    main()
