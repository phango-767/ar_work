from pyspark.sql.functions import current_date

def table_exists(spark, table_name):
    try:
        spark.sql(f"DESCRIBE TABLE {table_name}")
        return True
    except:
        return False

def upsert_data(spark, dataset_type, unique_cols):
    location = f"s3://arealytics-data-lake-trusted/source=rei/dataflow=reiv/renewal_august_2024/{dataset_type}"
    table_name = f"`arealytics-databricks_unity_catalog`.arealyticstrusted.reiv_{dataset_type}"
    view_name = f"{dataset_type}"
    on_conditions = " AND ".join([f"target.{col} = source.{col}" for col in unique_cols])

    if table_exists(spark, table_name):
        # Get column names from the source view
        view_columns = spark.sql(f"DESCRIBE {view_name}").select("col_name").rdd.flatMap(lambda x: x).collect()

        # Ensure LoadDate and UpdateDate are not in the insert or update columns list
        view_columns = [col for col in view_columns if col not in ['LoadDate', 'UpdateDate']]
        insert_columns = ", ".join(view_columns + ['LoadDate', 'UpdateDate'])  # Columns to insert
        insert_values = ", ".join([f"source.{col}" for col in view_columns] + [f"current_timestamp()", f"current_timestamp()"])  # Values to insert
        
        update_set = ", ".join([f"target.{col} = source.{col}" for col in view_columns if col not in unique_cols] + ["target.UpdateDate = current_timestamp()"])  # Update columns

        spark.sql(f"""
        MERGE INTO {table_name} AS target
        USING {view_name} AS source
        ON {on_conditions}
        WHEN MATCHED THEN 
            UPDATE SET {update_set}
        WHEN NOT MATCHED THEN 
            INSERT ({insert_columns}) VALUES ({insert_values})
        """)
        print("Merge operation successful.")
    else:
        # If the table does not exist, create it using the data from the view with current_timestamp for LoadDate and UpdateDate
        spark.sql(f"""
        CREATE TABLE {table_name}
        USING DELTA
        LOCATION '{location}'
        AS SELECT *, current_timestamp() as LoadDate, current_timestamp() as UpdateDate FROM {view_name}
        """)
        print(f"Table {table_name} created with data from {view_name}.")
