import contextual_classification
from data_loading import load_data_from_s3, get_lease_types_from_s3
from data_transformation import transform_data
from geocoding import Perform_geocoding
from spark_loading import load_to_spark
from delta_cdc import upsert_data
import config
import importlib
import logging

# reload modules
importlib.reload(config)

import data_transformation
importlib.reload(data_transformation)

import spark_loading
importlib.reload(spark_loading)

def main():
    try:
        # Fetch lease types from S3
        lease_types = get_lease_types_from_s3(config.S3_BUCKET)

        # Load data from S3 for the fetched lease types
        raw_data = load_data_from_s3(config.S3_BUCKET, lease_types, config.YEARS)

        # Transform the loaded data
        transformed_data = transform_data(raw_data)

        # # Perform geocoding
        geocoded_data = Perform_geocoding(transformed_data)   
    
        # # Load the transformed data into Spark
        # load_to_spark(transformed_data)
        
        load_to_spark(geocoded_data, view_name="geocoded_data")
    
        # Upsert data into Delta tables
        dataset_unique_cols = {
            "geocoded_data": ["id"]
        }

        for dataset_type, unique_cols in dataset_unique_cols.items():
            upsert_data(spark, dataset_type, unique_cols)
            
    except ValueError as ve:
        logging.error("ValueError occurred: %s", ve)
    except Exception as e:
        logging.error("General Error occurred: %s", e)

if __name__ == "__main__":
    main()
