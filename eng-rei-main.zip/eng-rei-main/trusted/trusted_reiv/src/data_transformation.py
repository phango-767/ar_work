import pandas as pd
import logging
import numpy as np
import re
import json
from dateutil import parser
from datetime import datetime
from contextual_classification import contextual_classification

######
# Apply transformations to the pandas DataFrame.
#####

def transform_data(pandas_df):
    logging.info(f"Initial DataFrame shape: {pandas_df.shape}")
    
    def standardise_comments(text):
        if pd.isna(text):
            return text  

        # Handle backslashes that are not part of an escape sequence for new lines
        text = re.sub(r'\\(?![rn])', r'\\', text)

        # Replace known line break characters and remove multiple spaces
        text_no_line_breaks = re.sub(r'\\r\\n|\\n|\\r|\s+', ' ', text).strip()
        text_no_line_breaks = re.sub(r'\.\s*\.', '', text_no_line_breaks)
        
        # Capitalize the first letter of each sentence and make the rest lower case
        sentences = re.split(r'(?<=\.)\s+', text_no_line_breaks)  # Split sentences on period followed by space
        capitalized_sentences = [sentence.capitalize().strip() for sentence in sentences]
        cleaned_text = ' '.join(capitalized_sentences)

        return cleaned_text

    def clean_unit_identifier(identifier):
        identifier = re.sub(r'\d+\s*\)', '', identifier)
        identifier = re.sub(r'[/,()]', '', identifier)
        words = identifier.split()
        cleaned_words = [word for word in words if any(char.isdigit() for char in word)]
        return ' '.join(cleaned_words)
    
    def classify_permitted_use(pandas_df):
        pandas_df['permittedusetype'] = None  # Initialize the column
        batch_size = 100
        total_batches = len(pandas_df) // batch_size + (1 if len(pandas_df) % batch_size else 0)

        # Processing in batches with progress prints
        for i in range(0, len(pandas_df), batch_size):
            for index, row in pandas_df.iloc[i:i+batch_size].iterrows():
                result = contextual_classification(row['permittedusedescription'])
                pandas_df.at[index, 'permittedusetype'] = result
            
    def standardize_date(row, col_name):
        date = row[col_name]
        if pd.isna(date) or str(date).strip().lower() in ['nan', 'nat', '']:
            return None
        try:
            # Check if the date is a dictionary-like string (JSON)
            if isinstance(date, str) and date.startswith("{"):
                date_json_str = date.replace("'", '"')  # Ensure double quotes for JSON
                date_dict = json.loads(date_json_str)  # Parse string as JSON
                if '$numberLong' in date_dict:
                    # Convert Unix timestamp (milliseconds) to datetime
                    return datetime.utcfromtimestamp(int(date_dict['$numberLong']) / 1000).strftime('%Y-%m-%d %H:%M:%S')
            elif isinstance(date, (float, int)):  # Handle numeric timestamps (assumed in milliseconds)
                return datetime.utcfromtimestamp(date / 1000).strftime('%Y-%m-%d %H:%M:%S')
            elif isinstance(date, str):  # Handle improperly formatted numeric strings
                # This handles numeric strings directly as timestamps
                return datetime.utcfromtimestamp(float(date) / 1000).strftime('%Y-%m-%d %H:%M:%S')
        except Exception as e:
            print(f"Error processing date {date}: {e}")
            return None
    
    def clean_tenant_name(name):
        pattern = r"(\bACN\b[^0-9]*[0-9 ]+|\bABN\b[^0-9]*[0-9 ]+|\([^)]*\)|T/AS[^a-zA-Z]*|trading as[^a-zA-Z]*|ATF[^a-zA-Z]*)"
        cleaned_name = re.sub(pattern, "", name, flags=re.IGNORECASE).strip()
        unwanted_names = {'!', '*', '-', '--', '.', '..................................................................', '...', '0', '2', '4124', 'xxx'}
        return None if cleaned_name.lower() in unwanted_names else cleaned_name
    
    # Call the classification function
    classify_permitted_use(pandas_df)

    # Apply transformations to specific columns
    description_fields = ['furthertermsdescription', 'outgoingsapportionmentdescription', 'excludedoutgoingsdescription', 'fixturesfittingsdescription', 'specialconditions']
    for col in description_fields:
        if col in pandas_df.columns:
            pandas_df[col] = pandas_df[col].astype(str).apply(standardise_comments)
        else:
            print(f"Warning: {col} does not exist in the DataFrame and will be skipped.")

    date_fields = ['commencementdate', 'rentcommencementdate', 'premisesleasedate', 'renewalleasedate', 'exerciseoptiondate','leasedate'] 
    for col in ['unitnumber', 'tenantname'] + date_fields:
        if col in pandas_df.columns:
            if col in date_fields:
                pandas_df[col] = pandas_df.apply(lambda row: standardize_date(row, col), axis=1)
            elif col == 'unitnumber':
                pandas_df[col] = pandas_df[col].astype(str).apply(clean_unit_identifier)
            elif col == 'tenantname':
                pandas_df[col] = pandas_df[col].astype(str).apply(clean_tenant_name)
        
    # Clean up ACN/ABN to ensure commas are handled properly
    for field in ['landlordacn', 'tenantacn', 'agentacn', 'tenantabn', 'landlordabn']:
        if field in pandas_df.columns:
            pandas_df[field] = pandas_df[field].astype(str).replace(r'\s+', '', regex=True).str.strip() 
            pandas_df[field] = pandas_df[field].replace({'ACN': '', '-': ''}, regex=True)
            pandas_df[field] = pandas_df[field].apply(lambda x: re.sub(r'\b[a-zA-Z]+\b', '', x))  # Remove non-numeric words
            pandas_df[field] = pandas_df[field].apply(lambda x: None if x == '' else x)

    # Clean up rent amounts
    for field in ['initialrentamount', 'landlordpiamount', 'securitydespositmonthsrent']:
        if field in pandas_df.columns:
            pandas_df[field] = pandas_df[field].astype(str).replace(r'\$', '', regex=True)  # Remove dollar signs
            pandas_df[field] = pandas_df[field].replace(r'\s+', '', regex=True)  # Remove spaces
    
    # Postal code cleanup, including removal of full stops and other non-numeric characters
    postcode_fields = ['postcode', 'tenantpostcode', 'agentpostcode', 'landlordpostcode', 'propertypostcode']
    for field in postcode_fields:
        if field in pandas_df.columns:
            pandas_df[field] = pandas_df[field].astype(str).replace('.', '')  # Remove full stops
            pandas_df[field] = pandas_df[field].str.replace(r'\.0*$', '').replace(r'[^\d,]', '', regex=True)  # Remove trailing decimal and zeros
            pandas_df[field] = pandas_df[field].apply(lambda x: x[:-1] if len(x) == 5 and x.endswith('0') else x)  # Truncate 5-digit postcodes

    # Standardize all object columns
    for col in pandas_df.select_dtypes(include=['object']).columns:
        pandas_df[col] = pandas_df[col].astype(str).str.replace(r'[\["\]()]', '', regex=True).str.strip()
        pandas_df[col] = pandas_df[col].replace({'nan': '', 'Nan': '', 'Nil': '', 'NIL': '', 'None': '', r'(?<!\d),+(?!\d)': ''}, regex=True)
        pandas_df[col] = pandas_df[col].apply(lambda x: None if x == '' else x)

    logging.info(f"DataFrame shape after transformation: {pandas_df.shape}")
    print(f"DataFrame shape after transformation: {pandas_df.shape}")
    return pandas_df

    
######
# Unflatten fields
#####

def extract_json_data(row, col_name):
    try:
        # Replace single quotes with double quotes and try to parse JSON
        data_str = row[col_name].replace("'", "\"")
        data_list = json.loads(data_str)

        for data in data_list:
            data['ReivId'] = row['id']
            data['leasedate'] = row['leasedate']
            # data['datasettype'] = row['dataset_type']
        return data_list
    except Exception as e:
        logging.error(f"JSON parsing error in extract_json_data with column {col_name}: {e}\nMalformed data: {row[col_name]}", exc_info=True)
        return []

