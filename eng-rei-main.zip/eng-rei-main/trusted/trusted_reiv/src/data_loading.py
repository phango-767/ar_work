import pandas as pd
import boto3
from pyspark.sql import SparkSession
import json
import logging
import s3fs
import numpy as np
import re
from dateutil import parser
from datetime import datetime

# Setting up the logging configuration
# logging.basicConfig(level=logging.INFO)
# Global definition of api_key this will change to a scope
api_key = 'xxxx' 

######
# Fetch the list of years (folders) from the specified S3 bucket and prefix.
#####
def get_years_from_s3(bucket, lease_type_prefix):
    logging.info(f"Fetching years from bucket: {bucket} with prefix: {lease_type_prefix}")
    s3_client = boto3.client('s3')
    result = s3_client.list_objects_v2(Bucket=bucket, Prefix=lease_type_prefix, Delimiter='/')

    years = [content['Prefix'].split('/')[-2] for content in result.get('CommonPrefixes', [])]
    logging.info(f"Years fetched from S3: {years}")
    
    if not years:
        logging.warning("No years found for the given prefix in the bucket.")

    return years

######
# Fetch the list of lease types (folders) from the specified S3 bucket.
#####
def get_lease_types_from_s3(bucket):
    logging.info(f"Fetching lease types from bucket: {bucket}")
    s3_client = boto3.client('s3')
    result = s3_client.list_objects_v2(Bucket=bucket, Prefix="source=rei/dataflow=reiv/", Delimiter='/')

    lease_types = [content['Prefix'].split('/')[-2] for content in result.get('CommonPrefixes', [])]
    logging.info(f"Lease types fetched from S3: {lease_types}")
    
    if not lease_types:
        logging.warning("No lease types found in the bucket.")

    return lease_types

######
# Load data from the specified S3 path based on a list of years, bucket, and lease types.
# if years is None, it loads data for all available years.
#####
def load_data_from_s3(bucket, lease_types, years=None):
    s3 = boto3.client('s3')
    all_data = []

    for lease_type in lease_types:
        # Determine the prefixes based on years provided or get all available years
        if years:
            years_list = [year.strip() for year in years.split(",")]
            prefixes = [f"source=rei/dataflow=reiv/{lease_type}/{year}/" for year in years_list]
        else:
            available_years = get_years_from_s3(bucket, f"source=rei/dataflow=reiv/{lease_type}/")
            prefixes = [f"source=rei/dataflow=reiv/{lease_type}/{yr}/" for yr in available_years]
        
        # List and read each CSV file from the prefixes
        for prefix in prefixes:
            response = s3.list_objects_v2(Bucket=bucket, Prefix=prefix)
            if 'Contents' in response:
                for obj in response['Contents']:
                    file_key = obj['Key']
                    if 'archive/' not in file_key and file_key.endswith('.csv'):
                        file_path = f"s3://{bucket}/{file_key}"
                        print(f"Loading data from path: {file_path}")
                        try:
                            # Read the CSV file
                            data = pd.read_csv(file_path)
                            data.columns = [col.lower() for col in data.columns]
                            data['lease_type'] = lease_type
                            all_data.append(data)
                            print(f"Successfully loaded data from path: {file_path}. Records loaded: {len(data)}")
                        except Exception as e:
                            print(f"Error loading data from path {file_path}: {str(e)}")
            else:
                print(f"No files found in {prefix}")

    # Combine all data into a single DataFrame
    if not all_data:
        print("No data loaded from the provided paths.")
        return pd.DataFrame()

    concatenated_data = pd.concat(all_data, ignore_index=True)
    print(f"Total records loaded: {len(concatenated_data)}")
    return concatenated_data