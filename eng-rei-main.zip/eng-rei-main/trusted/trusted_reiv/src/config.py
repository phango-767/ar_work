# Google Maps API Key
API_KEY = "Your_Google_Maps_API_Key"

# S3 Bucket Configuration
S3_BUCKET = "arealytics-data-lake-raw"
YEARS = "2024"
