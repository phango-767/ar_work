## Rei Trusted

This project is dedicated to transforming and enriching data for the Real Estate Institute (REI) in Australia, a major industry body representing real estate professionals. Our goal is to streamline the data handling processes, ensuring efficiency and reliability in delivering high-quality data for insightful analysis and decision-making.

## Folder Structure
- `config.py` Stores configuration settings, such as database connection parameters, API keys, and file paths. It's designed to centralize settings for easy management and updates.
- `contextual_classification.py` A script dedicated to classifying text data into predefined categories, enhancing data understanding and categorization.
- `data_loading.py` Handles the loading of raw data from various sources, ensuring that the initial stage of the data pipeline runs smoothly.
- `data_transformation.py` Responsible for transforming raw data into a more usable format. It includes cleaning, normalizing, and structuring data for the Trusted and Curated layers.
- `delta_cdc.py` Manages Change Data Capture (CDC) in Delta Lake, ensuring that data changes are tracked and managed efficiently.
- `geocoding.py` Converts address data into geographic coordinates, enriching location-based data for more precise analysis.
- `main.py` The main executable script that orchestrates the data pipeline, calling other scripts as needed to process data from raw to curated forms.
- `spark_loading.py` Integrates with Apache Spark for distributed data processing, crucial for handling large datasets.

## Setting Up
- Clone the repo either to your local or to Databricks
- Ensure Python 3.8+ is installed.
- Install necessary dependencies via `pip install -r requirements.txt` (located in the root directory).
- Configure config.py with the necessary parameters and credentials.

## Running the Pipeline
- Navigate to the src directory.
- Execute python main.py.
The main.py script will sequentially invoke other scripts, handling data from loading to transformation and enrichment.

