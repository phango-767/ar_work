import re
import json
import spacy
from pyspark.sql import SparkSession
from pyspark.sql import functions as F
from pyspark.sql.types import StructType, StructField, StringType

# Load the custom SpaCy model
nlp = spacy.load('/dbfs/tmp/lease_extraction_v2/lease_model')

# Function to extract entities using the custom SpaCy model
def extract_entities(text, labels_of_interest):
    if text is None or not isinstance(text, str):
        return json.dumps([])

    try:
        doc = nlp(text)
        entities = [{"label": ent.label_, "text": ent.text} for ent in doc.ents if ent.label_ in labels_of_interest]
        return json.dumps(entities)
    except Exception as e:
        print(f"Exception in extract_entities: {e}")
        return json.dumps([])

# Function for post-processing to capture missing percentages
def capture_missing_percentages(original_text):
    percentage_match = re.search(r'\b\d+%|\b\d+\.\d+%', original_text)
    if percentage_match:
        found_percentage = percentage_match.group()
        return json.dumps([{"label": "Escalation %", "text": found_percentage}])
    return None  # Return None if no percentage is found

# Main function to process a table and field
def process_table_with_spacy_model(spark, table_name, field_name, id_field, labels_of_interest):
    schema = StructType([
        StructField(id_field, StringType(), True),
        StructField(field_name, StringType(), True),
        StructField("extracted_entity", StringType(), True)
    ])

    extract_entities_udf = F.udf(lambda text: extract_entities(text, labels_of_interest), StringType())

    df = spark.sql(f"SELECT {id_field}, {field_name} FROM {table_name}")
    df = df.withColumn('extracted_entities', extract_entities_udf(F.col(field_name)))

    rows = []
    for row in df.collect():
        record_id = row[id_field]
        original_text = row[field_name]

        # Skip processing if the text field is NULL
        if original_text is None:
            continue

        extracted_entities = row['extracted_entities']

        if extracted_entities == "[]" or extracted_entities is None:
            processed_entities = capture_missing_percentages(original_text)
        else:
            processed_entities = extracted_entities

        if processed_entities:
            entities = json.loads(processed_entities)
            for entity in entities:
                rows.append({
                    id_field: record_id,
                    field_name: original_text,
                    'extracted_entity': entity['text']
                })
        else:
            rows.append({
                id_field: record_id,
                field_name: original_text,
                'extracted_entity': None
            })

    result_df = spark.createDataFrame(rows, schema) if rows else spark.createDataFrame([], schema)

    return result_df

# Example usage
# labels_of_interest = ["Rent/ Rate"]
# sample_text = "82,727.27 ($91,000 inc GST)"
# print(extract_entities(sample_text, labels_of_interest))
