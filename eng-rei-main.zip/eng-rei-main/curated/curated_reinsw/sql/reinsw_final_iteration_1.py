# Databricks notebook source

from pyspark.sql import SparkSession
from pyspark.sql.functions import col

aws_bucket_name = 'arealytics-data-lake-raw'
s3_folder_prefix = 'source=rei/dataflow=reinsw/'
base_path = f"s3a://{aws_bucket_name}/{s3_folder_prefix}"
spark = SparkSession.builder.appName("load_csv_from_s3").getOrCreate()
df = spark.read.csv(base_path + "nsw-FM00900-2023-12-01-2024-06-01.csv", header=True, inferSchema=True)
# FM00910 and FM00900
# qld_lease = spark.createDataFrame(qld_lease_df)
df.createOrReplaceTempView("rei_nsw_900")
# --nsw-FM00910-2023-12-01-2024-06-01

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT
# MAGIC
# MAGIC     COALESCE
# MAGIC     (nineten.form_id ,
# MAGIC     ninehundred.form_id) AS Form_ID,
# MAGIC       COALESCE
# MAGIC     (nineten.tenant_acn ,
# MAGIC     ninehundred.tenant_acn) AS tenant_acn,
# MAGIC               COALESCE
# MAGIC     (nineten.tenant_company_name, ninehundred.tenant_company_name, nineten.Parties_Tenant_Name_Address_ABN ,
# MAGIC     ninehundred.Parties_Tenant_Name_Address_ABN) AS Parties_Tenant_Name_Address_ABN,
# MAGIC         COALESCE
# MAGIC     (nineten.Principal_ABN ,
# MAGIC     ninehundred.Principal_ABN) AS Principal_ABN,
# MAGIC           COALESCE
# MAGIC     (nineten.Principal_ACN ,
# MAGIC     ninehundred.Principal_ACN) AS Principal_ACN,
# MAGIC               COALESCE
# MAGIC     (nineten.Parties_Landlord_Name_Address_ABN ,
# MAGIC     ninehundred.Parties_Landlord_Name_Address_ABN) AS Parties_Landlord_Name_Address_ABN
# MAGIC
# MAGIC FROM
# MAGIC    rei_nsw_910 nineten
# MAGIC FULL OUTER JOIN rei_nsw_900 as ninehundred

# COMMAND ----------

# MAGIC %md
# MAGIC **Creating reinsw_abn_acn View**
# MAGIC
# MAGIC The temporary view `reinsw_abn_acn` is created with the intent to clean and standardize the ABN and ACN numbers. 

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE OR REPLACE TEMP VIEW reinsw_abn_acn as
# MAGIC (
# MAGIC with CTE as
# MAGIC (SELECT
# MAGIC
# MAGIC     COALESCE
# MAGIC     (nineten.form_id ,
# MAGIC     ninehundred.form_id) AS Form_ID,
# MAGIC       COALESCE
# MAGIC     (nineten.tenant_acn ,
# MAGIC     ninehundred.tenant_acn) AS tenant_acn,
# MAGIC               COALESCE
# MAGIC     (nineten.tenant_company_name, ninehundred.tenant_company_name, nineten.Parties_Tenant_Name_Address_ABN ,
# MAGIC     ninehundred.Parties_Tenant_Name_Address_ABN) AS Parties_Tenant_Name_Address_ABN,
# MAGIC         COALESCE
# MAGIC     (nineten.Principal_ABN ,
# MAGIC     ninehundred.Principal_ABN) AS Principal_ABN,
# MAGIC           COALESCE
# MAGIC     (nineten.Principal_ACN ,
# MAGIC     ninehundred.Principal_ACN) AS Principal_ACN,
# MAGIC               COALESCE
# MAGIC     (nineten.Parties_Landlord_Name_Address_ABN ,
# MAGIC     ninehundred.Parties_Landlord_Name_Address_ABN) AS Parties_Landlord_Name_Address_ABN
# MAGIC
# MAGIC FROM
# MAGIC    rei_nsw_910 nineten
# MAGIC FULL OUTER JOIN rei_nsw_900 as ninehundred
# MAGIC ON
# MAGIC     nineten.form_id = ninehundred.form_id
# MAGIC ), CTE2 as
# MAGIC -- --------------------------------------------------------
# MAGIC (select
# MAGIC
# MAGIC main.form_id,
# MAGIC CASE WHEN LENGTH(REGEXP_REPLACE(
# MAGIC       COALESCE( 
# MAGIC main.tenant_acn,
# MAGIC main.Parties_Tenant_Name_Address_ABN
# MAGIC       ),
# MAGIC       '[^0-9]', '')) BETWEEN 9 AND 11
# MAGIC       then
# MAGIC     REGEXP_REPLACE(
# MAGIC       COALESCE( 
# MAGIC main.Tenant_ACN,
# MAGIC main.Parties_Tenant_Name_Address_ABN
# MAGIC       ),
# MAGIC       '[^0-9]', '')
# MAGIC else NULL
# MAGIC end AS extracted_tenant_numbers,
# MAGIC
# MAGIC CASE WHEN LENGTH(REGEXP_REPLACE(
# MAGIC       COALESCE( 
# MAGIC main.Principal_ACN,main.Principal_ABN,
# MAGIC main.Parties_Landlord_Name_Address_ABN
# MAGIC       ),
# MAGIC       '[^0-9]', '')) BETWEEN 9 AND 11
# MAGIC       then
# MAGIC     REGEXP_REPLACE(
# MAGIC       COALESCE( 
# MAGIC main.Principal_ACN,
# MAGIC main.Parties_Landlord_Name_Address_ABN
# MAGIC       ),
# MAGIC       '[^0-9]', '')
# MAGIC else NULL
# MAGIC end AS extracted_lessor_numbers
# MAGIC
# MAGIC   FROM 
# MAGIC  CTE as main
# MAGIC )
# MAGIC
# MAGIC Select
# MAGIC cte.form_id,
# MAGIC Parties_Tenant_Name_Address_ABN,
# MAGIC Parties_Landlord_Name_Address_ABN,
# MAGIC CASE WHEN LENGTH(extracted_lessor_numbers) = 11 THEN
# MAGIC   regexp_replace(CAST(extracted_lessor_numbers AS STRING), '(\d{2})(\d{3})(\d{3})(\d{3})', '$1 $2 $3 $4') 
# MAGIC   else NULL
# MAGIC   end AS Lessor_ABN,
# MAGIC CASE WHEN LENGTH(extracted_lessor_numbers) = 9 THEN
# MAGIC   regexp_replace(CAST(extracted_lessor_numbers AS STRING), '(\d{3})(\d{3})(\d{3})', '$1 $2 $3') 
# MAGIC   else null
# MAGIC   end AS Lessor_ACN,
# MAGIC CASE WHEN LENGTH(extracted_tenant_numbers) = 11 THEN
# MAGIC   regexp_replace(CAST(extracted_tenant_numbers AS STRING), '(\d{2})(\d{3})(\d{3})(\d{3})', '$1 $2 $3 $4') 
# MAGIC   else NULL
# MAGIC   end AS Lessee_ABN,
# MAGIC CASE WHEN LENGTH(extracted_tenant_numbers) = 9 THEN
# MAGIC   regexp_replace(CAST(extracted_tenant_numbers AS STRING), '(\d{3})(\d{3})(\d{3})', '$1 $2 $3') 
# MAGIC   else null
# MAGIC   end AS Lessee_ACN
# MAGIC
# MAGIC FROM CTE2
# MAGIC LEFT JOIN CTE ON CTE.Form_ID = CTE2.form_id
# MAGIC )
# MAGIC

# COMMAND ----------

# Import necessary modules
from pyspark.sql import SparkSession
from pyspark.sql.functions import udf
from pyspark.sql.types import IntegerType
import importlib

# Import UDF functions from modules
# import spacy_entity_extraction
import udf_total_term
import udf_total_further_term

# Initialize Spark session
spark = SparkSession.builder.appName("FactLeaseTransform").getOrCreate()

# Register UDF functions
spark.udf.register("extract_total_term", udf_total_term.extract_total_term, IntegerType())
spark.udf.register("extract_total_further_term", udf_total_further_term.extract_total_further_term, IntegerType())

# COMMAND ----------

# MAGIC %md
# MAGIC **Creating reinsw_rent_amount View**
# MAGIC
# MAGIC The temporary view `reinsw_rent_amount` is created with the intent to clean and standardize the rent amount data. 

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE OR REPLACE TEMP VIEW reinsw_rent_amount as
# MAGIC (WITH CTE AS 
# MAGIC (SELECT 
# MAGIC     COALESCE
# MAGIC     (nineten.form_id ,
# MAGIC     ninehundred.form_id) AS Form_ID,
# MAGIC     COALESCE
# MAGIC     (nineten.Rent_Frequency ,
# MAGIC     ninehundred.Rent_Frequency) AS Rent_Frequency,
# MAGIC     COALESCE
# MAGIC     (nineten.rent_amount ,
# MAGIC     ninehundred.rent_amount) AS Rent_amount,
# MAGIC     COALESCE
# MAGIC     (nineten.Permitted_Use ,
# MAGIC     ninehundred.Permitted_Use) AS Permitted_Use
# MAGIC     
# MAGIC
# MAGIC FROM
# MAGIC    rei_nsw_910 nineten
# MAGIC FULL OUTER JOIN rei_nsw_900 as ninehundred
# MAGIC ON
# MAGIC     nineten.form_id = ninehundred.form_id
# MAGIC )
# MAGIC
# MAGIC SELECT
# MAGIC main.form_id,
# MAGIC main.Rent_amount,
# MAGIC main.Rent_Frequency,
# MAGIC main.Permitted_Use,
# MAGIC     CASE
# MAGIC     WHEN LOWER(TRIM(main.Permitted_Use)) LIKE "%storage%" OR LOWER(TRIM(main.Permitted_Use)) LIKE "%car%" OR LOWER(TRIM(main.Permitted_Use)) LIKE "%garage%" THEN NULL
# MAGIC     WHEN LOWER(TRIM(main.Rent_Frequency)) LIKE '%week%' AND 48 * CAST(REPLACE(REGEXP_EXTRACT(main.rent_amount, '([0-9,.]+)'), ',', '') AS INTEGER) > 2000
# MAGIC     THEN ROUND(48 * CAST(REPLACE(REGEXP_EXTRACT(main.rent_amount, '([0-9,.]+)'), ',', '') AS INTEGER), 1)
# MAGIC
# MAGIC     WHEN LOWER(TRIM(main.Rent_Frequency)) LIKE '%month%' AND 12 * CAST(REPLACE(REGEXP_EXTRACT(main.rent_amount, '([0-9,.]+)'), ',', '') AS INTEGER) > 2000
# MAGIC     THEN ROUND(12 * CAST(REPLACE(REGEXP_EXTRACT(main.rent_amount, '([0-9,.]+)'), ',', '') AS INTEGER), 1)
# MAGIC
# MAGIC     WHEN (LOWER(TRIM(main.Rent_Frequency)) LIKE '%year%' OR LOWER(TRIM(main.Rent_Frequency)) LIKE '%annum%') AND CAST(REPLACE(REGEXP_EXTRACT(main.rent_amount, '([0-9,.]+)'), ',', '') AS INTEGER) > 2000
# MAGIC     THEN ROUND(CAST(REPLACE(REGEXP_EXTRACT(main.rent_amount, '([0-9,.]+)'), ',', '') AS INTEGER), 1)
# MAGIC
# MAGIC     ELSE NULL
# MAGIC     
# MAGIC END  AS FaceRentAnnual
# MAGIC     -- CAST(REPLACE(REGEXP_EXTRACT(rent_amount, '([0-9,]+\\.?[0-9]*)', 1), ',', '') AS FLOAT) as rent_amount,
# MAGIC     --    CAST(REPLACE(REGEXP_REPLACE(rent_amount, '[^0-9.,]', ''), ',', '') AS INTEGER) AS formatted_number,
# MAGIC
# MAGIC     -- CASE 
# MAGIC     --     WHEN regexp(rent_amount, '.*\\d+.*') THEN regexp_extract(rent_amount, '(\\d+)', 1)
# MAGIC     --     ELSE NULL
# MAGIC     -- END AS extracted_number
# MAGIC
# MAGIC  
# MAGIC    FROM
# MAGIC CTE AS main)

# COMMAND ----------

# MAGIC %md
# MAGIC **Creating reinsw_term_dates View**
# MAGIC
# MAGIC The temporary view `reinsw_term_dates` which organizes and standardizes the term dates from the `reinsw_main` table.

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE OR REPLACE TEMP VIEW reinsw_term_dates as
# MAGIC with cte as (
# MAGIC select 
# MAGIC main.created,
# MAGIC main.form_id,
# MAGIC main.rent_commencement_date,
# MAGIC main.rent_commencement_date_2,
# MAGIC main.rent_commencement_date_3,
# MAGIC main.Term_End_Date_Year,
# MAGIC main.Term_End_Date_Month,
# MAGIC main.Term_End_Date_Day,
# MAGIC main.Term_Duration,
# MAGIC CASE 
# MAGIC     WHEN main.rent_commencement_date IS NOT NULL 
# MAGIC          AND main.rent_commencement_date_2 IS NOT NULL 
# MAGIC          AND main.rent_commencement_date_3 IS NOT NULL 
# MAGIC     THEN CAST(CONCAT_WS('-', 
# MAGIC             main.rent_commencement_date_3,
# MAGIC             main.rent_commencement_date_2,
# MAGIC             main.rent_commencement_date
# MAGIC          ) as date)
# MAGIC     WHEN main.Term_Start_Date_Year IS NOT NULL 
# MAGIC          AND main.Term_Start_Date_Month IS NOT NULL 
# MAGIC          AND main.Term_Start_Date_Day IS NOT NULL 
# MAGIC     THEN CAST(CONCAT_WS('-', 
# MAGIC             main.Term_Start_Date_Year,
# MAGIC             main.Term_Start_Date_Month,
# MAGIC             main.Term_Start_Date_Day
# MAGIC          ) as date)
# MAGIC     ELSE NULL
# MAGIC END AS CommencingDate,
# MAGIC     CASE 
# MAGIC         WHEN main.Term_End_Date_Year IS NOT NULL 
# MAGIC              AND main.Term_End_Date_Month IS NOT NULL 
# MAGIC              AND main.Term_End_Date_Day IS NOT NULL 
# MAGIC     THEN CAST(CONCAT_WS('-', 
# MAGIC         CAST(main.Term_End_Date_Year AS STRING),
# MAGIC         CAST(main.Term_End_Date_Month AS STRING),
# MAGIC         CAST(main.Term_End_Date_Day AS STRING)) as date)
# MAGIC      ELSE NULL
# MAGIC     END AS ExpiryDate
# MAGIC from `arealytics-databricks_unity_catalog`.arealyticstrusted.reinsw_leasesnapshot as main
# MAGIC
# MAGIC ),
# MAGIC
# MAGIC CommencingDate_cte as (
# MAGIC Select  
# MAGIC form_id,
# MAGIC ExpiryDate,
# MAGIC CommencingDate as CommencingDate_org,
# MAGIC Term_Duration,
# MAGIC created,
# MAGIC CASE
# MAGIC         -- Calculate Commencement Date if Expiry is NOT NULL and Commencement is NULL
# MAGIC         WHEN ExpiryDate IS NOT NULL AND CommencingDate IS NULL THEN
# MAGIC             date_format(DATE_ADD(ExpiryDate, -729), 'yyyy-MM-dd')
# MAGIC         -- Calculate Commencement Date if Expiry is NULL and Commencement is NULL
# MAGIC         WHEN ExpiryDate IS NULL AND CommencingDate IS NULL THEN
# MAGIC            date_format(DATE_ADD(DATE_ADD(to_date(Created), 30), 1), 'yyyy-MM-dd')
# MAGIC         -- Keep existing Commencement Date if it's not NULL
# MAGIC         WHEN CommencingDate IS NULL OR (ExpiryDate IS NOT NULL AND ExpiryDate <= CommencingDate) THEN
# MAGIC             date_format(DATE_ADD(DATE_ADD(to_date(Created), 30), 1), 'yyyy-MM-dd')
# MAGIC         ELSE
# MAGIC           date_format(CAST(CommencingDate as date), 'yyyy-MM-dd')
# MAGIC     END AS CommencingDate
# MAGIC from cte
# MAGIC ),
# MAGIC
# MAGIC ExpiryDate_cte as (
# MAGIC Select  
# MAGIC form_id,
# MAGIC ExpiryDate as Expiry_Org,
# MAGIC CommencingDate_org,
# MAGIC created,
# MAGIC Term_Duration,
# MAGIC     CASE
# MAGIC         -- Calculate Expiry Date if both Expiry and Commencement are NULL
# MAGIC         WHEN ExpiryDate IS NULL AND CommencingDate IS NULL THEN
# MAGIC             DATE_FORMAT(DATE_ADD(to_date(Created), 30 + 730), 'yyyy-MM-dd')
# MAGIC         -- Calculate Expiry Date if Commencement is NOT NULL and Expiry is NULL
# MAGIC         WHEN CommencingDate IS NOT NULL AND ExpiryDate IS NULL THEN
# MAGIC             DATE_FORMAT(DATE_ADD(CommencingDate, 730), 'yyyy-MM-dd')
# MAGIC         -- Calculate Expiry Date based on term duration if Expiry is NULL or Expiry <= Commencing
# MAGIC         WHEN ExpiryDate IS NULL OR ExpiryDate <= CommencingDate THEN
# MAGIC             DATE_FORMAT(
# MAGIC                 CASE
# MAGIC                     WHEN extract_total_term(Term_Duration) > 0 THEN
# MAGIC                         ADD_MONTHS(CAST(CommencingDate AS DATE), extract_total_term(Term_Duration))
# MAGIC                     ELSE
# MAGIC                         -- Fallback to a default calculation based on the created date if Term_Duration is not valid
# MAGIC                         DATE_FORMAT(DATE_ADD(CommencingDate, 730), 'yyyy-MM-dd') -- DEFAULT_TERM_DURATION
# MAGIC                 END,
# MAGIC             'yyyy-MM-dd')
# MAGIC         ELSE
# MAGIC             DATE_FORMAT(CAST(ExpiryDate AS DATE), 'yyyy-MM-dd')
# MAGIC     END AS ExpiryDate,
# MAGIC CommencingDate
# MAGIC from CommencingDate_cte
# MAGIC )
# MAGIC
# MAGIC select 
# MAGIC *,
# MAGIC CASE 
# MAGIC         WHEN CommencingDate IS NOT NULL AND CommencingDate_org is null then 1
# MAGIC         WHEN DATE_FORMAT(CAST(CommencingDate AS DATE), 'yyyy-MM-dd') != DATE_FORMAT(CAST(CommencingDate_org AS DATE), 'yyyy-MM-dd') then 1
# MAGIC         ELSE 0
# MAGIC END AS Commencing_Estimated_Flag,
# MAGIC Case
# MAGIC         WHEN ExpiryDate IS NOT NULL AND Expiry_Org is null then 1
# MAGIC         WHEN DATE_FORMAT(CAST(ExpiryDate AS DATE), 'yyyy-MM-dd') != DATE_FORMAT(CAST(Expiry_Org AS DATE), 'yyyy-MM-dd') then 1
# MAGIC         ELSE 0
# MAGIC     END AS ExpiryDate_Estimated_Flag
# MAGIC from ExpiryDate_cte

# COMMAND ----------

# MAGIC %md
# MAGIC **Creating reinsw_suite View**
# MAGIC
# MAGIC The temporary view `reinsw_suite` which focuses on extracting suite numbers and types from the property address fields.

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE OR REPLACE TEMP VIEW reinsw_suite AS
# MAGIC select 
# MAGIC ma.form_id
# MAGIC ,premises_addressfull
# MAGIC ,Premises_Title
# MAGIC ,geo.unit
# MAGIC ,CASE 
# MAGIC     WHEN Geo.unit IS NULL THEN
# MAGIC         CASE
# MAGIC             -- Extracts the first number sequence before any slash, if present
# MAGIC             WHEN premises_addressfull REGEXP '\\b\\d+(?=/)' THEN 
# MAGIC                 REGEXP_SUBSTR(premises_addressfull, '\\b\\d+(?=/)')
# MAGIC
# MAGIC             -- For specific address types like Suite, Warehouse, etc., including plural forms and variations
# MAGIC             WHEN lower(premises_addressfull) REGEXP '\\b(suite|suites|warehouse|warehouses|building|buildings|level|levels|lot|lots|no\\.?)\\s*\\d+[A-Za-z0-9-]*' THEN 
# MAGIC                 REGEXP_SUBSTR(lower(premises_addressfull), '\\b(suite|suites|warehouse|warehouses|building|buildings|level|levels|lot|lots|no\\.?)\\s*\\d+[A-Za-z0-9-]*')
# MAGIC
# MAGIC             -- For address types with verbs like "shops", "sheds", "bays", "offices", "units", "lots", "studios", "garages"
# MAGIC             WHEN lower(premises_addressfull) REGEXP '\\b(shop|shops|shed|sheds|bay|bays|office|offices|unit|units|lot|lots|studio|studios|garage|garages)\\s*(\\d+\\s*&\\s*\\d+|\\d+[A-Za-z0-9-]*)' THEN 
# MAGIC                 REGEXP_SUBSTR(lower(premises_addressfull), '\\b(shop|shops|shed|sheds|bay|bays|office|offices|unit|units|lot|lots|studio|studios|garage|garages)\\s*(\\d+\\s*&\\s*\\d+|\\d+[A-Za-z0-9-]*)')
# MAGIC
# MAGIC             ELSE NULL
# MAGIC         END
# MAGIC     ELSE
# MAGIC         Geo.unit
# MAGIC END AS Suite
# MAGIC FROM
# MAGIC     `arealytics-databricks_unity_catalog`.arealyticstrusted.reinsw_leasesnapshot as ma
# MAGIC
# MAGIC LEFT join `arealytics-databricks_unity_catalog`.arealyticstrusted.reinsw_geocoded_data as geo
# MAGIC on ma.form_id = geo.id

# COMMAND ----------

# MAGIC %md
# MAGIC **Creating reinsw_bankGuarantee View**
# MAGIC
# MAGIC The temporary view reinsw_bankGuarantee which focuses on extracting bank guarantee amount from the bond_amountfields.

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE OR REPLACE TEMP VIEW reinsw_bankGuarantee AS
# MAGIC SELECT
# MAGIC     main.form_id,
# MAGIC     bond_amount,
# MAGIC     CASE
# MAGIC         -- Extract amounts with a dollar sign and remove the dollar sign
# MAGIC         WHEN REGEXP_SUBSTR(TRIM(bond_amount), '\\$[0-9]+(,[0-9]{3})*(\.[0-9]+)?') != '' THEN
# MAGIC             REGEXP_REPLACE(REGEXP_SUBSTR(TRIM(bond_amount), '\\$[0-9]+(,[0-9]{3})*(\.[0-9]+)?'), '\\$', '')
# MAGIC         -- Extract amounts without a dollar sign
# MAGIC         ELSE
# MAGIC             REGEXP_SUBSTR(TRIM(bond_amount), '(?<!\\d)[0-9]{1,3}(,[0-9]{3})*(\.[0-9]+)?(?!\\d)')
# MAGIC     END AS extracted_bond
# MAGIC FROM
# MAGIC      `arealytics-databricks_unity_catalog`.arealyticstrusted.reinsw_leasesnapshot AS main
# MAGIC WHERE
# MAGIC     main.bond_amount IS NOT NULL
# MAGIC     OR main.bond_amount NOT IN ('nil', 'na', 'not applicable')

# COMMAND ----------

# MAGIC %md
# MAGIC #Creating reinsw_final View#
# MAGIC
# MAGIC Creates or replaces the `arealytics-databricks_unity_catalog.arealyticstrusted.reinsw_final` table. It selects and transforms data from multiple sources into a structured format.

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace table `arealytics-databricks_unity_catalog`.arealyticstrusted.reinsw_final as
# MAGIC SELECT
# MAGIC     Pid.PropertyID AS PropertyID,
# MAGIC     Cast(NULL as string) AS PropertyName,
# MAGIC     Pid.formatted_address AS Address,
# MAGIC     Pid.suburb AS City,
# MAGIC     Cast(NULL as string) AS State,
# MAGIC     Pid.postal_code AS Zip,
# MAGIC     CASE 
# MAGIC         WHEN main.Tenant_Company_Name IS NOT NULL THEN INITCAP(main.Tenant_Company_Name)
# MAGIC     WHEN main.Parties_Tenant_Name_Address_ABN IS NOT NULL THEN INITCAP(main.Parties_Tenant_Name_Address_ABN)
# MAGIC         WHEN main.Tenant_NameFull IS NOT NULL THEN INITCAP(main.Tenant_NameFull)
# MAGIC
# MAGIC         ELSE "Unknown Tenant"
# MAGIC     END AS AltTenantName,
# MAGIC     CASE 
# MAGIC         WHEN REGEXP_EXTRACT(main.premises_addressfull, 'Level\\s*(\\d+)', 1) IS NOT NULL 
# MAGIC         AND TRIM(REGEXP_EXTRACT(main.premises_addressfull, 'Level\\s*(\\d+)', 1)) != '' 
# MAGIC         THEN REGEXP_EXTRACT(main.premises_addressfull, 'Level\\s*(\\d+)', 1)
# MAGIC         ELSE NULL
# MAGIC     END AS Level,
# MAGIC     CASE    
# MAGIC         WHEN su.suite IS NOT NULL THEN REGEXP_REPLACE(REGEXP_SUBSTR(su.suite, '\\b(\\d+\\s*&\\s*\\d+|\\d+)'), '\\s*&\\s*', '-')
# MAGIC         ELSE NULL
# MAGIC     END AS Suite,
# MAGIC     DATE_FORMAT(CAST(td.CommencingDate as date), 'dd/MM/yyyy') AS CommencingDate,
# MAGIC     DATE_FORMAT(CAST(td.ExpiryDate AS DATE), 'dd/MM/yyyy') AS ExpiryDate,
# MAGIC     CASE WHEN LOWER(TRIM(ra.Permitted_Use)) LIKE "%storage%" OR LOWER(TRIM(ra.Permitted_Use)) LIKE "%car%" OR LOWER(TRIM(ra.Permitted_Use)) LIKE "%garage%" THEN NULL
# MAGIC     WHEN LOWER(TRIM(ra.FaceRentAnnual)) BETWEEN 2000 AND 1500000  THEN ra.FaceRentAnnual
# MAGIC     
# MAGIC     ELSE NULL
# MAGIC     END as FaceRentAnnual,
# MAGIC     -- CASE
# MAGIC     -- WHEN ra.rent_amount IS NOT NULL THEN
# MAGIC     --     CASE
# MAGIC     --         WHEN main.rent_frequency ILIKE '%annum%' AND ra.rent_amount BETWEEN 2000 AND 1500000 THEN CEIL(ra.rent_amount)
# MAGIC     --         WHEN main.rent_frequency ILIKE '%month%' AND (ra.rent_amount * 12) BETWEEN 2000 AND 1500000 THEN CEIL(ra.rent_amount * 12)
# MAGIC     --         WHEN main.rent_frequency ILIKE '%week%' AND (ra.rent_amount * 48) BETWEEN 2000 AND 1500000 THEN CEIL(ra.rent_amount * 48)
# MAGIC     --         ELSE NULL
# MAGIC     --     END
# MAGIC     -- ELSE NULL
# MAGIC     -- END AS FaceRentAnnual,
# MAGIC
# MAGIC -- CASE
# MAGIC --     WHEN Outgoings_Checkbox = 'No' AND 
# MAGIC --     (lower(trim(outgoings_percentage_increases)) LIKE '%nil%' OR
# MAGIC --          lower(trim(outgoings_percentage_increases)) LIKE '%not applicable%' OR
# MAGIC --          lower(trim(outgoings_percentage_increases)) LIKE '%n/a%' OR
# MAGIC --          lower(trim(outgoings_percentage_increases)) = 'na' OR
# MAGIC --          lower(trim(outgoings_percentage_increases)) LIKE '%zero%') THEN NULL
# MAGIC --     WHEN Outgoings_Checkbox = 'Yes' AND 
# MAGIC --         (lower(trim(outgoings_percentage_to_be_paid)) LIKE '%nil%' OR
# MAGIC --          lower(trim(outgoings_percentage_to_be_paid)) LIKE '%not applicable%' OR
# MAGIC --          lower(trim(outgoings_percentage_to_be_paid)) LIKE '%n/a%' OR
# MAGIC --          lower(trim(outgoings_percentage_to_be_paid)) = 'na' OR
# MAGIC --          lower(trim(outgoings_percentage_to_be_paid)) LIKE '%zero%') THEN NULL
# MAGIC --     WHEN Outgoings_Checkbox = 'Other' AND 
# MAGIC --         (lower(trim(outgoings_special_conditions)) LIKE '%nil%' OR
# MAGIC --          lower(trim(outgoings_special_conditions)) LIKE '%not applicable%' OR
# MAGIC --          lower(trim(outgoings_special_conditions)) LIKE '%n/a%' OR
# MAGIC --          lower(trim(outgoings_special_conditions)) = 'na' OR
# MAGIC --          lower(trim(outgoings_special_conditions)) LIKE '%zero%') THEN NULL
# MAGIC --     WHEN Outgoings_Checkbox = 'No' THEN 10
# MAGIC --     WHEN Outgoings_Checkbox = 'Yes' THEN 10
# MAGIC --     WHEN Outgoings_Checkbox = 'Other' THEN 10
# MAGIC -- ELSE NULL
# MAGIC -- END AS LeaseRateType1,
# MAGIC CASE 
# MAGIC     WHEN LOWER(TRIM(Outgoings_Checkbox)) = 'off' THEN 4
# MAGIC     WHEN LOWER(TRIM(Outgoings_Checkbox)) = 'yes' THEN 10
# MAGIC ELSE NULL
# MAGIC END AS LeaseRateType,
# MAGIC     Cast(NULL as string) AS OutgoingsPerSqm,
# MAGIC CASE 
# MAGIC     WHEN CAST(REGEXP_EXTRACT(main.Rent_Review_Fixed_Percentage , r'(\d+(\.\d+)?)') AS INTEGER) BETWEEN 2 AND 9 THEN CAST(REGEXP_EXTRACT(main.Rent_Review_Fixed_Percentage, r'(\d+(\.\d+)?)') AS INTEGER)
# MAGIC         ELSE NULL
# MAGIC END AS EscalationRate,
# MAGIC     CASE 
# MAGIC         WHEN td.ExpiryDate IS NOT NULL AND td.CommencingDate IS NOT NULL THEN
# MAGIC             CASE 
# MAGIC                 WHEN DATE_FORMAT(CAST(td.ExpiryDate AS DATE), 'yyyy-MM-dd') <= DATE_FORMAT(CAST(td.CommencingDate AS DATE), 'yyyy-MM-dd')
# MAGIC                     THEN 
# MAGIC                     extract_total_term(main.Term_Duration) 
# MAGIC                 ELSE
# MAGIC                     CEIL(MONTHS_BETWEEN(DATE_FORMAT(CAST(td.ExpiryDate AS DATE), 'yyyy-MM-dd'), DATE_FORMAT(CAST(td.CommencingDate AS DATE), 'yyyy-MM-dd')))
# MAGIC             END
# MAGIC         WHEN extract_total_term(main.Term_Duration) = 0 THEN NULL
# MAGIC         ELSE extract_total_term(main.Term_Duration)
# MAGIC     END AS TermMonths,
# MAGIC CASE 
# MAGIC     WHEN extract_total_further_term(main.option_term_renewal) = 0 THEN NULL
# MAGIC     ELSE extract_total_further_term(main.option_term_renewal)
# MAGIC END AS RenewalOptionsNoOfMonths,
# MAGIC     Cast(NULL as string) AS RecordedDate,
# MAGIC     Cast(NULL as string) AS LeaseSublease,
# MAGIC     -- 1 AS LeaseSublease,
# MAGIC     1 AS LeaseTransType,
# MAGIC
# MAGIC
# MAGIC
# MAGIC     -- COALESCE(CASE
# MAGIC     --     WHEN Outgoings_Checkbox = 'No' AND lower(trim(outgoings_percentage_increases)) IN ('nil', 'not applicable', 'n/a', 'na') THEN NULL
# MAGIC     --     WHEN Outgoings_Checkbox = 'Yes' AND lower(trim(outgoings_percentage_to_be_paid)) IN ('nil', 'not applicable', 'n/a', 'na') THEN NULL
# MAGIC     --     WHEN Outgoings_Checkbox = 'Other' AND lower(trim(outgoings_special_conditions)) IN ('nil', 'not applicable', 'n/a', 'na') THEN NULL
# MAGIC     --     WHEN Outgoings_Checkbox = 'No' THEN '\nOutgoings: ' || lower(trim(outgoings_percentage_increases))
# MAGIC     --     WHEN Outgoings_Checkbox = 'Yes' THEN '\nOutgoings: ' || lower(trim(outgoings_percentage_to_be_paid))
# MAGIC     --     WHEN Outgoings_Checkbox = 'Other' THEN '\nOutgoings: ' || lower(trim(outgoings_special_conditions))
# MAGIC
# MAGIC
# MAGIC   IF(
# MAGIC   main.Parties_Landlord_Name_Address_ABN IS NULL AND --LESSOR DEETS
# MAGIC   main.Principal_Director_NameFull_Signature IS NULL AND
# MAGIC   main.Principal2_Director_NameFull_Signature IS NULL AND
# MAGIC   main.Principal_NameFull_Signature IS NULL AND
# MAGIC   main.Principal2_Director_NameFull_Signature IS NULL AND
# MAGIC   main.Principal2_NameFull_Signature IS NULL AND
# MAGIC   acn.Lessor_ABN IS NULL AND
# MAGIC   acn.Lessee_ABN IS NULL AND -- LESSEE DEETS
# MAGIC   main.Parties_Tenant_Name_Address_ABN IS NULL AND
# MAGIC   main.Tenant_Director_NameFull_Signature IS NULL AND
# MAGIC   main.Tenant2_Director_NameFull_Signature IS NULL AND
# MAGIC   main.Tenant_NameFull_Signature IS NULL AND
# MAGIC   main.Tenant2_NameFull_Signature IS NULL,
# MAGIC   NULL,
# MAGIC   CONCAT(
# MAGIC     IF(main.Parties_Landlord_Name_Address_ABN IS NOT NULL, CONCAT('Lessor Name: [', INITCAP(main.Parties_Landlord_Name_Address_ABN), ']'), ''), 
# MAGIC     IF(main.Parties_Landlord_Name_Address_ABN IS NOT NULL, '\n', ''),
# MAGIC     IF(acn.lessor_abn IS NOT NULL, CONCAT('Lessor ABN: [', INITCAP(acn.lessor_abn), ']'), ''), 
# MAGIC     IF(acn.lessor_abn IS NOT NULL, '\n', ''),
# MAGIC     IF(acn.lessor_acn IS NOT NULL, CONCAT('Lessor ACN: [', INITCAP(acn.lessor_acn), ']'), ''), 
# MAGIC     IF(acn.lessor_acn IS NOT NULL, '\n', ''),
# MAGIC     IF(main.Principal_Director_NameFull_Signature IS NOT NULL OR main.Principal2_Director_NameFull_Signature IS NOT NULL OR main.Principal_NameFull_Signature IS NOT NULL OR main.Principal2_NameFull_Signature IS NOT NULL, CONCAT('Lessor Executor: [', COALESCE(INITCAP(main.Principal_Director_NameFull_Signature),INITCAP(main.Principal2_Director_NameFull_Signature),INITCAP(main.Principal_NameFull_Signature),INITCAP(main.Principal2_NameFull_Signature)), ']'), ''), 
# MAGIC     IF(main.Principal_Director_NameFull_Signature IS NOT NULL OR main.Principal2_Director_NameFull_Signature IS NOT NULL OR main.Principal_NameFull_Signature IS NOT NULL OR main.Principal2_NameFull_Signature IS NOT NULL, '\n', ''),
# MAGIC     -- LESSOR DEETS
# MAGIC     IF(main.Parties_Tenant_Name_Address_ABN IS NOT NULL, CONCAT('Lessee Name: [', INITCAP(main.Parties_Tenant_Name_Address_ABN), ']'), ''), 
# MAGIC     IF(main.Parties_Tenant_Name_Address_ABN IS NOT NULL, '\n', ''),
# MAGIC     IF(acn.Lessee_abn IS NOT NULL, CONCAT('Lessee ABN: [', INITCAP(acn.Lessee_abn), ']'), ''), 
# MAGIC     IF(acn.Lessee_abn IS NOT NULL, '\n', ''),
# MAGIC     IF(acn.Lessee_acn IS NOT NULL, CONCAT('Lessee ACN: [', INITCAP(acn.Lessee_acn), ']'), ''), 
# MAGIC     IF(acn.Lessee_acn IS NOT NULL, '\n', ''),
# MAGIC     IF(main.Tenant_Director_NameFull_Signature IS NOT NULL OR main.Tenant2_Director_NameFull_Signature IS NOT NULL OR main.Tenant_NameFull_Signature IS NOT NULL OR main.Tenant2_NameFull_Signature IS NOT NULL, CONCAT('Lessee Executor: [', COALESCE(INITCAP(main.Tenant_Director_NameFull_Signature),INITCAP(main.Tenant2_Director_NameFull_Signature),INITCAP(main.Tenant_NameFull_Signature),INITCAP(main.Tenant2_NameFull_Signature)), ']'), ''), 
# MAGIC     IF(main.Parties_Tenant_Name_Address_ABN IS NOT NULL  OR main.Tenant_Director_NameFull_Signature IS NOT NULL OR acn.Lessee_ACN IS NOT NULL OR main.Tenant2_Director_NameFull_Signature IS NOT NULL OR main.Tenant_NameFull_Signature IS NOT NULL OR main.Tenant2_NameFull_Signature IS NOT NULL, '\n', '')
# MAGIC
# MAGIC
# MAGIC
# MAGIC   )
# MAGIC ) AS TransactionComments,
# MAGIC
# MAGIC
# MAGIC     -- CASE
# MAGIC     --     WHEN main.Parties_Landlord_Name_Address_ABN IS NOT NULL
# MAGIC     --         THEN 'Lessor: ' || main.Parties_Landlord_Name_Address_ABN
# MAGIC     --     WHEN main.Principal_Director_NameFull_Signature IS NOT NULL
# MAGIC     --         OR main.Principal2_Director_NameFull_Signature IS NOT NULL
# MAGIC     --         OR main.Principal_NameFull_Signature IS NOT NULL
# MAGIC     --         OR main.Principal2_NameFull_Signature IS NOT NULL
# MAGIC     --         THEN 'Lessor Executor: ' || COALESCE(main.Principal_Director_NameFull_Signature,
# MAGIC     --                                             main.Principal2_Director_NameFull_Signature,
# MAGIC     --                                             main.Principal_NameFull_Signature,
# MAGIC     --                                             main.Principal2_NameFull_Signature)
# MAGIC     --     WHEN main.Parties_Tenant_Name_Address_ABN IS NOT NULL
# MAGIC     --         THEN 'Lessee: ' || main.Parties_Tenant_Name_Address_ABN
# MAGIC     --     WHEN main.Tenant_Director_NameFull_Signature IS NOT NULL
# MAGIC     --         OR main.Tenant2_Director_NameFull_Signature IS NOT NULL
# MAGIC     --         OR main.Tenant_NameFull_Signature IS NOT NULL
# MAGIC     --         OR main.Tenant2_NameFull_Signature IS NOT NULL
# MAGIC     --         THEN 'Lessee Executor: ' || COALESCE(main.Tenant_Director_NameFull_Signature,
# MAGIC     --                                             main.Tenant2_Director_NameFull_Signature,
# MAGIC     --                                             main.Tenant_NameFull_Signature,
# MAGIC     --                                             main.Tenant2_NameFull_Signature)
# MAGIC     --     ELSE 'Unknown'
# MAGIC     -- END ||
# MAGIC     -- COALESCE(CASE
# MAGIC     --     WHEN Outgoings_Checkbox = 'No' AND lower(trim(outgoings_percentage_increases)) IN ('nil', 'not applicable', 'n/a', 'na') THEN NULL
# MAGIC     --     WHEN Outgoings_Checkbox = 'Yes' AND lower(trim(outgoings_percentage_to_be_paid)) IN ('nil', 'not applicable', 'n/a', 'na') THEN NULL
# MAGIC     --     WHEN Outgoings_Checkbox = 'Other' AND lower(trim(outgoings_special_conditions)) IN ('nil', 'not applicable', 'n/a', 'na') THEN NULL
# MAGIC     --     WHEN Outgoings_Checkbox = 'No' THEN '\nOutgoings: ' || lower(trim(outgoings_percentage_increases))
# MAGIC     --     WHEN Outgoings_Checkbox = 'Yes' THEN '\nOutgoings: ' || lower(trim(outgoings_percentage_to_be_paid))
# MAGIC     --     WHEN Outgoings_Checkbox = 'Other' THEN '\nOutgoings: ' || lower(trim(outgoings_special_conditions))
# MAGIC     -- END, '') AS TransactionComments,
# MAGIC     Cast(NULL as string) AS SuiteComments,
# MAGIC     Cast(NULL as string) AS ExecutionDate, 
# MAGIC     CASE 
# MAGIC         WHEN main.permitted_use_classification IN ('Office, Retail', 'Unclassified') THEN 
# MAGIC             CASE 
# MAGIC                 WHEN pd.PropertyUse = 'Office' THEN 9
# MAGIC                 WHEN pd.PropertyUse = 'Industrial' THEN 8
# MAGIC                 WHEN pd.PropertyUse = 'Retail' OR pd.PropertyUse IN ('Land', 'Multi-Family Housing') THEN 7
# MAGIC                 ELSE 0
# MAGIC             END
# MAGIC         WHEN main.permitted_use_classification = 'Office' THEN 9
# MAGIC         WHEN main.permitted_use_classification = 'Industrial' THEN 8
# MAGIC         WHEN main.permitted_use_classification = 'Retail' THEN 7
# MAGIC         ELSE 0
# MAGIC     END AS SpaceGeneralUse,
# MAGIC     CASE 
# MAGIC         WHEN DATE_FORMAT(CAST(td.ExpiryDate AS DATE), 'yyyy-MM-dd') < CURRENT_DATE THEN 1 -- HISTORIC
# MAGIC         ELSE 2 -- ACTIVE
# MAGIC     END AS LeaseStatus,
# MAGIC     Cast(NULL as string) AS ConfirmationNotes,
# MAGIC     Cast(NULL as string) AS SignDate,
# MAGIC     CAST(REPLACE(REGEXP_EXTRACT(rg.extracted_bond, '([0-9,.]+)'), ',', '') AS INTEGER) AS BankGuaranteeAmount,
# MAGIC         CASE 
# MAGIC             WHEN main.rent_amount is not null and lower(trim(main.rent_amount )) like "%gst%"
# MAGIC             THEN 1
# MAGIC             ELSE 0
# MAGIC     END  AS GSTIncluded,
# MAGIC     Cast(NULL as string) AS IsCondo,
# MAGIC     Cast(NULL as string) AS Fitout,
# MAGIC     2 AS TransactionOriginationTypeID,
# MAGIC     CASE 
# MAGIC         WHEN ra.rent_amount IS NOT NULL THEN 1
# MAGIC         ELSE 0
# MAGIC     END AS IsStartingRateConfirmed,
# MAGIC     5 as ShareLevelID,
# MAGIC     CASE 
# MAGIC         WHEN td.ExpiryDate_Estimated_Flag = 1 then 0
# MAGIC         ELSE 1
# MAGIC     END AS IsExpDateConfirmed,
# MAGIC   case
# MAGIC         when (main.rent_review_cpi_cb = 'on'and main.rent_review_cpi_commencement_anniversary_cb = 'on')
# MAGIC         and (main.rent_review_fixed_percentage_cb = 'on'and main.rent_review_fixed_percentage_commencement_anniversary_cb = 'on')
# MAGIC         and (main.rent_review_market_cb = 'on'and main.rent_review_market_commencement_anniversary_cb = 'on') then 'CPI/Fixed/Market'
# MAGIC
# MAGIC         when (main.rent_review_cpi_cb = 'on'and main.rent_review_cpi_commencement_anniversary_cb = 'on')
# MAGIC         and (main.rent_review_fixed_percentage_cb = 'on'and main.rent_review_fixed_percentage_commencement_anniversary_cb = 'on') then 'CPI/Fixed'
# MAGIC
# MAGIC         when (rent_review_cpi_cb = 'on'and main.rent_review_cpi_commencement_anniversary_cb = 'on')
# MAGIC         and (main.rent_review_market_cb = 'on'and main.rent_review_market_commencement_anniversary_cb = 'on') then 'CPI/Market'
# MAGIC
# MAGIC         when (main.rent_review_fixed_percentage_cb  = 'on'and main.rent_review_fixed_percentage_commencement_anniversary_cb = 'on')
# MAGIC         and (main.rent_review_market_cb = 'on'and main.rent_review_market_commencement_anniversary_cb = 'on') then 'Fixed/Market'
# MAGIC     
# MAGIC         when (main.rent_review_cpi_cb = 'on'and main.rent_review_cpi_commencement_anniversary_cb = 'on') then 'CPI'
# MAGIC
# MAGIC         when (main.rent_review_fixed_percentage_cb = 'on'and main.rent_review_fixed_percentage_commencement_anniversary_cb = 'on') then 'Fixed'
# MAGIC         
# MAGIC         when (main.rent_review_fixed_percentage_other_cb = 'on'and main.rent_review_fixed_percentage_other_cb = 'on'or main.rent_review_fixed_amount_cb = 'on') then 'Fixed' 
# MAGIC
# MAGIC         when (main.rent_review_market_cb = 'on'and main.rent_review_market_commencement_anniversary_cb = 'on') then 'Market'
# MAGIC         else NULL
# MAGIC     end as EscalationType,
# MAGIC     CASE 
# MAGIC             WHEN TermMonths > 0 and (td.Commencing_Estimated_Flag = 0 and td.ExpiryDate_Estimated_Flag = 0) THEN 1
# MAGIC             ELSE 0
# MAGIC     END AS IsTermsConfirmed,
# MAGIC     Cast(NULL as string) AS ConfirmedTenantID,
# MAGIC     main.form_id AS DealingNumber,
# MAGIC     CASE 
# MAGIC         WHEN td.Commencing_Estimated_Flag = 1 then 0
# MAGIC         ELSE 1
# MAGIC     END AS IsOccupDateConfirmed,
# MAGIC     Cast(NULL as string) AS RentFreePeriod,
# MAGIC     Cast(NULL as string) AS LeasedSqm,
# MAGIC     Cast(NULL as string) Folio,
# MAGIC     -- Cast(NULL as string) LeaseFolio,
# MAGIC     Cast(NULL as string) AS NoticePeriodMin,
# MAGIC     Cast(NULL as string) AS NoticePeriodMax,
# MAGIC     1 as ListingTypeId,
# MAGIC     pid.latitude as Latitude,
# MAGIC pid.longitude AS Longitude,
# MAGIC CAST(NULL as string) as `Location`,
# MAGIC     Cast(NULL as string) AS StageID,
# MAGIC     Cast(NULL as string) AS Status,
# MAGIC     Cast(NULL as string) AS ExceptionReason,
# MAGIC     Cast(NULL as string) AS CreatedDate,
# MAGIC     Cast(NULL as string) AS CreatedBy,
# MAGIC     Cast(NULL as string) AS ModifiedDate,
# MAGIC     Cast(NULL as string) AS ModifiedBy,
# MAGIC     Cast(NULL as string) AS LeaseID,
# MAGIC     Cast(NULL as string) AS IsActive,
# MAGIC     Cast(NULL as string) AS BatchID,
# MAGIC     Cast(NULL as string) AS HidedBy,
# MAGIC     Cast(NULL as string) AS IsHidden ,
# MAGIC     Cast(NULL as string) AS HidedDate,
# MAGIC     Cast(NULL as string) AS HideReasonID,
# MAGIC     Cast(NULL as string) AS HideReasonComments ,
# MAGIC     Cast(NULL as string) AS SubHideReasonID ,
# MAGIC     Cast(NULL as string) AS MismatchedTaggedBy ,
# MAGIC     Cast(NULL as string) AS IsMismatched ,
# MAGIC     Cast(NULL as string) AS    UID ,
# MAGIC     Cast(NULL as string) AS Url ,
# MAGIC     Cast(NULL as string) AS AgentName1 ,
# MAGIC     Cast(NULL as string) AS AgentEmail1 ,
# MAGIC     Cast(NULL as string) AS AgentName2 ,
# MAGIC     Cast(NULL as string) AS AgentEmail2 ,
# MAGIC 34 as ProviderID,
# MAGIC  ROW_NUMBER() OVER (
# MAGIC             PARTITION BY main.tenant_company_name, main.parties_tenant_name_address_abn, main.tenant_namefull, pd.PropertyID
# MAGIC             ORDER BY main.created DESC
# MAGIC         ) AS rn
# MAGIC
# MAGIC     
# MAGIC from `arealytics-databricks_unity_catalog`.arealyticstrusted.reinsw_leasesnapshot  as main -- 54 821
# MAGIC
# MAGIC LEFT JOIN reinsw_abn_acn AS acn
# MAGIC ON acn.form_id = main.form_id
# MAGIC
# MAGIC LEFT JOIN reinsw_rent_amount AS ra -- 54 821
# MAGIC on ra.form_id = main.form_id
# MAGIC
# MAGIC LEFT JOIN reinsw_suite AS su --54 821
# MAGIC on su.form_id = main.form_id
# MAGIC
# MAGIC LEFT JOIN reinsw_term_dates AS td --54 821
# MAGIC on td.form_id = main.form_id
# MAGIC
# MAGIC LEFT JOIN reinsw_bankGuarantee AS rg 
# MAGIC on rg.form_id = main.form_id
# MAGIC
# MAGIC LEFT JOIN `arealytics-databricks_unity_catalog`.arealyticstrusted.reinsw_pid_link AS pid --54 822
# MAGIC on pid.form_id = main.form_id
# MAGIC
# MAGIC LEFT JOIN `arealytics-databricks_unity_catalog`.arealyticstrusted.property_detail as pd
# MAGIC on pid.propertyId = pd.propertyId
# MAGIC WHERE pid.postal_code in (SELECT DISTINCT Zip FROM `arealytics-databricks_unity_catalog`.arealyticstrusted.reiq_in_market_codes)
# MAGIC
# MAGIC qualify
# MAGIC
# MAGIC  ROW_NUMBER() OVER (
# MAGIC             PARTITION BY  main.tenant_company_name, main.parties_tenant_name_address_abn, main.tenant_namefull, pd.PropertyID
# MAGIC             ORDER BY main.created DESC
# MAGIC         ) = 1;
# MAGIC
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC select  COUNT(*) FROM `arealytics-databricks_unity_catalog`.arealyticstrusted.reinsw_final --DEDUPE 2772 --NO DEDUPE = 3368

# COMMAND ----------

# MAGIC %md
# MAGIC ### Export data

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE OR REPLACE TEMP VIEW Reinsw_export AS
# MAGIC SELECT
# MAGIC     PropertyID AS `PropertyID`,
# MAGIC     PropertyName AS `Property Name`,
# MAGIC     Address,
# MAGIC     City,
# MAGIC     State,
# MAGIC     Zip,
# MAGIC     AltTenantName AS `Alt Tenant Name`,
# MAGIC     Level,
# MAGIC     Suite,
# MAGIC     LeasedSqm AS `Leased Sqm`,
# MAGIC     CommencingDate AS `Commencing Date`,
# MAGIC     ExpiryDate AS `Expiry Date`,
# MAGIC     FaceRentAnnual AS `Face Rent - Annual`,
# MAGIC     LeaseRateType AS `Lease Rate Type`,
# MAGIC     OutgoingsPerSqm AS `Outgoings (per sqm)`,
# MAGIC     EscalationRate AS `Escalation Rate %`,
# MAGIC     TermMonths AS `Term (months)`,
# MAGIC     RenewalOptionsNoOfMonths AS `Renewal Options (No. of Months)`,
# MAGIC     RecordedDate AS `Recorded Date`,
# MAGIC     LeaseSublease AS `Lease/Sublease`,
# MAGIC     LeaseTransType AS `Lease Trans Type`,
# MAGIC     TransactionComments AS `Transaction Comments`,
# MAGIC     SuiteComments AS `Suite Comments`,
# MAGIC     ExecutionDate AS `Execution Date`,
# MAGIC     SpaceGeneralUse AS `Space General Use`,
# MAGIC     LeaseStatus AS `Lease Status`,
# MAGIC     ConfirmationNotes,
# MAGIC     SignDate AS `SignDate`,
# MAGIC     BankGuaranteeAmount AS `BankGuaranteeAmount`,
# MAGIC     GSTIncluded AS `GSTIncluded`,
# MAGIC     IsCondo,
# MAGIC     Fitout,
# MAGIC     TransactionOriginationTypeID AS `TransactionOriginationTypeID`,
# MAGIC     IsStartingRateConfirmed AS `IsStartingRateConfirmed`,
# MAGIC     ShareLevelID AS `ShareLevelID`,
# MAGIC     IsExpDateConfirmed AS `IsExpDateConfirmed`,
# MAGIC     EscalationType,
# MAGIC     IsTermsConfirmed AS `IsTermsConfirmed`,
# MAGIC     ConfirmedTenantID AS `ConfirmedTenantID`,
# MAGIC     DealingNumber AS `DealingNumber`,
# MAGIC     IsOccupDateConfirmed AS `IsOccupDateConfirmed`,
# MAGIC     RentFreePeriod AS `RentFreePeriod`,
# MAGIC     NoticePeriodMin AS `NoticePeriodMin`,
# MAGIC     NoticePeriodMax AS `NoticePeriodMax`,
# MAGIC     ListingTypeID AS `ListingTypeID`,
# MAGIC     Folio,
# MAGIC     StageID,
# MAGIC     Status,
# MAGIC     ExceptionReason,
# MAGIC     CreatedDate,
# MAGIC     CreatedBy,
# MAGIC     ModifiedDate,
# MAGIC     ModifiedBy,
# MAGIC     LeaseID,
# MAGIC     IsActive,
# MAGIC     BatchID,
# MAGIC     ProviderID,
# MAGIC     HidedBy AS `HidedBy`,
# MAGIC     IsHidden AS `IsHidden`,
# MAGIC     HidedDate AS `HidedDate`,
# MAGIC     HideReasonID AS `HideReasonID`,
# MAGIC     HideReasonComments AS `HideReasonComments`,
# MAGIC     SubHideReasonID AS `SubHideReasonID`,
# MAGIC     MismatchedTaggedBy AS `MismatchedTaggedBy`,
# MAGIC     IsMismatched AS `IsMismatched`,
# MAGIC     Longitude,
# MAGIC     Latitude,
# MAGIC     cast(NULL as string) as Location,
# MAGIC     UID AS `UID`,
# MAGIC     Url AS `Url`,
# MAGIC     AgentName1 AS `AgentName1`,
# MAGIC     AgentEmail1 AS `AgentEmail1`,
# MAGIC     AgentName2 AS `AgentName2`,
# MAGIC     AgentEmail2 AS `AgentEmail2`,
# MAGIC     cast(NULL as string) as `Face Rent - per sqm`,
# MAGIC     cast(NULL as string) as `Space Type`,
# MAGIC     cast(NULL as string) as `LeaseFolio`,
# MAGIC     cast(NULL as string) as `Asking lease Rate/sqm/Year`,
# MAGIC     cast(NULL as string) as `Asking lease Rate/sqm/Month`,
# MAGIC     cast(NULL as string) as `Head Title`
# MAGIC FROM
# MAGIC      `arealytics-databricks_unity_catalog`.arealyticstrusted.reinsw_final ;
# MAGIC
# MAGIC      SELECT * from Reinsw_export
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from `arealytics-databricks_unity_catalog`.arealyticstrusted.reinsw_main as main 

# COMMAND ----------

# MAGIC %md
# MAGIC #Pre export filters#

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temp view counts as
# MAGIC WITH RankedData AS (
# MAGIC     SELECT 
# MAGIC         final.*,
# MAGIC         FROM_UNIXTIME(main.created) AS readable_created_date,
# MAGIC         ROW_NUMBER() OVER (
# MAGIC             PARTITION BY final.CommencingDate, final.ExpiryDate, final.AltTenantName, final.PropertyID
# MAGIC             ORDER BY main.created DESC
# MAGIC         ) AS rn
# MAGIC     FROM `arealytics-databricks_unity_catalog`.arealyticstrusted.reinsw_final as final
# MAGIC     left join `arealytics-databricks_unity_catalog`.arealyticstrusted.reinsw_main as main
# MAGIC     on main.nsw_id = final.dealingnumber
# MAGIC --     WHERE final.PropertyID IS NOT NULL
# MAGIC -- AND final.CommencingDate IS NOT NULL
# MAGIC -- AND final.AltTenantName IS NOT NULL
# MAGIC -- and final.SpaceGeneralUse != 0
# MAGIC --   AND
# MAGIC --   AltTenantName not ilike '%@%' AND AltTenantName not ilike '/%' AND AltTenantName not ilike '-%' and AltTenantName not  ilike '%&' and AltTenantName not ilike ',%' and AltTenantName not ilike '%,' AND AltTenantName not ilike 'and %' and AltTenantName not ilike 'as %' AND AltTenantName NOT ilike '%-' AND AltTenantName not ilike '%email%' AND AltTenantName NOT ilike '%sole%'
# MAGIC --   and AltTenantName not in ('.',';','_',' ','',':','!','@','#','$','%',' ','','&',',',')','1:', '|', '/', 'A &', 'A-', 'J.', 'K.', 'L.', 'M.', 'M &', 'F.','B &','R &','S &', 'T &', 'V &', 'C &', 'D &', 'E &', 'H &', 'K &','L &','P &', 'A.', 'V.','J &', 'Y &', 'and') 
# MAGIC ------ 18 279
# MAGIC -- AND TermMonths < 301 --17 767
# MAGIC )
# MAGIC    
# MAGIC where rn = 1
# MAGIC -- and zip IN ('2000','2007','2008','2009','2010','2011','2015','2016','2017','2018','2019','2020','2021','2022','2023','2024','2025','2026','2027','2028','2029','2030','2031','2032','2033','2034','2035','2036','2037','2038','2039','2040','2041','2042','2043','2044','2045','2046','2047','2048','2049','2050','2060','2061','2062','2063','2064','2065','2066','2067','2068','2069','2070','2071','2072','2073','2074','2075','2076','2077','2079','2080','2082','2083','2084','2085','2086','2087','2088','2089','2090','2092','2093','2094','2095','2096','2097','2099','2100','2101','2102','2103','2104','2106','2107','2108','2110','2111','2112','2113','2114','2115','2116','2117','2118','2119','2120','2121','2122','2125','2126','2127','2128','2130','2131','2132','2133','2134','2135','2136','2137','2138','2140','2141','2142','2143','2144','2145','2146','2147','2148','2150','2151','2152','2153','2154','2155','2156','2157','2158','2159','2160','2161','2162','2163','2164','2165','2166','2167','2168','2170','2171','2173','2174','2175','2176','2177','2178','2179','2190','2191','2192','2193','2194','2195','2196','2197','2198','2199','2200','2203','2204','2205','2206','2207','2208','2209','2210','2211','2212','2213','2214','2216','2217','2218','2219','2220','2221','2222','2223','2224','2225','2226','2227','2228','2229','2230','2231','2232','2233','2234','2238','2256','2259','2285','2287','2289','2293','2299','2300','2302','2304','2315','2323','2333','2480','2481','2500','2506','2527','2541','2557','2558','2560','2564','2565','2566','2567','2570','2571','2576','2577','2579','2580','2671','2745','2747','2748','2749','2750','2752','2753','2754','2756','2758','2759','2760','2761','2762','2763','2765','2766','2767','2768','2769','2770','2773','2774','2776','2777')
# MAGIC -- and dealingnumber = 'ade51dcafca5a1d61c007864b6d65c49e589d010eca79bdf0eef774a641496b3'
# MAGIC
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## pid linking

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT
# MAGIC id as form_id,
# MAGIC -- created,
# MAGIC -- code,
# MAGIC     formatted_address,
# MAGIC     REGEXP_SUBSTR(street_number, '\\d+') AS Street_Number_cleaned,
# MAGIC     street_number,
# MAGIC     CAST(
# MAGIC         SPLIT(street_number, '-')[0] AS INT
# MAGIC     ) AS StreetNumberMin,
# MAGIC     CAST(
# MAGIC         CASE 
# MAGIC             WHEN street_number LIKE '%-%' THEN
# MAGIC                 SPLIT(street_number, '-')[1]
# MAGIC             ELSE
# MAGIC                 NULL
# MAGIC         END AS INT
# MAGIC     ) AS StreetNumberMax,
# MAGIC     suburb,
# MAGIC     Unit,
# MAGIC     postal_code,
# MAGIC     latitude,
# MAGIC     longitude,
# MAGIC     CASE 
# MAGIC         WHEN unit = '00 00' OR unit IN ('00', '', '0') THEN NULL 
# MAGIC         ELSE REGEXP_EXTRACT(unit, '(\\d+)', 1)
# MAGIC     END as Cleaned_Unit,
# MAGIC     REGEXP_REPLACE(street_name, CONCAT('\\s+(', suffix_list.suffix_regex, ')$'), '') as Cleaned_Street_Name,
# MAGIC     CAST(NULL as INT) as PropertyID
# MAGIC FROM 
# MAGIC     `arealytics-databricks_unity_catalog`.arealyticstrusted.reinsw_geocoded_data as geo
# MAGIC CROSS JOIN 
# MAGIC     (SELECT concat_ws('|', collect_list(suffix),'Cres','Parade') as suffix_regex FROM `arealytics-databricks_unity_catalog`.arealyticstrusted.propertysuffixmap) as suffix_list
# MAGIC     -- WHERE geo. IS NULL;

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE OR REPLACE TABLE REINSW_Lease_Temp AS
# MAGIC SELECT
# MAGIC id as form_id,
# MAGIC -- created,
# MAGIC -- code,
# MAGIC     formatted_address,
# MAGIC     REGEXP_SUBSTR(street_number, '\\d+') AS Street_Number_cleaned,
# MAGIC     street_number,
# MAGIC     CAST(
# MAGIC         SPLIT(street_number, '-')[0] AS INT
# MAGIC     ) AS StreetNumberMin,
# MAGIC     CAST(
# MAGIC         CASE 
# MAGIC             WHEN street_number LIKE '%-%' THEN
# MAGIC                 SPLIT(street_number, '-')[1]
# MAGIC             ELSE
# MAGIC                 NULL
# MAGIC         END AS INT
# MAGIC     ) AS StreetNumberMax,
# MAGIC     suburb,
# MAGIC     Unit,
# MAGIC     postal_code,
# MAGIC     latitude,
# MAGIC     longitude,
# MAGIC     CASE 
# MAGIC         WHEN unit = '00 00' OR unit IN ('00', '', '0') THEN NULL 
# MAGIC         ELSE REGEXP_EXTRACT(unit, '(\\d+)', 1)
# MAGIC     END as Cleaned_Unit,
# MAGIC     REGEXP_REPLACE(street_name, CONCAT('\\s+(', suffix_list.suffix_regex, ')$'), '') as Cleaned_Street_Name,
# MAGIC     CAST(NULL as INT) as PropertyID
# MAGIC FROM 
# MAGIC     `arealytics-databricks_unity_catalog`.arealyticstrusted.reinsw_geocoded_data
# MAGIC CROSS JOIN 
# MAGIC     (SELECT concat_ws('|', collect_list(suffix),'Cres','Parade') as suffix_regex FROM `arealytics-databricks_unity_catalog`.arealyticstrusted.propertysuffixmap) as suffix_list;
# MAGIC
# MAGIC -----------------------------------------
# MAGIC CREATE OR REPLACE TABLE reiv_temp AS
# MAGIC WITH RankedMatches AS (
# MAGIC     SELECT 
# MAGIC     lt.form_id,
# MAGIC     -- lt.created,
# MAGIC     -- lt.code,
# MAGIC     A.ParentID AS PropertyID,
# MAGIC     LT.formatted_address,
# MAGIC     A.AddressText AS AL_address,
# MAGIC     LT.postal_code AS `REINSW_ZipCode`, 
# MAGIC     A.ZipCode AS `AL_ZipCode`,
# MAGIC     LT.suburb AS `REINSW_City`,
# MAGIC     CTY.CityName AS `AL_City`,
# MAGIC     LT.Cleaned_Street_Name AS `REINSW_StreetName`,
# MAGIC     A.AddressStreetName AS `AL_StreetName`,
# MAGIC     P.CondoTypeID,
# MAGIC     LT.StreetNumberMin AS REINSW_StreetNumberMin,
# MAGIC     LT.StreetNumberMax AS REINSW_StreetNumberMax,
# MAGIC     A.StreetNumberMin AS AL_StreetNumberMin,
# MAGIC     A.StreetNumberMax AS AL_StreetNumberMax,
# MAGIC     ROW_NUMBER() OVER (
# MAGIC         PARTITION BY LT.form_id
# MAGIC         ORDER BY (COALESCE(A.StreetNumberMax, A.StreetNumberMin) - A.StreetNumberMin) ASC
# MAGIC     ) AS rn
# MAGIC     FROM REINSW_Lease_Temp LT 
# MAGIC     LEFT JOIN `arealytics-databricks_unity_catalog`.arealyticstrusted.Address A ON A.ParentTableID=1 
# MAGIC         AND A.IsActive=1 AND LT.postal_code = A.ZipCode 
# MAGIC         AND lower(LT.Cleaned_Street_Name)=lower(A.AddressStreetName)
# MAGIC         AND 
# MAGIC         (
# MAGIC 		LT.Street_Number_cleaned =  A.StreetNumberMin
# MAGIC 		OR 
# MAGIC         LT.Street_Number_cleaned =  A.StreetNumberMax
# MAGIC         OR
# MAGIC         LT.StreetNumberMin BETWEEN A.StreetNumberMin AND COALESCE(A.StreetNumberMax, A.StreetNumberMin))
# MAGIC         -- AND LT.Cleaned_Street_Name=A.AddressStreetName AND (LT.street_number = A.StreetNumberMin OR LT.street_number BETWEEN A.StreetNumberMin AND A.StreetNumberMax)
# MAGIC     LEFT JOIN `arealytics-databricks_unity_catalog`.arealyticstrusted.Property_detail P ON P.PropertyID=A.ParentID
# MAGIC     LEFT JOIN `arealytics-databricks_unity_catalog`.arealyticstrusted.PropertySummary PS on PS.PropertyID=P.PropertyID 
# MAGIC     LEFT JOIN `arealytics-databricks_unity_catalog`.arealyticstrusted.City CTY ON CTY.CityID=A.CityID AND LT.suburb= CTY.CityName
# MAGIC     LEFT JOIN `arealytics-databricks_unity_catalog`.arealyticstrusted.propertysuffixmap as suff on p.StreetSuffix1 = suff.SuffixID
# MAGIC     WHERE LT.Cleaned_Unit is null and (P.CondoTypeID is null or P.CondoTypeID <> 2) and PS.ResearchTypeID not in (4,0)
# MAGIC )
# MAGIC SELECT * FROM RankedMatches
# MAGIC -- where id= '102409'
# MAGIC WHERE rn = 1;
# MAGIC
# MAGIC UPDATE REINSW_Lease_Temp lt
# MAGIC SET lt.PropertyID = (
# MAGIC     SELECT MAX(t.PropertyID)
# MAGIC     FROM reiv_temp t 
# MAGIC     WHERE lt.form_id = t.form_id
# MAGIC     -- AND lt.code = t.code
# MAGIC )
# MAGIC WHERE lt.PropertyID IS NULL;
# MAGIC
# MAGIC ------------------------ PASS 2
# MAGIC
# MAGIC CREATE OR REPLACE TABLE reiv_temp AS
# MAGIC WITH RankedMatches AS (
# MAGIC     SELECT 
# MAGIC     lt.form_id,
# MAGIC     -- lt.created,
# MAGIC     -- lt.code,
# MAGIC     A.ParentID AS PropertyID,
# MAGIC     LT.formatted_address,
# MAGIC     A.AddressText AS AL_address,
# MAGIC     LT.postal_code AS `REINSW_ZipCode`, 
# MAGIC     A.ZipCode AS `AL_ZipCode`,
# MAGIC     LT.suburb AS `REINSW_City`,
# MAGIC     CTY.CityName AS `AL_City`,
# MAGIC     LT.Cleaned_Street_Name AS `REINSW_StreetName`,
# MAGIC     A.AddressStreetName AS `AL_StreetName`,
# MAGIC     P.CondoTypeID,
# MAGIC     LT.StreetNumberMin AS REINSW_StreetNumberMin,
# MAGIC     LT.StreetNumberMax AS REINSW_StreetNumberMax,
# MAGIC     A.StreetNumberMin AS AL_StreetNumberMin,
# MAGIC     A.StreetNumberMax AS AL_StreetNumberMax,
# MAGIC     ROW_NUMBER() OVER (
# MAGIC         PARTITION BY LT.form_id
# MAGIC         ORDER BY (COALESCE(A.StreetNumberMax, A.StreetNumberMin) - A.StreetNumberMin) ASC
# MAGIC     ) AS rn
# MAGIC     FROM REINSW_Lease_Temp LT 
# MAGIC LEFT JOIN 
# MAGIC     `arealytics-databricks_unity_catalog`.arealyticstrusted.Address A 
# MAGIC ON 
# MAGIC     A.ParentTableID=1 AND A.IsActive=1 
# MAGIC     AND LT.postal_code = A.ZipCode AND lower(LT.Cleaned_Street_Name)=lower(A.AddressStreetName)
# MAGIC     -- AND LT.StreetNumberMin BETWEEN A.StreetNumberMin AND COALESCE(A.StreetNumberMax, A.StreetNumberMin)
# MAGIC     AND 
# MAGIC         (
# MAGIC 		LT.Street_Number_cleaned =  A.StreetNumberMin
# MAGIC 		OR 
# MAGIC         LT.Street_Number_cleaned =  A.StreetNumberMax
# MAGIC         OR
# MAGIC         LT.StreetNumberMin BETWEEN A.StreetNumberMin AND COALESCE(A.StreetNumberMax, A.StreetNumberMin))
# MAGIC LEFT JOIN 
# MAGIC     `arealytics-databricks_unity_catalog`.arealyticstrusted.Property_detail P 
# MAGIC ON 
# MAGIC     P.PropertyID = A.ParentID AND (P.CondoUnit IS NULL OR P.CondoUnit = LT.unit)
# MAGIC LEFT JOIN 
# MAGIC     `arealytics-databricks_unity_catalog`.arealyticstrusted.PropertySummary PS 
# MAGIC ON 
# MAGIC     PS.PropertyID = P.PropertyID 
# MAGIC LEFT JOIN 
# MAGIC     `arealytics-databricks_unity_catalog`.arealyticstrusted.City CTY 
# MAGIC ON 
# MAGIC     CTY.CityID = A.CityID AND LT.suburb = CTY.CityName
# MAGIC LEFT JOIN `arealytics-databricks_unity_catalog`.arealyticstrusted.propertysuffixmap as suff on p.StreetSuffix1 = suff.SuffixID
# MAGIC WHere  
# MAGIC LT.Cleaned_Unit IS NOT NULL 
# MAGIC and PS.ResearchTypeID not in (4,0)
# MAGIC AND P.CondoUnit IS NOT NULL
# MAGIC )
# MAGIC SELECT * FROM RankedMatches
# MAGIC -- where id= '102409'
# MAGIC WHERE rn = 1;
# MAGIC
# MAGIC UPDATE REINSW_Lease_Temp lt
# MAGIC SET lt.PropertyID = (
# MAGIC     SELECT MAX(t.PropertyID)
# MAGIC     FROM reiv_temp t 
# MAGIC     WHERE lt.form_id = t.form_id
# MAGIC     -- AND lt.code = t.code
# MAGIC )
# MAGIC WHERE lt.PropertyID IS NULL;
# MAGIC
# MAGIC ------------------- PASS 3
# MAGIC
# MAGIC CREATE OR REPLACE TABLE reiv_temp AS
# MAGIC WITH RankedMatches AS (
# MAGIC     SELECT 
# MAGIC     lt.form_id,
# MAGIC     -- lt.created,
# MAGIC     -- lt.code,
# MAGIC     A.ParentID AS PropertyID,
# MAGIC     LT.formatted_address,
# MAGIC     A.AddressText AS AL_address,
# MAGIC     LT.postal_code AS `REINSW_ZipCode`, 
# MAGIC     A.ZipCode AS `AL_ZipCode`,
# MAGIC     LT.suburb AS `REINSW_City`,
# MAGIC     CTY.CityName AS `AL_City`,
# MAGIC     LT.Cleaned_Street_Name AS `REINSW_StreetName`,
# MAGIC     A.AddressStreetName AS `AL_StreetName`,
# MAGIC     P.CondoTypeID,
# MAGIC     LT.StreetNumberMin AS REINSW_StreetNumberMin,
# MAGIC     LT.StreetNumberMax AS REINSW_StreetNumberMax,
# MAGIC     A.StreetNumberMin AS AL_StreetNumberMin,
# MAGIC     A.StreetNumberMax AS AL_StreetNumberMax,
# MAGIC     ROW_NUMBER() OVER (
# MAGIC         PARTITION BY LT.form_id
# MAGIC         ORDER BY (COALESCE(A.StreetNumberMax, A.StreetNumberMin) - A.StreetNumberMin) ASC
# MAGIC     ) AS rn
# MAGIC     FROM REINSW_Lease_Temp LT 
# MAGIC LEFT JOIN 
# MAGIC     `arealytics-databricks_unity_catalog`.arealyticstrusted.Address A 
# MAGIC ON 
# MAGIC     A.ParentTableID=1 AND A.IsActive=1 AND LT.postal_code = A.ZipCode AND lower(LT.Cleaned_Street_Name) = lower(A.AddressStreetName)
# MAGIC     AND 
# MAGIC         (
# MAGIC 		LT.Street_Number_cleaned =  A.StreetNumberMin
# MAGIC 		OR 
# MAGIC         LT.Street_Number_cleaned =  A.StreetNumberMax
# MAGIC         OR
# MAGIC         LT.StreetNumberMin BETWEEN A.StreetNumberMin AND COALESCE(A.StreetNumberMax, A.StreetNumberMin))
# MAGIC LEFT JOIN 
# MAGIC     `arealytics-databricks_unity_catalog`.arealyticstrusted.Property_detail P 
# MAGIC ON 
# MAGIC     P.PropertyID = A.ParentID AND (P.CondoUnit IS NULL OR P.CondoUnit = LT.unit)
# MAGIC LEFT JOIN 
# MAGIC     `arealytics-databricks_unity_catalog`.arealyticstrusted.PropertySummary PS 
# MAGIC ON 
# MAGIC     PS.PropertyID = P.PropertyID 
# MAGIC LEFT JOIN 
# MAGIC     `arealytics-databricks_unity_catalog`.arealyticstrusted.City CTY 
# MAGIC ON 
# MAGIC     CTY.CityID = A.CityID AND LT.suburb = CTY.CityName
# MAGIC LEFT JOIN `arealytics-databricks_unity_catalog`.arealyticstrusted.propertysuffixmap as suff on p.StreetSuffix1 = suff.SuffixID
# MAGIC )
# MAGIC
# MAGIC SELECT * FROM RankedMatches
# MAGIC -- where id= '102409'
# MAGIC WHERE rn = 1;
# MAGIC
# MAGIC UPDATE REINSW_Lease_Temp lt
# MAGIC SET lt.PropertyID = (
# MAGIC     SELECT MAX(t.PropertyID)
# MAGIC     FROM reiv_temp t 
# MAGIC     WHERE lt.form_id = t.form_id
# MAGIC     -- AND lt.code = t.code
# MAGIC )
# MAGIC WHERE lt.PropertyID IS NULL;
# MAGIC
# MAGIC create or replace table `arealytics-databricks_unity_catalog`.arealyticstrusted.reinsw_pid_link as
# MAGIC select * from REINSW_Lease_Temp

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT * FROM `arealytics-databricks_unity_catalog`.arealyticstrusted.reinsw_pid_link --5233
# MAGIC WHERE PropertyID IS NOT NULL --3177
# MAGIC -- WHERE PropertyID IS NULL --

# COMMAND ----------

# MAGIC %md 
# MAGIC #Counts for post proccessing audit#

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT 
# MAGIC     COUNT(*) AS Total_Records,
# MAGIC     COUNT(CASE WHEN final.PropertyID IS NOT NULL THEN 1 END) AS Filter_Pid,
# MAGIC     COUNT(CASE WHEN final.CommencingDate IS NOT NULL AND final.PropertyID IS NOT NULL THEN 1 END) AS Filter_CommencingDate,
# MAGIC     COUNT(CASE WHEN final.CommencingDate IS NOT NULL AND final.PropertyID IS NOT NULL AND final.AltTenantName IS NOT NULL THEN 1 END) AS Filter_TenantName,
# MAGIC     COUNT(CASE WHEN final.CommencingDate IS NOT NULL AND final.PropertyID IS NOT NULL AND final.AltTenantName IS NOT NULL AND final.SpaceGeneralUse !=0 THEN 1 END) AS Filter_SpaceGeneralUse,
# MAGIC     COUNT(CASE WHEN final.CommencingDate IS NOT NULL AND final.PropertyID IS NOT NULL AND final.AltTenantName IS NOT NULL AND final.SpaceGeneralUse !=0 THEN 1 END) - count(CASE WHEN final.CommencingDate IS NOT NULL AND final.PropertyID IS NOT NULL AND final.AltTenantName IS NOT NULL AND final.SpaceGeneralUse !=0 AND count.dealingnumber IS NULL THEN 1 END) AS Filter_Dups
# MAGIC FROM `arealytics-databricks_unity_catalog`.arealyticstrusted.reinsw_final as final
# MAGIC
# MAGIC left join counts as count
# MAGIC on `count`.`DealingNumber` = final.DealingNumber

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT 
# MAGIC     '54822' AS Total_Records,
# MAGIC     COUNT(*) as IM_cut_off,
# MAGIC     COUNT(*) - COUNT(CASE WHEN count.DealingNumber is null then 1 end) as Unique_records_cut_off,
# MAGIC     -------------------------------
# MAGIC     ---Valid tenant names
# MAGIC     count(case WHEN count.DealingNumber is not null and count.AltTenantName IS NOT NULL then 1 end) valid_ten,
# MAGIC     count(case WHEN count.DealingNumber is not null and count.CommencingDate IS NOT NULL then 1 end) valid_CommencingDate,
# MAGIC     count(case WHEN count.DealingNumber is not null and count.ExpiryDate  IS NOT NULL then 1 end) valid_ExpiryDate,
# MAGIC     count(case WHEN count.DealingNumber is not null and count.SpaceGeneralUse !=0 then 1 end) valid_SpaceGeneralUse,
# MAGIC     count(case WHEN count.DealingNumber is not null and count.FaceRentAnnual IS NOT NULL then 1 end) valid_FaceRentAnnual,
# MAGIC     COUNT(CASE WHEN count.CommencingDate IS NOT NULL AND count.PropertyID IS NOT NULL AND count.AltTenantName IS NOT NULL AND count.SpaceGeneralUse !=0 and rn = 1 THEN 1 END) as Extra_filter_count
# MAGIC FROM `arealytics-databricks_unity_catalog`.arealyticstrusted.reinsw_main as final
# MAGIC
# MAGIC left join counts as count
# MAGIC on `count`.`DealingNumber` = final.nsw_id
# MAGIC -- and rn = 1
# MAGIC
# MAGIC LEFT JOIN `arealytics-databricks_unity_catalog`.arealyticstrusted.reinsw_geocoded_data  AS geo2
# MAGIC ON geo2.nsw_id = final.nsw_id
# MAGIC
# MAGIC where geo2.postal_code IN ('2000','2007','2008','2009','2010','2011','2015','2016','2017','2018','2019','2020','2021','2022','2023','2024','2025','2026','2027','2028','2029','2030','2031','2032','2033','2034','2035','2036','2037','2038','2039','2040','2041','2042','2043','2044','2045','2046','2047','2048','2049','2050','2060','2061','2062','2063','2064','2065','2066','2067','2068','2069','2070','2071','2072','2073','2074','2075','2076','2077','2079','2080','2082','2083','2084','2085','2086','2087','2088','2089','2090','2092','2093','2094','2095','2096','2097','2099','2100','2101','2102','2103','2104','2106','2107','2108','2110','2111','2112','2113','2114','2115','2116','2117','2118','2119','2120','2121','2122','2125','2126','2127','2128','2130','2131','2132','2133','2134','2135','2136','2137','2138','2140','2141','2142','2143','2144','2145','2146','2147','2148','2150','2151','2152','2153','2154','2155','2156','2157','2158','2159','2160','2161','2162','2163','2164','2165','2166','2167','2168','2170','2171','2173','2174','2175','2176','2177','2178','2179','2190','2191','2192','2193','2194','2195','2196','2197','2198','2199','2200','2203','2204','2205','2206','2207','2208','2209','2210','2211','2212','2213','2214','2216','2217','2218','2219','2220','2221','2222','2223','2224','2225','2226','2227','2228','2229','2230','2231','2232','2233','2234','2238','2256','2259','2285','2287','2289','2293','2299','2300','2302','2304','2315','2323','2333','2480','2481','2500','2506','2527','2541','2557','2558','2560','2564','2565','2566','2567','2570','2571','2576','2577','2579','2580','2671','2745','2747','2748','2749','2750','2752','2753','2754','2756','2758','2759','2760','2761','2762','2763','2765','2766','2767','2768','2769','2770','2773','2774','2776','2777')

# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC select *
# MAGIC from counts as final
# MAGIC
# MAGIC LEFT JOIN `arealytics-databricks_unity_catalog`.arealyticstrusted.reinsw_geocoded_data  AS geo2
# MAGIC ON geo2.nsw_id = final.dealingnumber
# MAGIC
# MAGIC where geo2.postal_code IN ('2000','2007','2008','2009','2010','2011','2015','2016','2017','2018','2019','2020','2021','2022','2023','2024','2025','2026','2027','2028','2029','2030','2031','2032','2033','2034','2035','2036','2037','2038','2039','2040','2041','2042','2043','2044','2045','2046','2047','2048','2049','2050','2060','2061','2062','2063','2064','2065','2066','2067','2068','2069','2070','2071','2072','2073','2074','2075','2076','2077','2079','2080','2082','2083','2084','2085','2086','2087','2088','2089','2090','2092','2093','2094','2095','2096','2097','2099','2100','2101','2102','2103','2104','2106','2107','2108','2110','2111','2112','2113','2114','2115','2116','2117','2118','2119','2120','2121','2122','2125','2126','2127','2128','2130','2131','2132','2133','2134','2135','2136','2137','2138','2140','2141','2142','2143','2144','2145','2146','2147','2148','2150','2151','2152','2153','2154','2155','2156','2157','2158','2159','2160','2161','2162','2163','2164','2165','2166','2167','2168','2170','2171','2173','2174','2175','2176','2177','2178','2179','2190','2191','2192','2193','2194','2195','2196','2197','2198','2199','2200','2203','2204','2205','2206','2207','2208','2209','2210','2211','2212','2213','2214','2216','2217','2218','2219','2220','2221','2222','2223','2224','2225','2226','2227','2228','2229','2230','2231','2232','2233','2234','2238','2256','2259','2285','2287','2289','2293','2299','2300','2302','2304','2315','2323','2333','2480','2481','2500','2506','2527','2541','2557','2558','2560','2564','2565','2566','2567','2570','2571','2576','2577','2579','2580','2671','2745','2747','2748','2749','2750','2752','2753','2754','2756','2758','2759','2760','2761','2762','2763','2765','2766','2767','2768','2769','2770','2773','2774','2776','2777')
# MAGIC -- and 
# MAGIC -- (
# MAGIC -- final.PropertyID IS NULL
# MAGIC -- or final.CommencingDate IS NULL
# MAGIC -- or final.AltTenantName IS NULL
# MAGIC -- or final.SpaceGeneralUse = 0
# MAGIC -- )

# COMMAND ----------

# MAGIC %sql
# MAGIC WITH aggregated_data AS (
# MAGIC     SELECT
# MAGIC         FROM_UNIXTIME(main.created, 'yyyy-MM') AS Month,
# MAGIC         main.code,
# MAGIC         COUNT(*) as count
# MAGIC     FROM `arealytics-databricks_unity_catalog`.arealyticstrusted.reinsw_main AS main
# MAGIC LEFT JOIN `arealytics-databricks_unity_catalog`.arealyticstrusted.reinsw_geocoded_data  AS geo2
# MAGIC ON geo2.nsw_id = main.nsw_id
# MAGIC where 
# MAGIC -- geo2.postal_code IN ('2000','2007','2008','2009','2010','2011','2015','2016','2017','2018','2019','2020','2021','2022','2023','2024','2025','2026','2027','2028','2029','2030','2031','2032','2033','2034','2035','2036','2037','2038','2039','2040','2041','2042','2043','2044','2045','2046','2047','2048','2049','2050','2060','2061','2062','2063','2064','2065','2066','2067','2068','2069','2070','2071','2072','2073','2074','2075','2076','2077','2079','2080','2082','2083','2084','2085','2086','2087','2088','2089','2090','2092','2093','2094','2095','2096','2097','2099','2100','2101','2102','2103','2104','2106','2107','2108','2110','2111','2112','2113','2114','2115','2116','2117','2118','2119','2120','2121','2122','2125','2126','2127','2128','2130','2131','2132','2133','2134','2135','2136','2137','2138','2140','2141','2142','2143','2144','2145','2146','2147','2148','2150','2151','2152','2153','2154','2155','2156','2157','2158','2159','2160','2161','2162','2163','2164','2165','2166','2167','2168','2170','2171','2173','2174','2175','2176','2177','2178','2179','2190','2191','2192','2193','2194','2195','2196','2197','2198','2199','2200','2203','2204','2205','2206','2207','2208','2209','2210','2211','2212','2213','2214','2216','2217','2218','2219','2220','2221','2222','2223','2224','2225','2226','2227','2228','2229','2230','2231','2232','2233','2234','2238','2256','2259','2285','2287','2289','2293','2299','2300','2302','2304','2315','2323','2333','2480','2481','2500','2506','2527','2541','2557','2558','2560','2564','2565','2566','2567','2570','2571','2576','2577','2579','2580','2671','2745','2747','2748','2749','2750','2752','2753','2754','2756','2758','2759','2760','2761','2762','2763','2765','2766','2767','2768','2769','2770','2773','2774','2776','2777')
# MAGIC -- and 
# MAGIC FROM_UNIXTIME(main.created, 'yyyy') = '2023'
# MAGIC     GROUP BY FROM_UNIXTIME(main.created, 'yyyy-MM'), main.code
# MAGIC )
# MAGIC SELECT *
# MAGIC FROM aggregated_data
# MAGIC PIVOT (
# MAGIC     SUM(count) FOR code IN ('FM00900', 'FM00910') -- Add additional codes as required
# MAGIC ) ORDER BY month
