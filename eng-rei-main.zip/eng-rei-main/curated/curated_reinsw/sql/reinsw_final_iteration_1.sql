%sql
-- Set the load date variable
-- SET loadDate = CURRENT_DATE();

-- Delete records for the current load date
DELETE FROM `arealytics-databricks_unity_catalog`.arealyticscurated.FactLease
WHERE LoadDate = cast(CURRENT_DATE() as date);

INSERT INTO `arealytics-databricks_unity_catalog`.arealyticscurated.FactLease
-- CREATE TABLE IF NOT EXISTS `arealytics-databricks_unity_catalog`.arealyticscurated.FactLease
-- USING DELTA
-- LOCATION "s3://arealytics-data-lake-curated/source=rei/dataflow=reiv/FactLease/"
-- AS
SELECT
    -- Direct mappings and case statements
    pd.PropertyID AS PropertyID,
    -- ten.id as TenantID,
    -- lal.id as LandLordId,
    -- agt.id as AgentId,
    -- c.DateKey,
    cast(null as string) AS PropertyName, -- Field not in original select
    cast(null as string) AS Address, -- Field not in original select
    cast(null as string) AS City, -- Field not in original select
    cast(null as string) AS State, -- Field not in original select
    cast(null as string) AS Zip, -- Field not in original select
    tenantname AS AltTenantName, --Get tenant id
    REGEXP_EXTRACT(ma.streetaddress, 'Level\\s*(\\d+)', 1) AS Level,
    -- SuiteNumber logic
    CASE    
        WHEN suite.suite IS NOT NULL THEN REGEXP_SUBSTR(suite.suite, '(\\b\\d+)')
        ELSE NULL
    END AS Suite,
    cast(null as string) AS LeasedSqm, -- Field not in original select
    date_format(cast(commencementdate as date), 'dd/MM/yyyy') AS CommencingDate,
    -- ExpirationDate logic
    CASE
        WHEN CAST(commencementdate AS DATE) = NULL OR extract_total_term(ma.termpremises) = 0 THEN NULL
        WHEN  extract_total_term(ma.termpremises) != 0 OR CAST(commencementdate AS DATE) != NULL THEN date_format(CAST(DATEADD(MONTH, extract_total_term(ma.termpremises), CAST(commencementdate AS DATE)) AS DATE), 'dd/MM/yyyy')
        ELSE NULL
    END AS ExpiryDate,
    CASE 
    WHEN lower(preferredrentoption) = Lower('Annum') THEN ROUND(commencingrentamount, 0)
    WHEN lower(preferredrentoption) = Lower('calendarMonth') THEN ROUND(commencingrentamount * 12, 0)
    ELSE NULL
END AS FaceRentAnnual,
    -- LeaseRateTypeID logic
    CASE 
        WHEN outgoingsapportionmentdescription REGEXP '[0-9]+%' OR outgoingsapportionmentdescription LIKE '%outgoings%' THEN 10
        WHEN outgoingsapportionmentdescription = 'Nil' OR outgoingsapportionmentdescription LIKE 'Nil%' THEN 4
        ELSE NULL
    END AS LeaseRateType,
    cast(null as string) AS OutgoingsPerSqm, -- Field not in original select
    -- EscalationRate logic  -- REGEXP_EXTRACT(ec.extracted_entity, '(\\d+\\.?\\d*)%?', 1)
    CASE
        WHEN ec.extracted_entity IS NULL THEN NULL
        WHEN ec.extracted_entity > 9 THEN NULL
        WHEN ec.extracted_entity BETWEEN 0 AND 9 THEN ROUND(REGEXP_EXTRACT(ec.extracted_entity, '(\\d+\\.?\\d*)%?', 1), 0)
        ELSE REGEXP_EXTRACT(ec.extracted_entity, '(\\d+\\.?\\d*)%?', 1)
    END AS EscalationRate,
     -- Total term logic   
    extract_total_term(ma.termpremises) AS TermMonths,
    parse_and_compute(furthertermsdescription).result AS RenewalOptionsNoOfMonths, -- Field not in original select
    CASE 
        WHEN leasedate != 'nan' THEN date_format(cast(leasedate as date), 'dd/MM/yyyy')
        ELSE NULL  
    END AS RecordedDate,
   cast(null as string) AS LeaseSublease, -- Field not in original select
    -- LeaseTransType logic
    CASE
        WHEN lease_type = 'lease-renewal' THEN 2
        WHEN lease_type = 'lease-schedule' THEN 1
        ELSE NULL
    END AS LeaseTransType,
    -- TransactionComments logic
    CASE 
        WHEN lease_type = 'lease-schedule' THEN 
            CONCAT('Renewal Option: ', FurtherTermsDescription, 
                    'Outgoings Description: ', outgoingsapportionmentdescription, 
                    'Excluded Outgoings: ', excludedoutgoingsdescription)
        WHEN lease_type = 'lease-renewal' THEN 
            CONCAT('Special Conditions: ', specialconditions)
        ELSE 
        NULL
    END AS TransactionComments,
    CASE 
        WHEN fixturesfittingsdescription = 'nan' and lower(fixturesfittingsdescription) = 'nil' THEN NULL
        WHEN fixturesfittingsdescription != 'nan' THEN fixturesfittingsdescription
        ELSE NULL
    END AS SuiteComments,
    CASE 
        WHEN leasedate != 'nan' THEN date_format(cast(leasedate as date), 'dd/MM/yyyy')
        ELSE NULL   
    END AS ExecutionDate,
    CASE 
        WHEN ma.permittedusetype IN ('Office, Retail', 'Unclassified') THEN 
            CASE 
                WHEN pd.PropertyUse = 'Office' THEN 9
                WHEN pd.PropertyUse = 'Industrial' THEN 8
                WHEN pd.PropertyUse = 'Retail' OR pd.PropertyUse IN ('Land', 'Multi-Family Housing') THEN 7
                ELSE 0 -- or some other default ID for unmatched cases
            END
        WHEN ma.permittedusetype = 'Office' THEN 9
        WHEN ma.permittedusetype = 'Industrial' THEN 8
        WHEN ma.permittedusetype = 'Retail' THEN 7
        ELSE 0 -- or some other default ID for other cases
    END AS SpaceGeneralUse,
    -- LeaseStatusID logic
    CASE 
        WHEN CAST(commencementdate AS DATE) != '1970-01-01' AND 
            CAST(DATEADD(MONTH, extract_total_term(ma.termpremises), CAST(commencementdate AS DATE)) AS DATE) < CURRENT_DATE THEN 1  -- Historic
        WHEN CAST(commencementdate AS DATE) != '1970-01-01' AND 
            CAST(DATEADD(MONTH, extract_total_term(ma.termpremises), CAST(commencementdate AS DATE)) AS DATE) >= CURRENT_DATE THEN 2  -- Active
        ELSE NULL  -- Default case when commencement date is '1970-01-01' or other invalid/missing data
    END AS LeaseStatus,
    cast(null as string) AS ConfirmationNotes, -- Field not in original select
    cast(null as string) AS SignDate, -- Field not in original select
    cast(null as string) AS BankGuaranteeAmount, -- Field not in original select
    -- GSTIncluded logic
    CASE 
        WHEN commencinggstoption = 'excludeGST' THEN 0
        WHEN commencinggstoption = 'includeGST' THEN 1
        ELSE NULL
    END AS GSTIncluded,
    cast(null as string) AS IsCondo, -- Field not in original select
    -- Fitout logic
    CASE 
        WHEN fixturesfittingsdescription IS NULL 
        OR lower(fixturesfittingsdescription) LIKE lower('Nil%')
        OR fixturesfittingsdescription = 'nan' 
        THEN 0
        ELSE 1
    END AS Fitout,
    2 as TransactionOriginationTypeID,
    -- IsStartingRateConfirmed logic
    CASE 
        WHEN commencingrentamount IS NOT NULL THEN 1
        ELSE 0
    END AS IsStartingRateConfirmed,
    5 as ShareLevelID,
    -- IsExpDateConfirmed logic
    CASE 
        WHEN CAST(DATEADD(MONTH, extract_total_term(ma.termpremises), CAST(commencementdate AS DATE)) AS DATE) IS NOT NULL AND CAST(commencementdate AS DATE) != '1970-01-01' THEN 1
        ELSE 0
    END AS IsExpDateConfirmed,
    -- EscalationType logic
    CASE     
        WHEN ma.rentincreasedescription REGEXP '\\bCPI\\b' AND ma.rentincreasedescription REGEXP '\\bplus\\b|\\+' AND ma.rentincreasedescription REGEXP '\\d+\\.?\\d*%' THEN '5'  -- CPI plus fixed %
        WHEN ma.rentincreasedescription REGEXP '\\bCPI\\b' AND ma.rentincreasedescription REGEXP '\\d+\\.?\\d*%' THEN '4'  -- Greater of CPI and fixed percentage
        WHEN ma.rentincreasedescription REGEXP '\\d+\\.?\\d*%?' THEN '1' -- Fixed percent (Searches for '%')
        WHEN ma.rentincreasedescription REGEXP '\\bCPI\\b|\\bcpi\\b|\\bCPi\\b|\\bConsumer Price Index\\b|\\b(Consumer Price Index)\\b' THEN '2' -- Searches for CPI when it's on its own
        WHEN ma.rentincreasedescription REGEXP '\\bmarket\\b|\\bMarket\\b|\\bMARKET\\b' THEN '3' -- Searches for Market when it's on its own
        ELSE NULL
    END AS EscalationType,
    -- IsTermsConfirmed logic
    CASE 
        WHEN extract_total_term(ma.termpremises) IS NOT NULL AND extract_total_term(ma.termpremises) != 0 THEN 1
        ELSE 0
    END AS IsTermsConfirmed,
    cast(null as string) AS ConfirmedTenantID, -- Field not in original select
    ma.id AS DealingNumber,
    -- IsOccupDateConfirmed logic
    CASE 
        WHEN commencementdate IS NOT NULL AND CAST(commencementdate AS DATE) != '1970-01-01' THEN 1
        ELSE 0
    END AS IsOccupDateConfirmed,
    -- RentFreePeriod logic
    CASE 
        WHEN MONTHS_BETWEEN(
                CAST(rentcommencementdate AS DATE), 
                CAST(commencementdate AS DATE)
            ) <= 0 THEN NULL
        WHEN ROUND(MONTHS_BETWEEN(
                CAST(rentcommencementdate AS DATE), 
                CAST(commencementdate AS DATE)
            ), 0) > 6 THEN NULL
        ELSE ROUND(MONTHS_BETWEEN(
                CAST(rentcommencementdate AS DATE), 
                CAST(commencementdate AS DATE)
            ), 0)
    END AS RentFreePeriod,
    -- NoticePeriodMin logic
CASE
    WHEN extract_total_term(ma.termpremises) <= 0 OR CAST(commencementdate AS DATE) IS NULL THEN NULL
    ELSE 
        CASE 
            WHEN ROUND(MONTHS_BETWEEN(CAST(DATEADD(MONTH, extract_total_term(ma.termpremises), CAST(commencementdate AS DATE)) AS DATE), CAST(FROM_UNIXTIME(exerciseoptiondate / 1000) AS DATE)), 0) < 0 THEN NULL
            WHEN ROUND(MONTHS_BETWEEN(CAST(DATEADD(MONTH, extract_total_term(ma.termpremises), CAST(commencementdate AS DATE)) AS DATE), CAST(FROM_UNIXTIME(exerciseoptiondate / 1000) AS DATE)), 0) > 6 THEN NULL
            ELSE ROUND(MONTHS_BETWEEN(CAST(DATEADD(MONTH, extract_total_term(ma.termpremises), CAST(commencementdate AS DATE)) AS DATE), CAST(FROM_UNIXTIME(exerciseoptiondate / 1000) AS DATE)), 0)
        END
END AS NoticePeriodMin,
    cast(null as string) AS NoticePeriodMax, -- Field not in original select
    1 as ListingTypeID,
    CAST(current_date() AS DATE) AS LoadDate
FROM `arealytics-databricks_unity_catalog`.arealyticstrusted.reiv_lease_main as ma -- 30873

LEFT JOIN reiv_Escalation as ec on ec.id = ma.id  -- 30873

LEFT JOIN reiv_Geocoded_pid as GPid
on GPid.id = ma.id

LEFT JOIN `arealytics-databricks_unity_catalog`.arealyticstrusted.property_detail as pd
on gpid.propertyId = pd.propertyId

LEFT JOIN reiv_suite_cleanup
as Suite on Suite.id = ma.id

LEFT JOIN `arealytics-databricks_unity_catalog`.arealyticscurated.dimtenant as ten
on ten.id = ma.id

LEFT JOIN `arealytics-databricks_unity_catalog`.arealyticscurated.dimlandlord as lal
on lal.id = ma.id

LEFT JOIN `arealytics-databricks_unity_catalog`.arealyticscurated.dimagent as agt
on agt.id = ma.id

LEFT JOIN `arealytics-databricks_unity_catalog`.arealyticscurated.DimCalendar as c 
ON c.DateKey = CAST(DATE_FORMAT(current_date(), 'yyyyMMdd') AS INT)

where 
year(cast(ma.commencementdate as date)) is not null 
-- ec.FaceRentAnnual >= 2000
-- and ec.FaceRentAnnual <= 1500000 

and pd.PropertyID is not null
and ma.id not in (select RegExOut1 from reiv_al_exculde where RegExOut1 is not null)