#### USE THIS FUNCTION

import re
from pyspark.sql.functions import udf
from pyspark.sql.types import IntegerType

# Regular expression patterns
year_pattern = r'(\b\d+\.?\d*|\b(?:one|two|three|four|five|six|seven|eight|nine|ten|eleven|twelve|thirteen|fourteen|fifteen|sixteen|seventeen|eighteen|nineteen|twenty(?:\s(?:one|two|three|four|five|six|seven|eight|nine))?|thirty)\b)\s*(?:\(\d+\))?(\s*Years?|\s*Yrs?)'
month_pattern = r'(\b\d+\.?\d*|\b(?:one|two|three|four|five|six|seven|eight|nine|ten|eleven|twelve)\b)\s*(?:\(\d+\))?(\s*Months?|\s*Mths?)'
day_pattern = r'(\b\d+\.?\d*)\s*(?:\(\d+\))?(\s*Days?|\s*Dys?)'
week_pattern = r'(\b\d+\.?\d*)\s*(?:\(\d+\))?(\s*Weeks?|\s*Wks?)'
# singular_value_pattern = r'^\b(one|two|three|four|five|six|seven|eight|nine|ten|1|2|3|4|5|6|7|8|9|10)\s*(?:\((\d+)\))?\b$'
singular_value_pattern = r'^\b(one|two|three|four|five|six|seven|eight|nine|ten|1|2|3|4|5|6|7|8|9|10)\b'

# Function to convert text to number
def convert_text_to_number(text):
    word_to_number = {
        'one': 1, 'two': 2, 'three': 3, 'four': 4, 'five': 5,
        'six': 6, 'seven': 7, 'eight': 8, 'nine': 9, 'ten': 10,
        'eleven': 11, 'twelve': 12, 'thirteen': 13, 'fourteen': 14,
        'fifteen': 15, 'sixteen': 16, 'seventeen': 17, 'eighteen': 18,
        'nineteen': 19, 'twenty': 20, 'thirty': 30
    }

    text = text.lower().strip()
    if text in word_to_number:
        return word_to_number[text]

    if text.startswith('twenty-'):
        base = word_to_number['twenty']
        remainder = text.split('-')[-1]
        if remainder in word_to_number:
            return base + word_to_number[remainder]

    if text.isdigit():
        return int(text)

    try:
        return float(text)
    except ValueError:
        pass

    return None

# Functions to extract durations
def extract_total_further_term(description):
    if description is None:
        return 0

    # Check if the description explicitly mentions a time unit
    if "month" in description.lower() or "year" in description.lower() or "day" in description.lower() or "week" in description.lower():
        # If so, use the existing logic to handle years, months, days, weeks
        total_months = 0
        total_months += extract_duration(description, year_pattern)
        total_months += extract_duration(description, month_pattern)
        total_months += extract_duration(description, day_pattern)
        total_months += extract_duration(description, week_pattern, weeks=True)
        return total_months
    else:
        # For descriptions without a specified unit, check for singular values and default to years if applicable
        match = re.match(singular_value_pattern, description, re.IGNORECASE)
        if match:
            num_text = match.group(0)  # This captures the entire match
            num = convert_text_to_number(num_text)
            return num * 12
        else:
            # If no pattern matches, return 0 as we cannot determine the duration
            return 0

def extract_duration(description, pattern, weeks=False):
    total_months = 0
    matches = re.findall(pattern, description, re.IGNORECASE)
    for match in matches:
        if isinstance(match, tuple):
            num_text, _ = match
        else:
            num_text = match
        num = convert_text_to_number(num_text)
        if weeks:
            total_months += (num * 7) // 30  # Convert weeks to days, then to months
        elif 'Year' in pattern or 'Yr' in pattern:
            total_months += num * 12
        elif 'Month' in pattern or 'Mth' in pattern:
            total_months += num
        elif 'Day' in pattern or 'Dy' in pattern:
            total_months += num // 30
    return total_months

# # Convert the Python function to a UDF
# extract_total_term_udf = udf(extract_total_term, IntegerType())

# # Register the UDF
# spark.udf.register("extract_total_term", extract_total_term_udf)

# # Testing the function
# test_values = ["THREE (3) YEARS "]

# for value in test_values:
#     print(f"{value}: {extract_total_term(value)} months")