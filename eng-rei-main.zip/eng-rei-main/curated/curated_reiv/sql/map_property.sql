%sql
CREATE OR REPLACE TABLE `arealytics-databricks_unity_catalog`.arealyticscurated.reiv_pid_link AS
SELECT 
    id,
    formatted_address,
    REGEXP_SUBSTR(street_number, '\\d+') AS Street_Number_cleaned,
    street_number,
    COALESCE(
        CAST(SPLIT(street_number, '-')[0] AS INT),
        CAST(REGEXP_SUBSTR(street_number, '\\d+') AS INT)
    ) AS StreetNumberMin,
    CAST(
        CASE 
            WHEN street_number LIKE '%-%' THEN
                SPLIT(street_number, '-')[1]
            ELSE
                NULL
        END AS INT
    ) AS StreetNumberMax,
    suburb,
    Unit,
    postal_code,
    latitude,
    longitude,
    CASE 
        WHEN unit = '00 00' OR unit IN ('00', '', '0') THEN NULL 
        ELSE REGEXP_EXTRACT(unit, '(\\d+)', 1)
    END as Cleaned_Unit,
    REGEXP_REPLACE(street_name, CONCAT('\\s+(', suffix_list.suffix_regex, ')$'), '') as Cleaned_Street_Name,
    CAST(NULL as INT) as PropertyID
FROM 
    `arealytics-databricks_unity_catalog`.arealyticstrusted.reiv_geocoded_data
CROSS JOIN 
(SELECT concat_ws('|', collect_list(suffix),'Cres','Parade') as suffix_regex FROM `arealytics-databricks_unity_catalog`.arealyticstrusted.propertysuffixmap) as suffix_list
where cast(LoadDate as date) = '2024-06-18';

-----------------------------------------

-- CREATE OR REPLACE TABLE reiv_temp AS
WITH RankedMatches AS (
    SELECT 
        LT.id AS id,
        A.ParentID AS PropertyID,
        LT.formatted_address,
        A.AddressText AS AL_address,
        LT.postal_code AS `REIV_ZipCode`, 
        A.ZipCode AS `AL_ZipCode`,
        LT.suburb AS `REIV_City`,
        CTY.CityName AS `AL_City`,
        LT.Cleaned_Street_Name AS `REIV_StreetName`,
        A.AddressStreetName AS `AL_StreetName`,
        P.CondoTypeID,
        LT.StreetNumberMin AS REIV_StreetNumberMin,
        LT.StreetNumberMax AS REIV_StreetNumberMax,
        A.StreetNumberMin AS AL_StreetNumberMin,
        A.StreetNumberMax AS AL_StreetNumberMax,
        ROW_NUMBER() OVER (
            PARTITION BY LT.id 
            ORDER BY (COALESCE(A.StreetNumberMax, A.StreetNumberMin) - A.StreetNumberMin) ASC
        ) AS rn
    FROM `arealytics-databricks_unity_catalog`.arealyticscurated.reiv_pid_link LT 
    LEFT JOIN `arealytics-databricks_unity_catalog`.arealyticstrusted.Address A ON A.ParentTableID=1 
        AND A.IsActive=1 AND LT.postal_code = A.ZipCode 
        AND lower(LT.Cleaned_Street_Name)=lower(A.AddressStreetName)
        AND 
        (
		LT.Street_Number_cleaned =  A.StreetNumberMin
		OR 
        LT.Street_Number_cleaned =  A.StreetNumberMax
        OR
        LT.StreetNumberMin BETWEEN A.StreetNumberMin AND COALESCE(A.StreetNumberMax, A.StreetNumberMin))
        -- AND LT.Cleaned_Street_Name=A.AddressStreetName AND (LT.street_number = A.StreetNumberMin OR LT.street_number BETWEEN A.StreetNumberMin AND A.StreetNumberMax)
    LEFT JOIN `arealytics-databricks_unity_catalog`.arealyticstrusted.Property_detail P ON P.PropertyID=A.ParentID
    LEFT JOIN `arealytics-databricks_unity_catalog`.arealyticstrusted.PropertySummary PS on PS.PropertyID=P.PropertyID 
    LEFT JOIN `arealytics-databricks_unity_catalog`.arealyticstrusted.City CTY ON CTY.CityID=A.CityID AND LT.suburb= CTY.CityName
    LEFT JOIN `arealytics-databricks_unity_catalog`.arealyticstrusted.propertysuffixmap as suff on p.StreetSuffix1 = suff.SuffixID
    WHERE LT.Cleaned_Unit is null and (P.CondoTypeID is null or P.CondoTypeID <> 2) and PS.ResearchTypeID <> 4
)
SELECT * FROM RankedMatches --9 839 -- 10 472
-- where id= '102409'
WHERE rn = 1;

UPDATE `arealytics-databricks_unity_catalog`.arealyticscurated.reiv_pid_link lt
SET lt.PropertyID = (
    SELECT MAX(t.PropertyID)
    FROM reiv_temp t 
    WHERE lt.id = t.id
)
WHERE lt.PropertyID IS NULL;

-- -- ---------------PASS 2
CREATE OR REPLACE TABLE REIV_Temp AS
WITH RankedMatches AS (
SELECT 
        LT.id AS id,
        A.ParentID AS PropertyID,
        LT.formatted_address,
        A.AddressText AS AL_address,
        LT.postal_code AS `REIV_ZipCode`, 
        A.ZipCode AS `AL_ZipCode`,
        LT.suburb AS `REIV_City`,
        CTY.CityName AS `AL_City`,
        LT.Cleaned_Street_Name AS `REIV_StreetName`,
        A.AddressStreetName AS `AL_StreetName`,
        P.CondoTypeID,
        LT.StreetNumberMin AS REIV_StreetNumberMin,
        LT.StreetNumberMax AS REIV_StreetNumberMax,
        A.StreetNumberMin AS AL_StreetNumberMin,
        A.StreetNumberMax AS AL_StreetNumberMax,
        P.CondoUnit as AL_unit,
        LT.unit as REIV_unit,
        ROW_NUMBER() OVER (
            PARTITION BY LT.id 
            ORDER BY (COALESCE(A.StreetNumberMax, A.StreetNumberMin) - A.StreetNumberMin) ASC
        ) AS rn
    FROM `arealytics-databricks_unity_catalog`.arealyticscurated.reiv_pid_link LT 
LEFT JOIN 
    `arealytics-databricks_unity_catalog`.arealyticstrusted.Address A 
ON 
    A.ParentTableID=1 AND A.IsActive=1 
    AND LT.postal_code = A.ZipCode AND lower(LT.Cleaned_Street_Name)=lower(A.AddressStreetName)
    -- AND LT.StreetNumberMin BETWEEN A.StreetNumberMin AND COALESCE(A.StreetNumberMax, A.StreetNumberMin)
    AND 
        (
		LT.Street_Number_cleaned =  A.StreetNumberMin
		OR 
        LT.Street_Number_cleaned =  A.StreetNumberMax
        OR
        LT.StreetNumberMin BETWEEN A.StreetNumberMin AND COALESCE(A.StreetNumberMax, A.StreetNumberMin))
LEFT JOIN 
    `arealytics-databricks_unity_catalog`.arealyticstrusted.Property_detail P 
ON 
    P.PropertyID = A.ParentID AND (P.CondoUnit IS NULL OR P.CondoUnit = LT.unit)
LEFT JOIN 
    `arealytics-databricks_unity_catalog`.arealyticstrusted.PropertySummary PS 
ON 
    PS.PropertyID = P.PropertyID 
LEFT JOIN 
    `arealytics-databricks_unity_catalog`.arealyticstrusted.City CTY 
ON 
    CTY.CityID = A.CityID AND LT.suburb = CTY.CityName
LEFT JOIN `arealytics-databricks_unity_catalog`.arealyticstrusted.propertysuffixmap as suff on p.StreetSuffix1 = suff.SuffixID
WHere  
LT.Cleaned_Unit IS NOT NULL 
and PS.ResearchTypeID <> 4
AND P.CondoUnit IS NOT NULL
)
SELECT * FROM RankedMatches
where rn = 1;

UPDATE `arealytics-databricks_unity_catalog`.arealyticscurated.reiv_pid_link lt
SET lt.PropertyID = (
    SELECT MAX(t.PropertyID)
    FROM reiv_temp t 
    WHERE lt.id = t.id
)
WHERE lt.PropertyID IS NULL;

-- -- ---------------PASS 3
CREATE  OR REPLACE TABLE REIV_Temp AS
WITH RankedMatches AS (
SELECT 
        LT.id AS id,
        A.ParentID AS PropertyID,
        LT.formatted_address,
        A.AddressText AS AL_address,
        LT.postal_code AS `REIV_ZipCode`, 
        A.ZipCode AS `AL_ZipCode`,
        LT.suburb AS `REIV_City`,
        CTY.CityName AS `AL_City`,
        LT.Cleaned_Street_Name AS `REIV_StreetName`,
        A.AddressStreetName AS `AL_StreetName`,
        P.CondoTypeID,
        LT.StreetNumberMin AS REIV_StreetNumberMin,
        LT.StreetNumberMax AS REIV_StreetNumberMax,
        A.StreetNumberMin AS AL_StreetNumberMin,
        A.StreetNumberMax AS AL_StreetNumberMax,
        P.CondoUnit as AL_unit,
        LT.unit as REIV_unit,
        ROW_NUMBER() OVER (
            PARTITION BY LT.id 
            ORDER BY (COALESCE(A.StreetNumberMax, A.StreetNumberMin) - A.StreetNumberMin) ASC
        ) AS rn
    FROM `arealytics-databricks_unity_catalog`.arealyticscurated.reiv_pid_link LT 
LEFT JOIN 
    `arealytics-databricks_unity_catalog`.arealyticstrusted.Address A 
ON 
    A.ParentTableID=1 AND A.IsActive=1 AND LT.postal_code = A.ZipCode AND lower(LT.Cleaned_Street_Name)=lower(A.AddressStreetName) 
    AND 
        (
		LT.Street_Number_cleaned =  A.StreetNumberMin
		OR 
        LT.Street_Number_cleaned =  A.StreetNumberMax
        OR
        LT.StreetNumberMin BETWEEN A.StreetNumberMin AND COALESCE(A.StreetNumberMax, A.StreetNumberMin))
LEFT JOIN 
    `arealytics-databricks_unity_catalog`.arealyticstrusted.Property_detail P 
ON 
    P.PropertyID = A.ParentID AND (P.CondoUnit IS NULL OR P.CondoUnit = LT.unit)
LEFT JOIN 
    `arealytics-databricks_unity_catalog`.arealyticstrusted.PropertySummary PS 
ON 
    PS.PropertyID = P.PropertyID 
LEFT JOIN 
    `arealytics-databricks_unity_catalog`.arealyticstrusted.City CTY 
ON 
    CTY.CityID = A.CityID AND LT.suburb = CTY.CityName
LEFT JOIN `arealytics-databricks_unity_catalog`.arealyticstrusted.propertysuffixmap as suff on p.StreetSuffix1 = suff.SuffixID

WHERE 
     LT.PropertyID IS NULL 
    AND PS.ResearchTypeID <> 4
    )   
SELECT * FROM RankedMatches
WHERE rn = 1;

UPDATE `arealytics-databricks_unity_catalog`.arealyticscurated.reiv_pid_link lt
SET lt.PropertyID = (
    SELECT MAX(t.PropertyID)
    FROM reiv_temp t 
    WHERE lt.id = t.id
)
WHERE lt.PropertyID IS NULL;
