from pyspark.sql import SparkSession
from pyspark.sql.functions import col, udf, when, concat_ws, collect_list
from pyspark.sql.types import ArrayType, StringType
import json
import spacy
import re

# Load the custom SpaCy model
nlp = spacy.load('/dbfs/tmp/lease_extraction_v2/lease_model')

def normalize_percentage(percentage):
    # Strip spaces and leading zeros
    normalized = percentage.replace(" ", "")
    # Format decimal percentages to remove unnecessary trailing zeros
    match = re.match(r'(\d+\.?\d*)%', normalized)
    if match:
        # Convert to float then back to string to remove trailing zeros, convert to int if no decimal
        num = float(match.group(1))
        num = int(num) if num.is_integer() else num
        return f"{num}%"
    return normalized

# Define UDFs for entity extraction and missing percentage capture
def extract_entities(text, labels_of_interest):
    if text is None:
        return []
    doc = nlp(str(text))
    # Normalize, ensure uniqueness, and format percentages
    return list(set([normalize_percentage(ent.text) for ent in doc.ents if ent.label_ in labels_of_interest]))

def capture_missing_percentages(original_text):
    if original_text is None:
        return []
    # Normalize and format found percentages
    return list(set([normalize_percentage(match) for match in re.findall(r'\b\d+%|\b\d+\.\d+%', original_text)]))

extract_entities_udf = udf(lambda text: json.dumps(extract_entities(text, ["Escalation %"]) if extract_entities(text, ["Escalation %"]) else None), StringType())
capture_missing_percentages_udf = udf(lambda text: json.dumps(capture_missing_percentages(text) if capture_missing_percentages(text) else None), StringType())

def process_table_with_spacy_model(spark, table_name, field_name, id_field, labels_of_interest):
    labels_udf = udf(lambda text: extract_entities(text, labels_of_interest), ArrayType(StringType()))

    df = spark.sql(f"SELECT {id_field}, {field_name} FROM {table_name}")
    df = df.withColumn("extracted_entities", labels_udf(col(field_name)))
    df = df.withColumn("extracted_entities", when(col("extracted_entities").getItem(0).isNull(), udf(lambda text: capture_missing_percentages(text), ArrayType(StringType()))(col(field_name))).otherwise(col("extracted_entities")))
    df = df.withColumn("extracted_entities", when(col("extracted_entities").isNull(), None).otherwise(concat_ws(", ", col("extracted_entities"))))
    df = df.groupBy(id_field).agg(concat_ws(", ", collect_list("extracted_entities")).alias("extracted_entities"))
    df = df.withColumn("extracted_entities", when(col("extracted_entities") == "", None).otherwise(col("extracted_entities")))
    return df

# Spark session
spark = SparkSession.builder.getOrCreate()

# Example usage
tenantname_df = process_table_with_spacy_model(
    spark,
    "`arealytics-databricks_unity_catalog`.arealyticstrusted.reiv_lease_main",
    "rentincreasedescription",
    "id",
    ["Escalation %"]  # Labels of interest
)
tenantname_df.write.format("delta").mode("overwrite").saveAsTable("reiv_escalation_delta")
# tenantname_df.createOrReplaceTable("reiv_escalation_temp")
# data = spark.sql("select * from reiv_escalation ")
# display(data)
