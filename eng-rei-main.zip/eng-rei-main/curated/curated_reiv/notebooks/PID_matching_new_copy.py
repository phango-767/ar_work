# Databricks notebook source
# MAGIC %sql
# MAGIC create or replace table pid_unit_bridge as
# MAGIC Select distinct a.ParentID, p.CondoUnit
# MAGIC from `arealytics-databricks_unity_catalog`.arealyticstrusted.Address as A
# MAGIC
# MAGIC LEFT JOIN `arealytics-databricks_unity_catalog`.arealyticstrusted.Property_detail P 
# MAGIC ON a.ParentID = p.PropertyID
# MAGIC
# MAGIC where p.CondoUnit is not null

# COMMAND ----------

# MAGIC %sql
# MAGIC -- reiv
# MAGIC CREATE OR REPLACE TABLE rea_pid_link AS
# MAGIC SELECT 
# MAGIC     uid as id,
# MAGIC     REGEXP_SUBSTR(streetNumber, '\\d+') AS Street_Number_cleaned,
# MAGIC     streetNumber as streetNumber,
# MAGIC     TRIM(COALESCE(
# MAGIC         CAST(SPLIT(streetNumber, '-')[0] AS INT),
# MAGIC         CAST(REGEXP_SUBSTR(streetNumber, '\\d+') AS INT)
# MAGIC     )) AS StreetNumberMin,
# MAGIC     TRIM(CAST(
# MAGIC         CASE 
# MAGIC             WHEN streetNumber LIKE '%-%' THEN
# MAGIC                 SPLIT(streetNumber, '-')[1]
# MAGIC             ELSE
# MAGIC                 NULL
# MAGIC         END AS INT
# MAGIC     )) AS StreetNumberMax,
# MAGIC     city as suburb,
# MAGIC     suiteNumber as unit,
# MAGIC     cast(cast(postcode as INT) as STRING) as postal_code,
# MAGIC     CASE 
# MAGIC         WHEN suiteNumber = '00 00' OR suiteNumber IN ('00', '', '0') THEN NULL 
# MAGIC         ELSE TRIM(REGEXP_EXTRACT(suiteNumber, '(\\d+)', 1))
# MAGIC     END as Cleaned_Unit,
# MAGIC     streetName,
# MAGIC     REGEXP_REPLACE(streetName, CONCAT('\\s+(', suffix_list.suffix_regex, ')$'), '') as Cleaned_Street_Name,
# MAGIC     CAST(NULL as INT) as PropertyID,
# MAGIC     CAST(NULL as string) as LayerPassed,
# MAGIC     CAST(NULL as INT) as PhasedPassed
# MAGIC FROM 
# MAGIC     `arealytics-databricks_unity_catalog`.arealyticstrusted.scraped_address_nsw
# MAGIC CROSS JOIN 
# MAGIC     (SELECT concat_ws('|', collect_list(concat(suffix, '|', SuffixName))) as suffix_regex 
# MAGIC      FROM `arealytics-databricks_unity_catalog`.arealyticstrusted.propertysuffixmap
# MAGIC     ) as suffix_list;

# COMMAND ----------

# MAGIC %sql
# MAGIC --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
# MAGIC -- Phase 1: FREEHOLD
# MAGIC --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
# MAGIC
# MAGIC --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
# MAGIC --- Pass 1: Exact Min Street Number Match
# MAGIC CREATE OR REPLACE TABLE reiv_temp_exact AS
# MAGIC WITH RankedMatches AS (
# MAGIC     SELECT 
# MAGIC         LT.id AS id,
# MAGIC         A.ParentID AS PropertyID,
# MAGIC         LT.postal_code AS `REIV_ZipCode`, 
# MAGIC         A.ZipCode AS `AL_ZipCode`,
# MAGIC         LT.suburb AS `REIV_City`,
# MAGIC         CTY.CityName AS `AL_City`,
# MAGIC         LT.Cleaned_Street_Name AS `REIV_StreetName`,
# MAGIC         A.AddressStreetName AS `AL_StreetName`,
# MAGIC         LT.StreetNumberMin AS REIV_StreetNumberMin,
# MAGIC         LT.StreetNumberMax AS REIV_StreetNumberMax,
# MAGIC         A.StreetNumberMin AS AL_StreetNumberMin,
# MAGIC         A.StreetNumberMax AS AL_StreetNumberMax,
# MAGIC         ROW_NUMBER() OVER (
# MAGIC             PARTITION BY LT.id 
# MAGIC             ORDER BY 1
# MAGIC         ) AS rn
# MAGIC     FROM rea_pid_link LT 
# MAGIC     LEFT JOIN `arealytics-databricks_unity_catalog`.arealyticstrusted.Address A ON
# MAGIC         A.ParentTableID = 1 AND 
# MAGIC         A.IsActive = 1 AND 
# MAGIC         LT.postal_code = A.ZipCode AND 
# MAGIC         LOWER(LT.Cleaned_Street_Name) = LOWER(A.AddressStreetName) AND
# MAGIC         LT.StreetNumberMin = A.StreetNumberMin
# MAGIC     LEFT JOIN `arealytics-databricks_unity_catalog`.arealyticstrusted.City CTY ON
# MAGIC         CTY.CityID = A.CityID AND 
# MAGIC         LT.suburb = CTY.CityName
# MAGIC     WHERE LT.Cleaned_Unit IS NULL
# MAGIC )
# MAGIC SELECT * FROM RankedMatches WHERE rn = 1;
# MAGIC
# MAGIC -- Update after Pass 1
# MAGIC UPDATE rea_pid_link lt
# MAGIC SET lt.PropertyID = (
# MAGIC     SELECT MAX(t.PropertyID)
# MAGIC     FROM reiv_temp_exact t 
# MAGIC     WHERE lt.id = t.id
# MAGIC ),
# MAGIC lt.LayerPassed = '1',
# MAGIC lt.PhasedPassed = '1'
# MAGIC WHERE lt.PropertyID IS NULL;
# MAGIC
# MAGIC --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
# MAGIC --- Pass 2: Exact Max Street Number Match
# MAGIC CREATE OR REPLACE TABLE reiv_temp_exact AS
# MAGIC WITH RankedMatches AS (
# MAGIC     SELECT 
# MAGIC         LT.id AS id,
# MAGIC         A.ParentID AS PropertyID,
# MAGIC         LT.postal_code AS `REIV_ZipCode`, 
# MAGIC         A.ZipCode AS `AL_ZipCode`,
# MAGIC         LT.suburb AS `REIV_City`,
# MAGIC         CTY.CityName AS `AL_City`,
# MAGIC         LT.Cleaned_Street_Name AS `REIV_StreetName`,
# MAGIC         A.AddressStreetName AS `AL_StreetName`,
# MAGIC         LT.StreetNumberMin AS REIV_StreetNumberMin,
# MAGIC         LT.StreetNumberMax AS REIV_StreetNumberMax,
# MAGIC         A.StreetNumberMin AS AL_StreetNumberMin,
# MAGIC         A.StreetNumberMax AS AL_StreetNumberMax,
# MAGIC         ROW_NUMBER() OVER (
# MAGIC             PARTITION BY LT.id 
# MAGIC             ORDER BY 1
# MAGIC         ) AS rn
# MAGIC     FROM rea_pid_link LT 
# MAGIC     LEFT JOIN `arealytics-databricks_unity_catalog`.arealyticstrusted.Address A ON
# MAGIC         A.ParentTableID = 1 AND 
# MAGIC         A.IsActive = 1 AND 
# MAGIC         LT.postal_code = A.ZipCode AND 
# MAGIC         LOWER(LT.Cleaned_Street_Name) = LOWER(A.AddressStreetName) AND
# MAGIC         LT.StreetNumberMax = A.StreetNumberMax
# MAGIC     LEFT JOIN `arealytics-databricks_unity_catalog`.arealyticstrusted.City CTY ON
# MAGIC         CTY.CityID = A.CityID AND 
# MAGIC         LT.suburb = CTY.CityName
# MAGIC     WHERE LT.Cleaned_Unit IS NULL
# MAGIC )
# MAGIC SELECT * FROM RankedMatches WHERE rn = 1;
# MAGIC
# MAGIC -- Update after Pass 2
# MAGIC UPDATE rea_pid_link lt
# MAGIC SET lt.PropertyID = (
# MAGIC     SELECT MAX(t.PropertyID)
# MAGIC     FROM reiv_temp_exact t 
# MAGIC     WHERE lt.id = t.id
# MAGIC ),
# MAGIC lt.LayerPassed = '2',
# MAGIC lt.PhasedPassed = '1'
# MAGIC WHERE lt.PropertyID IS NULL;
# MAGIC
# MAGIC --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
# MAGIC --- Pass 3: Range Matches
# MAGIC CREATE OR REPLACE TABLE reiv_temp_range AS
# MAGIC WITH RankedMatches AS (
# MAGIC     SELECT 
# MAGIC         LT.id AS id,
# MAGIC         A.ParentID AS PropertyID,
# MAGIC         LT.postal_code AS `REIV_ZipCode`, 
# MAGIC         A.ZipCode AS `AL_ZipCode`,
# MAGIC         LT.suburb AS `REIV_City`,
# MAGIC         CTY.CityName AS `AL_City`,
# MAGIC         LT.Cleaned_Street_Name AS `REIV_StreetName`,
# MAGIC         A.AddressStreetName AS `AL_StreetName`,
# MAGIC         LT.StreetNumberMin AS REIV_StreetNumberMin,
# MAGIC         LT.StreetNumberMax AS REIV_StreetNumberMax,
# MAGIC         A.StreetNumberMin AS AL_StreetNumberMin,
# MAGIC         A.StreetNumberMax AS AL_StreetNumberMax,
# MAGIC         match_score_udf(LT.StreetNumberMin, LT.StreetNumberMax, A.StreetNumberMin, A.StreetNumberMax) AS match_score
# MAGIC     FROM rea_pid_link LT 
# MAGIC     LEFT JOIN `arealytics-databricks_unity_catalog`.arealyticstrusted.Address A ON
# MAGIC         A.ParentTableID = 1 AND 
# MAGIC         A.IsActive = 1 AND 
# MAGIC         LT.postal_code = A.ZipCode AND 
# MAGIC         LOWER(LT.Cleaned_Street_Name) = LOWER(A.AddressStreetName) 
# MAGIC
# MAGIC     -- LEFT JOIN `arealytics-databricks_unity_catalog`.arealyticstrusted.Property_detail P ON
# MAGIC     --     P.PropertyID = A.ParentID AND 
# MAGIC     --     LT.Cleaned_Unit = P.CondoUnit
# MAGIC
# MAGIC     LEFT JOIN `arealytics-databricks_unity_catalog`.arealyticstrusted.City CTY ON
# MAGIC         CTY.CityID = A.CityID AND 
# MAGIC         LT.suburb = CTY.CityName
# MAGIC
# MAGIC     LEFT JOIN rea_pid_link as C ON
# MAGIC     c.id = lt.id
# MAGIC
# MAGIC     WHERE LT.Cleaned_Unit IS NULL 
# MAGIC     and c.PropertyID IS NULL -- Only mathces records that have not been matched
# MAGIC )
# MAGIC SELECT * FROM RankedMatches 
# MAGIC WHERE match_score = 1;
# MAGIC
# MAGIC -- Update after Phase 3
# MAGIC UPDATE rea_pid_link lt
# MAGIC SET lt.PropertyID = (
# MAGIC     SELECT MAX(t.PropertyID)
# MAGIC     FROM reiv_temp_range t 
# MAGIC     WHERE lt.id = t.id
# MAGIC ),
# MAGIC lt.LayerPassed = '3',
# MAGIC lt.PhasedPassed = '1'
# MAGIC WHERE lt.PropertyID IS NULL;
# MAGIC
# MAGIC --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
# MAGIC -- Phase 2: STRATA
# MAGIC --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
# MAGIC
# MAGIC --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
# MAGIC --- Pass 1: Exact Min Street Number Match
# MAGIC CREATE OR REPLACE TABLE reiv_temp_exact AS
# MAGIC WITH RankedMatches AS (
# MAGIC     SELECT 
# MAGIC         LT.id AS id,
# MAGIC         A.ParentID AS PropertyID,
# MAGIC         LT.postal_code AS `REIV_ZipCode`, 
# MAGIC         A.ZipCode AS `AL_ZipCode`,
# MAGIC         LT.suburb AS `REIV_City`,
# MAGIC         CTY.CityName AS `AL_City`,
# MAGIC         LT.Cleaned_Street_Name AS `REIV_StreetName`,
# MAGIC         A.AddressStreetName AS `AL_StreetName`,
# MAGIC         LT.StreetNumberMin AS REIV_StreetNumberMin,
# MAGIC         LT.StreetNumberMax AS REIV_StreetNumberMax,
# MAGIC         A.StreetNumberMin AS AL_StreetNumberMin,
# MAGIC         A.StreetNumberMax AS AL_StreetNumberMax,
# MAGIC         ROW_NUMBER() OVER (
# MAGIC             PARTITION BY LT.id 
# MAGIC             ORDER BY 1
# MAGIC         ) AS rn
# MAGIC     FROM rea_pid_link LT 
# MAGIC
# MAGIC     LEFT JOIN `arealytics-databricks_unity_catalog`.arealyticstrusted.Address A ON
# MAGIC         A.ParentTableID = 1 AND 
# MAGIC         A.IsActive = 1 AND 
# MAGIC         LT.postal_code = A.ZipCode AND 
# MAGIC         LOWER(LT.Cleaned_Street_Name) = LOWER(A.AddressStreetName) AND
# MAGIC         LT.StreetNumberMin = A.StreetNumberMin
# MAGIC
# MAGIC     LEFT JOIN `arealytics-databricks_unity_catalog`.arealyticstrusted.City CTY ON
# MAGIC         CTY.CityID = A.CityID AND 
# MAGIC         LT.suburb = CTY.CityName
# MAGIC
# MAGIC     LEFT JOIN rea_pid_link as C ON
# MAGIC     c.id = lt.id
# MAGIC
# MAGIC     WHERE LT.Cleaned_Unit IS NOT NULL
# MAGIC     and c.PropertyID IS NULL -- Only mathces records that have not been matched
# MAGIC )
# MAGIC SELECT * FROM RankedMatches 
# MAGIC WHERE rn = 1;
# MAGIC
# MAGIC -- Update after Pass 1
# MAGIC UPDATE rea_pid_link lt
# MAGIC SET lt.PropertyID = (
# MAGIC     SELECT MAX(t.PropertyID)
# MAGIC     FROM reiv_temp_exact t 
# MAGIC     WHERE lt.id = t.id
# MAGIC ),
# MAGIC lt.LayerPassed = '1',
# MAGIC lt.PhasedPassed = '2'
# MAGIC WHERE lt.PropertyID IS NULL;
# MAGIC
# MAGIC --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
# MAGIC --- Pass 2: Exact Max Street Number Match
# MAGIC CREATE OR REPLACE TABLE reiv_temp_exact AS
# MAGIC WITH RankedMatches AS (
# MAGIC     SELECT 
# MAGIC         LT.id AS id,
# MAGIC         A.ParentID AS PropertyID,
# MAGIC         LT.postal_code AS `REIV_ZipCode`, 
# MAGIC         A.ZipCode AS `AL_ZipCode`,
# MAGIC         LT.suburb AS `REIV_City`,
# MAGIC         CTY.CityName AS `AL_City`,
# MAGIC         LT.Cleaned_Street_Name AS `REIV_StreetName`,
# MAGIC         A.AddressStreetName AS `AL_StreetName`,
# MAGIC         LT.StreetNumberMin AS REIV_StreetNumberMin,
# MAGIC         LT.StreetNumberMax AS REIV_StreetNumberMax,
# MAGIC         A.StreetNumberMin AS AL_StreetNumberMin,
# MAGIC         A.StreetNumberMax AS AL_StreetNumberMax,
# MAGIC         ROW_NUMBER() OVER (
# MAGIC             PARTITION BY LT.id 
# MAGIC             ORDER BY 1
# MAGIC         ) AS rn
# MAGIC     FROM rea_pid_link LT 
# MAGIC
# MAGIC     LEFT JOIN `arealytics-databricks_unity_catalog`.arealyticstrusted.Address A ON
# MAGIC         A.ParentTableID = 1 AND 
# MAGIC         A.IsActive = 1 AND 
# MAGIC         LT.postal_code = A.ZipCode AND 
# MAGIC         LOWER(LT.Cleaned_Street_Name) = LOWER(A.AddressStreetName) AND
# MAGIC         LT.StreetNumberMax = A.StreetNumberMax
# MAGIC
# MAGIC     LEFT JOIN `arealytics-databricks_unity_catalog`.arealyticstrusted.City CTY ON
# MAGIC         CTY.CityID = A.CityID AND 
# MAGIC         LT.suburb = CTY.CityName
# MAGIC
# MAGIC     LEFT JOIN rea_pid_link as C ON
# MAGIC     c.id = lt.id
# MAGIC
# MAGIC     WHERE LT.Cleaned_Unit IS NOT NULL
# MAGIC     and c.PropertyID IS NULL -- Only mathces records that have not been matched
# MAGIC )
# MAGIC SELECT * FROM RankedMatches WHERE rn = 1;
# MAGIC
# MAGIC -- Update after Pass 2
# MAGIC UPDATE rea_pid_link lt
# MAGIC SET lt.PropertyID = (
# MAGIC     SELECT MAX(t.PropertyID)
# MAGIC     FROM reiv_temp_exact t 
# MAGIC     WHERE lt.id = t.id
# MAGIC ),
# MAGIC lt.LayerPassed = '2',
# MAGIC lt.PhasedPassed = '2'
# MAGIC WHERE lt.PropertyID IS NULL;
# MAGIC
# MAGIC --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
# MAGIC --- Pass 3: Range Matches
# MAGIC -- CREATE OR REPLACE TABLE reiv_temp_range AS
# MAGIC -- WITH RankedMatches AS (
# MAGIC --     SELECT 
# MAGIC --         LT.id AS id,
# MAGIC --         a.ParentID AS PropertyID,
# MAGIC --         br.CondoUnit as AL_Unit,
# MAGIC --         a.AddressText as AL_adress,
# MAGIC --         LT.Cleaned_Unit as Reiv_Unit,
# MAGIC --         LT.StreetNumberMin AS REIV_StreetNumberMin,
# MAGIC --         LT.StreetNumberMax AS REIV_StreetNumberMax,
# MAGIC --         LT.suburb AS `REIV_City`,
# MAGIC --         LT.Cleaned_Street_Name AS `REIV_StreetName`,
# MAGIC --         A.AddressStreetName AS `AL_StreetName`,
# MAGIC --         A.StreetNumberMin AS AL_StreetNumberMin,
# MAGIC --         A.StreetNumberMax AS AL_StreetNumberMax,
# MAGIC --         match_score_udf(LT.StreetNumberMin, LT.StreetNumberMax, A.StreetNumberMin, A.StreetNumberMax) AS match_score
# MAGIC --     FROM rea_pid_link LT 
# MAGIC --     LEFT JOIN `arealytics-databricks_unity_catalog`.arealyticstrusted.Address A ON
# MAGIC --         A.ParentTableID = 1 AND 
# MAGIC --         A.IsActive = 1 AND 
# MAGIC --         LT.postal_code = A.ZipCode AND 
# MAGIC --         LOWER(LT.Cleaned_Street_Name) = LOWER(A.AddressStreetName) 
# MAGIC
# MAGIC --     LEFT JOIN `arealytics-databricks_unity_catalog`.arealyticstrusted.Property_detail P ON
# MAGIC --         P.PropertyID = A.ParentID AND 
# MAGIC --         LT.Cleaned_Unit = P.CondoUnit
# MAGIC
# MAGIC --     LEFT JOIN `arealytics-databricks_unity_catalog`.arealyticstrusted.City CTY ON
# MAGIC --         CTY.CityID = A.CityID AND 
# MAGIC --         LT.suburb = CTY.CityName
# MAGIC
# MAGIC --     LEFT JOIN rea_pid_link as C ON
# MAGIC --     c.id = lt.id
# MAGIC
# MAGIC --     WHERE LT.Cleaned_Unit IS NOT NULL
# MAGIC --     and c.PropertyID IS NULL -- Only mathces records that have not been matched
# MAGIC -- )
# MAGIC -- SELECT * FROM RankedMatches 
# MAGIC -- WHERE match_score = 1;
# MAGIC
# MAGIC -- -- Update after Phase 3
# MAGIC -- UPDATE rea_pid_link lt
# MAGIC -- SET lt.PropertyID = (
# MAGIC --     SELECT MAX(t.PropertyID)
# MAGIC --     FROM reiv_temp_range t 
# MAGIC --     WHERE lt.id = t.id
# MAGIC -- ),
# MAGIC -- lt.LayerPassed = '3',
# MAGIC -- lt.PhasedPassed = '2'
# MAGIC -- WHERE lt.PropertyID IS NULL;
# MAGIC
# MAGIC --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
# MAGIC --- Phase 4: Unit Matching
# MAGIC CREATE OR REPLACE TABLE reiv_temp_units AS
# MAGIC WITH RankedMatches AS (
# MAGIC     SELECT 
# MAGIC         LT.id AS id,
# MAGIC         a.ParentID AS PropertyID,
# MAGIC         br.CondoUnit as AL_Unit,
# MAGIC         a.AddressText as AL_adress,
# MAGIC         LT.Cleaned_Unit as Reiv_Unit,
# MAGIC         LT.StreetNumberMin AS REIV_StreetNumberMin,
# MAGIC         LT.StreetNumberMax AS REIV_StreetNumberMax,
# MAGIC         LT.suburb AS `REIV_City`,
# MAGIC         LT.Cleaned_Street_Name AS `REIV_StreetName`,
# MAGIC         A.AddressStreetName AS `AL_StreetName`,
# MAGIC         A.StreetNumberMin AS AL_StreetNumberMin,
# MAGIC         A.StreetNumberMax AS AL_StreetNumberMax,
# MAGIC         match_score_udf(LT.StreetNumberMin, LT.StreetNumberMax, A.StreetNumberMin, A.StreetNumberMax) AS match_score
# MAGIC     FROM rea_pid_link LT 
# MAGIC     LEFT JOIN `arealytics-databricks_unity_catalog`.arealyticstrusted.Address A ON
# MAGIC         A.ParentTableID = 1 AND 
# MAGIC         A.IsActive = 1 AND 
# MAGIC         LT.postal_code = A.ZipCode AND 
# MAGIC         LOWER(LT.Cleaned_Street_Name) = LOWER(A.AddressStreetName) 
# MAGIC
# MAGIC     -- temp table of pids with unit matches
# MAGIC     LEFT JOIN pid_unit_bridge AS br ON
# MAGIC     br.ParentID = A.ParentID
# MAGIC     and br.CondoUnit = LT.Cleaned_Unit
# MAGIC             
# MAGIC     -- LEFT JOIN `arealytics-databricks_unity_catalog`.arealyticstrusted.Property_detail P ON
# MAGIC     --     P.PropertyID = A.ParentID AND 
# MAGIC     --     LT.Cleaned_Unit = P.CondoUnit
# MAGIC
# MAGIC     LEFT JOIN `arealytics-databricks_unity_catalog`.arealyticstrusted.City CTY ON
# MAGIC         CTY.CityID = A.CityID AND 
# MAGIC         LT.suburb = CTY.CityName
# MAGIC
# MAGIC     LEFT JOIN rea_pid_link as C ON
# MAGIC     c.id = lt.id
# MAGIC
# MAGIC     WHERE LT.Cleaned_Unit IS NOT NULL AND br.CondoUnit IS NOT NULL
# MAGIC     and c.PropertyID IS NULL -- Only mathces records that have not been matched
# MAGIC )
# MAGIC SELECT * FROM RankedMatches 
# MAGIC WHERE match_score = 1;
# MAGIC
# MAGIC -- Update after Phase 4
# MAGIC UPDATE rea_pid_link lt
# MAGIC SET lt.PropertyID = (
# MAGIC     SELECT MAX(t.PropertyID)
# MAGIC     FROM reiv_temp_units t 
# MAGIC     WHERE lt.id = t.id
# MAGIC ),
# MAGIC lt.LayerPassed = '4',
# MAGIC lt.PhasedPassed = '2'
# MAGIC WHERE lt.PropertyID IS NULL;
# MAGIC
# MAGIC --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
# MAGIC -- Phase 3: Remaining addresses 
# MAGIC --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
# MAGIC
# MAGIC --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
# MAGIC --- Pass 1: Exact Min Street Number Match
# MAGIC CREATE OR REPLACE TABLE reiv_temp_exact AS
# MAGIC WITH RankedMatches AS (
# MAGIC     SELECT 
# MAGIC         LT.id AS id,
# MAGIC         A.ParentID AS PropertyID,
# MAGIC         LT.postal_code AS `REIV_ZipCode`, 
# MAGIC         A.ZipCode AS `AL_ZipCode`,
# MAGIC         LT.suburb AS `REIV_City`,
# MAGIC         CTY.CityName AS `AL_City`,
# MAGIC         LT.Cleaned_Street_Name AS `REIV_StreetName`,
# MAGIC         A.AddressStreetName AS `AL_StreetName`,
# MAGIC         LT.StreetNumberMin AS REIV_StreetNumberMin,
# MAGIC         LT.StreetNumberMax AS REIV_StreetNumberMax,
# MAGIC         A.StreetNumberMin AS AL_StreetNumberMin,
# MAGIC         A.StreetNumberMax AS AL_StreetNumberMax,
# MAGIC         ROW_NUMBER() OVER (
# MAGIC             PARTITION BY LT.id 
# MAGIC             ORDER BY 1
# MAGIC         ) AS rn
# MAGIC     FROM rea_pid_link LT 
# MAGIC     LEFT JOIN `arealytics-databricks_unity_catalog`.arealyticstrusted.Address A ON
# MAGIC         A.ParentTableID = 1 AND 
# MAGIC         A.IsActive = 1 AND 
# MAGIC         LT.postal_code = A.ZipCode AND 
# MAGIC         LOWER(LT.Cleaned_Street_Name) = LOWER(A.AddressStreetName) AND
# MAGIC         LT.StreetNumberMin = A.StreetNumberMin
# MAGIC     LEFT JOIN `arealytics-databricks_unity_catalog`.arealyticstrusted.City CTY ON
# MAGIC         CTY.CityID = A.CityID AND 
# MAGIC         LT.suburb = CTY.CityName
# MAGIC )
# MAGIC SELECT * FROM RankedMatches WHERE rn = 1;
# MAGIC
# MAGIC -- Update after Pass 1
# MAGIC UPDATE rea_pid_link lt
# MAGIC SET lt.PropertyID = (
# MAGIC     SELECT MAX(t.PropertyID)
# MAGIC     FROM reiv_temp_exact t 
# MAGIC     WHERE lt.id = t.id
# MAGIC ),
# MAGIC lt.LayerPassed = '1',
# MAGIC lt.PhasedPassed = '3'
# MAGIC WHERE lt.PropertyID IS NULL;
# MAGIC
# MAGIC --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
# MAGIC --- Pass 2: Exact Max Street Number Match
# MAGIC CREATE OR REPLACE TABLE reiv_temp_exact AS
# MAGIC WITH RankedMatches AS (
# MAGIC     SELECT 
# MAGIC         LT.id AS id,
# MAGIC         A.ParentID AS PropertyID,
# MAGIC         LT.postal_code AS `REIV_ZipCode`, 
# MAGIC         A.ZipCode AS `AL_ZipCode`,
# MAGIC         LT.suburb AS `REIV_City`,
# MAGIC         CTY.CityName AS `AL_City`,
# MAGIC         LT.Cleaned_Street_Name AS `REIV_StreetName`,
# MAGIC         A.AddressStreetName AS `AL_StreetName`,
# MAGIC         LT.StreetNumberMin AS REIV_StreetNumberMin,
# MAGIC         LT.StreetNumberMax AS REIV_StreetNumberMax,
# MAGIC         A.StreetNumberMin AS AL_StreetNumberMin,
# MAGIC         A.StreetNumberMax AS AL_StreetNumberMax,
# MAGIC         ROW_NUMBER() OVER (
# MAGIC             PARTITION BY LT.id 
# MAGIC             ORDER BY 1
# MAGIC         ) AS rn
# MAGIC     FROM rea_pid_link LT 
# MAGIC     LEFT JOIN `arealytics-databricks_unity_catalog`.arealyticstrusted.Address A ON
# MAGIC         A.ParentTableID = 1 AND 
# MAGIC         A.IsActive = 1 AND 
# MAGIC         LT.postal_code = A.ZipCode AND 
# MAGIC         LOWER(LT.Cleaned_Street_Name) = LOWER(A.AddressStreetName) AND
# MAGIC         LT.StreetNumberMax = A.StreetNumberMax
# MAGIC     LEFT JOIN `arealytics-databricks_unity_catalog`.arealyticstrusted.City CTY ON
# MAGIC         CTY.CityID = A.CityID AND 
# MAGIC         LT.suburb = CTY.CityName
# MAGIC )
# MAGIC SELECT * FROM RankedMatches WHERE rn = 1;
# MAGIC
# MAGIC -- Update after Pass 2
# MAGIC UPDATE rea_pid_link lt
# MAGIC SET lt.PropertyID = (
# MAGIC     SELECT MAX(t.PropertyID)
# MAGIC     FROM reiv_temp_exact t 
# MAGIC     WHERE lt.id = t.id
# MAGIC ),
# MAGIC lt.LayerPassed = '2',
# MAGIC lt.PhasedPassed = '3'
# MAGIC WHERE lt.PropertyID IS NULL;
# MAGIC
# MAGIC --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
# MAGIC --- Pass 3: Range Matches
# MAGIC CREATE OR REPLACE TABLE reiv_temp_units AS
# MAGIC WITH RankedMatches AS (
# MAGIC     SELECT 
# MAGIC         LT.id AS id,
# MAGIC         a.ParentID AS PropertyID,
# MAGIC         -- br.CondoUnit as AL_Unit,
# MAGIC         a.AddressText as AL_adress,
# MAGIC         LT.Cleaned_Unit as Reiv_Unit,
# MAGIC         LT.StreetNumberMin AS REIV_StreetNumberMin,
# MAGIC         LT.StreetNumberMax AS REIV_StreetNumberMax,
# MAGIC         LT.suburb AS `REIV_City`,
# MAGIC         LT.Cleaned_Street_Name AS `REIV_StreetName`,
# MAGIC         A.AddressStreetName AS `AL_StreetName`,
# MAGIC         A.StreetNumberMin AS AL_StreetNumberMin,
# MAGIC         A.StreetNumberMax AS AL_StreetNumberMax,
# MAGIC         match_score_udf(LT.StreetNumberMin, LT.StreetNumberMax, A.StreetNumberMin, A.StreetNumberMax) AS match_score
# MAGIC     FROM rea_pid_link LT 
# MAGIC     LEFT JOIN `arealytics-databricks_unity_catalog`.arealyticstrusted.Address A ON
# MAGIC         A.ParentTableID = 1 AND 
# MAGIC         A.IsActive = 1 AND 
# MAGIC         LT.postal_code = A.ZipCode AND 
# MAGIC         LOWER(LT.Cleaned_Street_Name) = LOWER(A.AddressStreetName) 
# MAGIC             
# MAGIC     -- LEFT JOIN `arealytics-databricks_unity_catalog`.arealyticstrusted.Property_detail P ON
# MAGIC     --     P.PropertyID = A.ParentID AND 
# MAGIC     --     LT.Cleaned_Unit = P.CondoUnit
# MAGIC
# MAGIC     LEFT JOIN `arealytics-databricks_unity_catalog`.arealyticstrusted.City CTY ON
# MAGIC         CTY.CityID = A.CityID AND 
# MAGIC         LT.suburb = CTY.CityName
# MAGIC
# MAGIC     LEFT JOIN rea_pid_link as C ON
# MAGIC     c.id = lt.id
# MAGIC
# MAGIC     WHERE c.PropertyID IS NULL -- Only mathces records that have not been matched
# MAGIC )
# MAGIC SELECT * FROM RankedMatches 
# MAGIC WHERE match_score = 1;
# MAGIC
# MAGIC -- Update after Phase 3
# MAGIC UPDATE rea_pid_link lt
# MAGIC SET lt.PropertyID = (
# MAGIC     SELECT MAX(t.PropertyID)
# MAGIC     FROM reiv_temp_range t 
# MAGIC     WHERE lt.id = t.id
# MAGIC ),
# MAGIC lt.LayerPassed = '3',
# MAGIC lt.PhasedPassed = '3'
# MAGIC WHERE lt.PropertyID IS NULL;
# MAGIC

# COMMAND ----------

import re
from pyspark.sql.functions import udf
from pyspark.sql.types import IntegerType

def clean_number(s):
    # Function to remove all non-digit characters from a string
    cleaned = re.sub(r'\D', '', s) if s is not None else ''
    return int(cleaned) if cleaned != '' else None

def address_match_score(street_number_min, street_number_max, al_street_number_min, al_street_number_max):
    # Clean numbers to ensure only numeric parts are used
    street_number_min = clean_number(street_number_min)
    street_number_max = clean_number(street_number_max) if street_number_max else None
    al_street_number_min = clean_number(al_street_number_min)
    al_street_number_max = clean_number(al_street_number_max)

    # Check for missing data after cleaning
    if None in [street_number_min, al_street_number_min, al_street_number_max]:
        return 1000  # High score for any missing or non-parsable data

    # Calculate parity
    min_parity = street_number_min % 2
    al_min_parity = al_street_number_min % 2
    al_max_parity = al_street_number_max % 2

    # Ensure parity consistency within the address range
    if al_min_parity != al_max_parity:
        return 1000  # Invalidate ranges that mix odd and even numbers

    # Check whether a number is even or odd and within range
    if min_parity == al_min_parity:
        if street_number_min == al_street_number_min or (street_number_max == al_street_number_max and street_number_max is not None):
            return 0  # Exact match
        if al_street_number_min <= street_number_min <= al_street_number_max:
            return 1  # Within range match
        else:
            # Calculate for numbers outside the range
            proximity_to_min = abs(street_number_min - al_street_number_min)
            proximity_to_max = abs(street_number_min - al_street_number_max)
            return min(proximity_to_min, proximity_to_max)  # Return the minimum proximity as the score
    else:
        return 1000  # High score if parity does not match

# Register the UDF in PySpark
match_score_udf = udf(address_match_score, IntegerType())
spark.udf.register("match_score_udf", match_score_udf)

# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC WITH RankedMatches AS (
# MAGIC     SELECT 
# MAGIC         LT.id AS id,
# MAGIC         -- br.ParentID AS PropertyID,
# MAGIC         a.ParentID,
# MAGIC         -- br.CondoUnit as AL_Unit,
# MAGIC         a.AddressText as AL_adress,
# MAGIC         -- LT.Cleaned_Unit as Reiv_Unit,
# MAGIC         LT.StreetNumberMin AS REIV_StreetNumberMin,
# MAGIC         LT.StreetNumberMax AS REIV_StreetNumberMax,
# MAGIC         LT.suburb AS `REIV_City`,
# MAGIC         LT.Cleaned_Street_Name AS `REIV_StreetName`,
# MAGIC         A.AddressStreetName AS `AL_StreetName`,
# MAGIC         A.StreetNumberMin AS AL_StreetNumberMin,
# MAGIC         A.StreetNumberMax AS AL_StreetNumberMax,
# MAGIC         LT.Cleaned_Unit AS `REIV_Unit`,
# MAGIC         match_score_udf(LT.StreetNumberMin, LT.StreetNumberMax, A.StreetNumberMin, A.StreetNumberMax) AS match_score
# MAGIC     FROM rea_pid_link LT 
# MAGIC     LEFT JOIN `arealytics-databricks_unity_catalog`.arealyticstrusted.Address A ON
# MAGIC         A.ParentTableID = 1 AND 
# MAGIC         A.IsActive = 1 AND 
# MAGIC         LT.postal_code = A.ZipCode AND 
# MAGIC         LOWER(LT.Cleaned_Street_Name) = LOWER(A.AddressStreetName) 
# MAGIC
# MAGIC     -- LEFT JOIN `arealytics-databricks_unity_catalog`.arealyticstrusted.Property_detail P ON
# MAGIC     --     P.PropertyID = A.ParentID AND 
# MAGIC     --     LT.Cleaned_Unit = P.CondoUnit
# MAGIC
# MAGIC     LEFT JOIN `arealytics-databricks_unity_catalog`.arealyticstrusted.City CTY ON
# MAGIC         CTY.CityID = A.CityID AND 
# MAGIC         LT.suburb = CTY.CityName
# MAGIC
# MAGIC     LEFT JOIN rea_pid_link as C ON
# MAGIC     c.id = lt.id
# MAGIC
# MAGIC     WHERE LT.Cleaned_Unit IS NULL 
# MAGIC     and c.PropertyID IS NULL
# MAGIC )
# MAGIC SELECT * FROM RankedMatches 
# MAGIC WHERE match_score = 1
# MAGIC -- limit 20
# MAGIC where id = '00051400096'
# MAGIC
# MAGIC --00002600088
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC -- create or replace table rea_pid_link_unmatched as
# MAGIC Select 
# MAGIC a.id
# MAGIC ,a.propertyid
# MAGIC ,p.CondoUnit as AL_Unit
# MAGIC ,b.AddressText as AL_adress
# MAGIC -- ,b.AddressStreetName as AL_streetName
# MAGIC -- ,b.StreetNumberMin as AL_StreetNumberMin
# MAGIC -- ,b.StreetNumberMax as AL_StreetNumberMax
# MAGIC ,a.Cleaned_Unit as Rei_Unit
# MAGIC ,a.StreetNumberMin as Rei_StreetNumberMin
# MAGIC ,a.StreetNumberMax as Rei_StreetNumberMax
# MAGIC ,a.Cleaned_Street_Name as Rei_streetName
# MAGIC ,a.suburb
# MAGIC ,a.postal_code
# MAGIC ,b.ZipCode as AL_Postal_code
# MAGIC   ,CASE
# MAGIC         WHEN LOWER(a.Cleaned_Street_Name) = LOWER(b.AddressStreetName) AND
# MAGIC              a.StreetNumberMin = b.StreetNumberMin AND
# MAGIC              a.StreetNumberMax = b.StreetNumberMax THEN 'Correct Match - Exact'
# MAGIC         WHEN LOWER(a.Cleaned_Street_Name) = LOWER(b.AddressStreetName) AND
# MAGIC              a.StreetNumberMin BETWEEN b.StreetNumberMin AND b.StreetNumberMax THEN 'Correct Match - Range'
# MAGIC         WHEN LOWER(a.Cleaned_Street_Name) = LOWER(b.AddressStreetName) AND
# MAGIC              NOT (a.StreetNumberMin BETWEEN b.StreetNumberMin AND b.StreetNumberMax) THEN 'Incorrect Match - Range'
# MAGIC         WHEN trim(LOWER(a.Cleaned_Street_Name)) != trim(LOWER(b.AddressStreetName)) THEN 'Matched to Alt address'
# MAGIC         ELSE 'Potential Issue'
# MAGIC     END AS Match_Quality
# MAGIC ,a.PhasedPassed
# MAGIC ,a.layerpassed
# MAGIC from rea_pid_link as A
# MAGIC
# MAGIC LEFT JOIN `arealytics-databricks_unity_catalog`.arealyticstrusted.Address B ON A.PropertyID = B.ParentID 
# MAGIC and B.ParentTableID=1 
# MAGIC
# MAGIC LEFT JOIN 
# MAGIC     `arealytics-databricks_unity_catalog`.arealyticstrusted.Property_detail P 
# MAGIC ON 
# MAGIC     P.PropertyID = B.ParentID 
# MAGIC
# MAGIC where a.PropertyID is not null -- 4847
# MAGIC
# MAGIC order by p.CondoUnit desc
# MAGIC -- limit 50
# MAGIC -- and A.postal_code is not null
# MAGIC -- and a.id = '00062700296'
# MAGIC -- and a.StreetNumberMax > b.StreetNumberMax
# MAGIC -- and a.StreetNumberMin > b.StreetNumberMin
# MAGIC -- where lower(b.AddressText) like "%quay%"
# MAGIC -- and a.propertyid = '138587'

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from rea_pid_link_unmatched
# MAGIC -- where postal_code is not null
# MAGIC -- where id = '00002600021'
