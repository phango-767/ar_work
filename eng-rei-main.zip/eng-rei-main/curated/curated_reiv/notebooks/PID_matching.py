# Databricks notebook source
# MAGIC %sql
# MAGIC CREATE OR REPLACE TABLE `arealytics-databricks_unity_catalog`.arealyticscurated.reiv_pid_link AS
# MAGIC SELECT
# MAGIC id,
# MAGIC     formatted_address,
# MAGIC     REGEXP_SUBSTR(street_number, '\\d+') AS Street_Number_cleaned,
# MAGIC     street_number,
# MAGIC     CAST(
# MAGIC         SPLIT(REGEXP_SUBSTR(street_number, '\\d+'), '-')[0] AS INT
# MAGIC     ) AS StreetNumberMin,
# MAGIC     CAST(
# MAGIC         CASE 
# MAGIC             WHEN street_number LIKE '%-%' THEN
# MAGIC                 SPLIT(street_number, '-')[1]
# MAGIC             ELSE
# MAGIC                 NULL
# MAGIC         END AS INT
# MAGIC     ) AS StreetNumberMax,
# MAGIC     suburb,
# MAGIC     Unit,
# MAGIC     postal_code,
# MAGIC     latitude,
# MAGIC     longitude,
# MAGIC     CASE 
# MAGIC         WHEN unit = '00 00' OR unit IN ('00', '', '0') THEN NULL 
# MAGIC         ELSE REGEXP_EXTRACT(unit, '(\\d+)', 1)
# MAGIC     END as Cleaned_Unit,
# MAGIC     REGEXP_REPLACE(street_name, CONCAT('\\s+(', suffix_list.suffix_regex, ')$'), '') as Cleaned_Street_Name,
# MAGIC     CAST(NULL as INT) as PropertyID,
# MAGIC     NULL as LayerPassed
# MAGIC FROM 
# MAGIC     `arealytics-databricks_unity_catalog`.arealyticstrusted.reiv_geocoded_data --input table
# MAGIC CROSS JOIN 
# MAGIC (SELECT concat_ws('|', collect_list(suffix),'Cres','Parade') as suffix_regex FROM `arealytics-databricks_unity_catalog`.arealyticstrusted.propertysuffixmap) as suffix_list
# MAGIC where cast(LoadDate as date) = '2024-06-18'; -- date of data
# MAGIC     
# MAGIC -- Phase 1: Exact Matches Min
# MAGIC CREATE OR REPLACE TABLE reiv_temp_exact AS
# MAGIC WITH RankedMatches AS (
# MAGIC     SELECT 
# MAGIC         LT.id AS id,
# MAGIC         A.ParentID AS PropertyID,
# MAGIC         LT.postal_code AS `REIV_ZipCode`, 
# MAGIC         A.ZipCode AS `AL_ZipCode`,
# MAGIC         LT.suburb AS `REIV_City`,
# MAGIC         CTY.CityName AS `AL_City`,
# MAGIC         LT.Cleaned_Street_Name AS `REIV_StreetName`,
# MAGIC         A.AddressStreetName AS `AL_StreetName`,
# MAGIC         LT.StreetNumberMin AS REIV_StreetNumberMin,
# MAGIC         LT.StreetNumberMax AS REIV_StreetNumberMax,
# MAGIC         A.StreetNumberMin AS AL_StreetNumberMin,
# MAGIC         A.StreetNumberMax AS AL_StreetNumberMax,
# MAGIC         ROW_NUMBER() OVER (
# MAGIC             PARTITION BY LT.id 
# MAGIC             ORDER BY 1
# MAGIC         ) AS rn
# MAGIC     FROM `arealytics-databricks_unity_catalog`.arealyticscurated.reiv_pid_link LT 
# MAGIC     LEFT JOIN `arealytics-databricks_unity_catalog`.arealyticstrusted.Address A ON
# MAGIC         A.ParentTableID = 1 AND 
# MAGIC         A.IsActive = 1 AND 
# MAGIC         LT.postal_code = A.ZipCode AND 
# MAGIC         LOWER(LT.Cleaned_Street_Name) = LOWER(A.AddressStreetName) AND
# MAGIC         LT.StreetNumberMin = A.StreetNumberMin
# MAGIC     LEFT JOIN `arealytics-databricks_unity_catalog`.arealyticstrusted.City CTY ON
# MAGIC         CTY.CityID = A.CityID AND 
# MAGIC         LT.suburb = CTY.CityName
# MAGIC     -- WHERE LT.Cleaned_Unit IS NULL
# MAGIC )
# MAGIC SELECT * FROM RankedMatches WHERE rn = 1;
# MAGIC
# MAGIC -- Update after Phase 1
# MAGIC UPDATE `arealytics-databricks_unity_catalog`.arealyticscurated.reiv_pid_link lt
# MAGIC SET lt.PropertyID = (
# MAGIC     SELECT MAX(t.PropertyID)
# MAGIC     FROM reiv_temp_exact t 
# MAGIC     WHERE lt.id = t.id
# MAGIC ),
# MAGIC lt.LayerPassed = '1'
# MAGIC WHERE lt.PropertyID IS NULL;
# MAGIC
# MAGIC -- Phase 2: Exact Matches Max
# MAGIC CREATE OR REPLACE TABLE reiv_temp_exact AS
# MAGIC WITH RankedMatches AS (
# MAGIC     SELECT 
# MAGIC         LT.id AS id,
# MAGIC         A.ParentID AS PropertyID,
# MAGIC         LT.postal_code AS `REIV_ZipCode`, 
# MAGIC         A.ZipCode AS `AL_ZipCode`,
# MAGIC         LT.suburb AS `REIV_City`,
# MAGIC         CTY.CityName AS `AL_City`,
# MAGIC         LT.Cleaned_Street_Name AS `REIV_StreetName`,
# MAGIC         A.AddressStreetName AS `AL_StreetName`,
# MAGIC         LT.StreetNumberMin AS REIV_StreetNumberMin,
# MAGIC         LT.StreetNumberMax AS REIV_StreetNumberMax,
# MAGIC         A.StreetNumberMin AS AL_StreetNumberMin,
# MAGIC         A.StreetNumberMax AS AL_StreetNumberMax,
# MAGIC         ROW_NUMBER() OVER (
# MAGIC             PARTITION BY LT.id 
# MAGIC             ORDER BY 1
# MAGIC         ) AS rn
# MAGIC     FROM `arealytics-databricks_unity_catalog`.arealyticscurated.reiv_pid_link  LT 
# MAGIC     LEFT JOIN `arealytics-databricks_unity_catalog`.arealyticstrusted.Address A ON
# MAGIC         A.ParentTableID = 1 AND 
# MAGIC         A.IsActive = 1 AND 
# MAGIC         LT.postal_code = A.ZipCode AND 
# MAGIC         LOWER(LT.Cleaned_Street_Name) = LOWER(A.AddressStreetName) AND
# MAGIC         LT.StreetNumberMax = A.StreetNumberMax
# MAGIC     LEFT JOIN `arealytics-databricks_unity_catalog`.arealyticstrusted.City CTY ON
# MAGIC         CTY.CityID = A.CityID AND 
# MAGIC         LT.suburb = CTY.CityName
# MAGIC     WHERE LT.Cleaned_Unit IS NULL
# MAGIC )
# MAGIC SELECT * FROM RankedMatches WHERE rn = 1;
# MAGIC
# MAGIC -- Update after Phase 2
# MAGIC UPDATE `arealytics-databricks_unity_catalog`.arealyticscurated.reiv_pid_link lt
# MAGIC SET lt.PropertyID = (
# MAGIC     SELECT MAX(t.PropertyID)
# MAGIC     FROM reiv_temp_exact t 
# MAGIC     WHERE lt.id = t.id
# MAGIC ),
# MAGIC lt.LayerPassed = '2'
# MAGIC WHERE lt.PropertyID IS NULL;
# MAGIC
# MAGIC -- Phase 3: Range Matches
# MAGIC CREATE OR REPLACE TABLE reiv_temp_range AS
# MAGIC WITH RankedMatches AS (
# MAGIC     SELECT 
# MAGIC         LT.id AS id,
# MAGIC         A.ParentID AS PropertyID,
# MAGIC         LT.postal_code AS `REIV_ZipCode`, 
# MAGIC         A.ZipCode AS `AL_ZipCode`,
# MAGIC         LT.suburb AS `REIV_City`,
# MAGIC         CTY.CityName AS `AL_City`,
# MAGIC         LT.Cleaned_Street_Name AS `REIV_StreetName`,
# MAGIC         A.AddressStreetName AS `AL_StreetName`,
# MAGIC         LT.StreetNumberMin AS REIV_StreetNumberMin,
# MAGIC         LT.StreetNumberMax AS REIV_StreetNumberMax,
# MAGIC         A.StreetNumberMin AS AL_StreetNumberMin,
# MAGIC         A.StreetNumberMax AS AL_StreetNumberMax,
# MAGIC         ROW_NUMBER() OVER (
# MAGIC             PARTITION BY LT.id 
# MAGIC             ORDER BY CASE
# MAGIC                 WHEN LT.StreetNumberMin BETWEEN A.StreetNumberMin AND A.StreetNumberMax THEN 0
# MAGIC                 WHEN LT.StreetNumberMax BETWEEN A.StreetNumberMin AND A.StreetNumberMax THEN 0
# MAGIC                 ELSE 1
# MAGIC             END
# MAGIC         ) AS rn
# MAGIC     FROM `arealytics-databricks_unity_catalog`.arealyticscurated.reiv_pid_link LT 
# MAGIC     LEFT JOIN `arealytics-databricks_unity_catalog`.arealyticstrusted.Address A ON
# MAGIC         A.ParentTableID = 1 AND 
# MAGIC         A.IsActive = 1 AND 
# MAGIC         LT.postal_code = A.ZipCode AND 
# MAGIC         LOWER(LT.Cleaned_Street_Name) = LOWER(A.AddressStreetName) AND
# MAGIC         (
# MAGIC             LT.StreetNumberMin BETWEEN A.StreetNumberMin AND A.StreetNumberMax OR
# MAGIC             LT.StreetNumberMax BETWEEN A.StreetNumberMin AND A.StreetNumberMax
# MAGIC         )
# MAGIC     LEFT JOIN `arealytics-databricks_unity_catalog`.arealyticstrusted.City CTY ON
# MAGIC         CTY.CityID = A.CityID AND 
# MAGIC         LT.suburb = CTY.CityName
# MAGIC     WHERE LT.Cleaned_Unit IS NULL
# MAGIC )
# MAGIC SELECT * FROM RankedMatches WHERE rn = 1 AND rn > 1;
# MAGIC
# MAGIC -- Update after Phase 3
# MAGIC UPDATE `arealytics-databricks_unity_catalog`.arealyticscurated.reiv_pid_link lt
# MAGIC SET lt.PropertyID = (
# MAGIC     SELECT MAX(t.PropertyID)
# MAGIC     FROM reiv_temp_range t 
# MAGIC     WHERE lt.id = t.id
# MAGIC ),
# MAGIC lt.LayerPassed = '3'
# MAGIC WHERE lt.PropertyID IS NULL;
# MAGIC
# MAGIC -- Phase 4: Unit Matching
# MAGIC CREATE OR REPLACE TABLE reiv_temp_units AS
# MAGIC WITH RankedMatches AS (
# MAGIC     SELECT 
# MAGIC         LT.id AS id,
# MAGIC         A.ParentID AS PropertyID,
# MAGIC         LT.postal_code AS `REIV_ZipCode`, 
# MAGIC         A.ZipCode AS `AL_ZipCode`,
# MAGIC         LT.suburb AS `REIV_City`,
# MAGIC         CTY.CityName AS `AL_City`,
# MAGIC         LT.Cleaned_Street_Name AS `REIV_StreetName`,
# MAGIC         A.AddressStreetName AS `AL_StreetName`,
# MAGIC         LT.StreetNumberMin AS REIV_StreetNumberMin,
# MAGIC         LT.StreetNumberMax AS REIV_StreetNumberMax,
# MAGIC         A.StreetNumberMin AS AL_StreetNumberMin,
# MAGIC         A.StreetNumberMax AS AL_StreetNumberMax,
# MAGIC         LT.Cleaned_Unit AS `REIV_Unit`,
# MAGIC         P.CondoUnit AS `AL_Unit`,  -- Correct field for unit number from Property_detail table
# MAGIC         ROW_NUMBER() OVER (
# MAGIC             PARTITION BY LT.id 
# MAGIC             ORDER BY CASE
# MAGIC                 WHEN LT.Cleaned_Unit = P.CondoUnit THEN 0  -- Ensuring correct unit number comparison
# MAGIC                 ELSE 1
# MAGIC             END
# MAGIC         ) AS rn
# MAGIC     FROM `arealytics-databricks_unity_catalog`.arealyticscurated.reiv_pid_link LT 
# MAGIC     LEFT JOIN `arealytics-databricks_unity_catalog`.arealyticstrusted.Address A ON
# MAGIC         A.ParentTableID = 1 AND 
# MAGIC         A.IsActive = 1 AND 
# MAGIC         LT.postal_code = A.ZipCode AND 
# MAGIC         LOWER(LT.Cleaned_Street_Name) = LOWER(A.AddressStreetName) AND
# MAGIC         (
# MAGIC             LT.StreetNumberMin BETWEEN A.StreetNumberMin AND A.StreetNumberMax OR
# MAGIC             LT.StreetNumberMax BETWEEN A.StreetNumberMin AND A.StreetNumberMax
# MAGIC         )
# MAGIC     LEFT JOIN `arealytics-databricks_unity_catalog`.arealyticstrusted.Property_detail P ON
# MAGIC         P.PropertyID = A.ParentID AND 
# MAGIC         LT.Cleaned_Unit = P.CondoUnit
# MAGIC     LEFT JOIN `arealytics-databricks_unity_catalog`.arealyticstrusted.City CTY ON
# MAGIC         CTY.CityID = A.CityID AND 
# MAGIC         LT.suburb = CTY.CityName
# MAGIC     WHERE LT.Cleaned_Unit IS NOT NULL AND P.CondoUnit IS NOT NULL
# MAGIC )
# MAGIC SELECT * FROM RankedMatches WHERE rn = 1;
# MAGIC
# MAGIC -- Update after Phase 4
# MAGIC UPDATE `arealytics-databricks_unity_catalog`.arealyticscurated.reiv_pid_link lt
# MAGIC SET lt.PropertyID = (
# MAGIC     SELECT MAX(t.PropertyID)
# MAGIC     FROM reiv_temp_units t 
# MAGIC     WHERE lt.id = t.id
# MAGIC ),
# MAGIC lt.LayerPassed = '4'
# MAGIC WHERE lt.PropertyID IS NULL;
# MAGIC
# MAGIC -- Phase 4: Fuzzy Matching
# MAGIC -- CREATE OR REPLACE TABLE reiv_temp_fuzzy AS
# MAGIC -- WITH RankedMatches AS (
# MAGIC --     SELECT 
# MAGIC --         LT.id AS id,
# MAGIC --         A.ParentID AS PropertyID,
# MAGIC --         LT.postal_code AS `REIV_ZipCode`, 
# MAGIC --         A.ZipCode AS `AL_ZipCode`,
# MAGIC --         LT.suburb AS `REIV_City`,
# MAGIC --         CTY.CityName AS `AL_City`,
# MAGIC --         LT.Cleaned_Street_Name AS `REIV_StreetName`,
# MAGIC --         A.AddressStreetName AS `AL_StreetName`,
# MAGIC --         levenshtein(LT.Cleaned_Street_Name, A.AddressStreetName) AS Lev_Distance,
# MAGIC --         ROW_NUMBER() OVER (
# MAGIC --             PARTITION BY LT.id 
# MAGIC --             ORDER BY levenshtein(LT.Cleaned_Street_Name, A.AddressStreetName)
# MAGIC --         ) AS rn
# MAGIC --     FROM rea_pid_link LT 
# MAGIC --     LEFT JOIN `arealytics-databricks_unity_catalog`.arealyticstrusted.Address A ON
# MAGIC --         A.ParentTableID = 1 AND 
# MAGIC --         A.IsActive = 1 AND 
# MAGIC --         LT.postal_code = A.ZipCode
# MAGIC --     LEFT JOIN `arealytics-databricks_unity_catalog`.arealyticstrusted.City CTY ON
# MAGIC --         CTY.CityID = A.CityID AND 
# MAGIC --         LT.suburb = CTY.CityName
# MAGIC --     WHERE LT.Cleaned_Unit IS NULL  -- Assuming still filtering on non-unit addresses
# MAGIC --         AND (LT.PropertyID IS NULL OR LT.PropertyID = '')  -- Applying fuzzy logic to unmatched records
# MAGIC -- )
# MAGIC -- SELECT * FROM RankedMatches WHERE rn = 1 AND Lev_Distance <= 5;  -- Adjust threshold as needed
# MAGIC
# MAGIC -- -- Update after Phase 4
# MAGIC -- UPDATE rea_pid_link lt
# MAGIC -- SET lt.PropertyID = (
# MAGIC --     SELECT MAX(t.PropertyID)
# MAGIC --     FROM reiv_temp_fuzzy t 
# MAGIC --     WHERE lt.id = t.id
# MAGIC -- )
# MAGIC -- WHERE lt.PropertyID IS NULL;
# MAGIC
# MAGIC -- -- Clean up temporary tables if necessary
# MAGIC -- DROP TABLE IF EXISTS reiv_temp_exact;
# MAGIC -- DROP TABLE IF EXISTS reiv_temp_range;
# MAGIC -- DROP TABLE IF EXISTS reiv_temp_units;
# MAGIC -- DROP TABLE IF EXISTS reiv_temp_fuzzy;
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace table rea_pid_link_unmatched as
# MAGIC Select 
# MAGIC a.id
# MAGIC ,a.propertyid
# MAGIC , p.ParcelInfo
# MAGIC ,b.AddressText as AL_adress
# MAGIC ,b.AddressStreetName as AL_streetName
# MAGIC ,a.Cleaned_Street_Name as Rei_streetName
# MAGIC ,b.StreetNumberMin as AL_StreetNumberMin
# MAGIC ,a.StreetNumberMin as Rei_StreetNumberMin
# MAGIC ,b.StreetNumberMax as AL_StreetNumberMax
# MAGIC ,a.StreetNumberMax as Rei_StreetNumberMax
# MAGIC ,a.suburb
# MAGIC ,a.unit
# MAGIC ,a.postal_code
# MAGIC ,b.ZipCode as AL_Postal_code
# MAGIC ,a.Cleaned_Unit
# MAGIC   ,CASE
# MAGIC         WHEN LOWER(a.Cleaned_Street_Name) = LOWER(b.AddressStreetName) AND
# MAGIC              a.StreetNumberMin = b.StreetNumberMin AND
# MAGIC              a.StreetNumberMax = b.StreetNumberMax THEN 'Correct Match - Exact'
# MAGIC         WHEN LOWER(a.Cleaned_Street_Name) = LOWER(b.AddressStreetName) AND
# MAGIC              a.StreetNumberMin BETWEEN b.StreetNumberMin AND b.StreetNumberMax THEN 'Correct Match - Range'
# MAGIC         WHEN LOWER(a.Cleaned_Street_Name) = LOWER(b.AddressStreetName) AND
# MAGIC              NOT (a.StreetNumberMin BETWEEN b.StreetNumberMin AND b.StreetNumberMax) THEN 'Incorrect Match - Range'
# MAGIC         WHEN trim(LOWER(a.Cleaned_Street_Name)) != trim(LOWER(b.AddressStreetName)) THEN 'Matched to Alt address'
# MAGIC         ELSE 'Potential Issue'
# MAGIC     END AS Match_Quality
# MAGIC from rea_pid_link as A
# MAGIC
# MAGIC LEFT JOIN `arealytics-databricks_unity_catalog`.arealyticstrusted.Address B ON A.PropertyID = B.ParentID 
# MAGIC and B.ParentTableID=1 
# MAGIC
# MAGIC LEFT JOIN 
# MAGIC     `arealytics-databricks_unity_catalog`.arealyticstrusted.Property_detail P 
# MAGIC ON 
# MAGIC     P.PropertyID = B.ParentID 
# MAGIC
# MAGIC where a.PropertyID is null -- 4847
# MAGIC -- and A.postal_code is not null
# MAGIC -- where a.id = '00062700006'
# MAGIC -- and a.StreetNumberMax > b.StreetNumberMax
# MAGIC -- and a.StreetNumberMin > b.StreetNumberMin
# MAGIC -- where lower(b.AddressText) like "%quay%"
# MAGIC -- and a.propertyid = '138587'

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from rea_pid_link_unmatched
# MAGIC where id = '00064300002'
