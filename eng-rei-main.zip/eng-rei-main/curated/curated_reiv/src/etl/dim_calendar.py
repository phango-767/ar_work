from pyspark.sql import SparkSession
import importlib
from utils.scd_merge import upsert_data_scd_type_2

def create_and_merge_dim_calendar(spark: SparkSession, config):
    
    # Create temporary view DimCalendar
    spark.sql("""
    CREATE OR REPLACE TEMP VIEW DimCalendar AS
    SELECT
        CAST(DATE_FORMAT(Date, 'yyyyMMdd') AS INT) AS DateKey,
        Date AS FullDate,
        YEAR(Date) AS Year,
        MONTH(Date) AS Month,
        DAY(Date) AS Day,
        QUARTER(Date) AS Quarter,
        WEEKOFYEAR(Date) AS WeekOfYear,
        DAYOFWEEK(Date) AS DayOfWeek,
        CASE
            WHEN DAYOFWEEK(Date) IN (1, 7) THEN 'Weekend' -- If the day is Sunday or Saturday
            ELSE 'Weekday' -- Other days
        END AS DayType
    FROM (
        SELECT EXPLODE(SEQUENCE(TO_DATE('2020-01-01'), TO_DATE('2030-12-31'), INTERVAL 1 DAY)) AS Date
    ) AS Calendar
    """)
    
    # Merge the data using Upsert method and scd_merge module
    upsert_data_scd_type_2(spark, "DimCalendar", 'DateKey', config['dim_calendar_table'], config['dim_calendar_location'])