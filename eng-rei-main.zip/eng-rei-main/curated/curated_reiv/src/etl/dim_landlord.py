# Importing required modules
from pyspark.sql import SparkSession
import importlib

# Importing scd_merge function from utils module
from utils.scd_merge import upsert_data_scd_type_2

# Defining a function which creates a temporary view of a table of required columns from source location
# and upserts the data to destination location using SCD type 2 merge
# arguments: SparkSession - a new session created by a spark application, config - a dictionary of configuration details
def create_and_merge_dim_landlord(spark: SparkSession, config):
    # Getting data from source and creating a temporary view of it
    spark.sql("""
    CREATE OR REPLACE TEMP VIEW DimLandlord AS
    SELECT
        id,
        landlordabn AS LandlordABN,
        landlordacn AS LandlordACN,
        landlordaddress AS Address,
        landlordcontactname AS ContactName,
        landlordemail AS Email,
        landlordfax AS Fax,
        landlordinsuranceperiod AS InsurancePeriod,
        landlordleaselist AS LeaseList,
        landlordmobile AS Mobile,
        landlordname AS Name,
        landlordphone AS Phone,
        landlordpiamount AS PI_Amount,
        landlordpostcode AS Postcode,
        landlordstatusoption AS StatusOption
    FROM `arealytics-databricks_unity_catalog`.arealyticstrusted.reiv_lease_main
    """)

    # Upserting data to destination location using SCD type 2 merge
    upsert_data_scd_type_2(spark, "DimLandlord", 'id', config['dim_landlord_table'], config['dim_landlord_location'])
