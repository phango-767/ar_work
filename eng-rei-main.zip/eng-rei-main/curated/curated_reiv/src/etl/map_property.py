# import SparkSession module from pyspark.sql library
from pyspark.sql import SparkSession

# define a function that reads SQL commands from a file and executes those commands
def execute_sql_from_file(spark: SparkSession, file_path: str):
    """
    Executes SQL commands from a given file.

    Args:
    spark (SparkSession): The Spark session.
    file_path (str): The path to the SQL file.
    """
    # open the SQL file in read mode and assign it to a variable
    with open(file_path, 'r') as file:
        sql_commands = file.read()

    # split the SQL commands by semicolons and execute each command using the SparkSession object
    for command in sql_commands.split(';'):
        if command.strip():
          # execute the SQL command using the spark object
            spark.sql(command.strip())

# define a function that processes the map property data using SQL commands from a file
def process_map_property(spark: SparkSession, sql_file_path: str):
    """
    Processes the map property data using SQL commands from a file.

    Args:
    spark (SparkSession): The Spark session.
    sql_file_path (str): The path to the SQL file containing the commands.
    """
    # call the execute_sql_from_file function to execute the SQL commands from the SQL file
    execute_sql_from_file(spark, sql_file_path)
