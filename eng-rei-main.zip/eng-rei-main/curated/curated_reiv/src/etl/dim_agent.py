from pyspark.sql import SparkSession
import importlib
from utils.scd_merge import upsert_data_scd_type_2

# Function to create a temporary view of the dimensional table "DimAgent" and merge it to the target table using SCD type-2
def create_and_merge_dim_agent(spark: SparkSession, config):
    
    # Create or replace a temporary view of the dimensional table prior to merging
    spark.sql("""
    CREATE OR REPLACE TEMP VIEW DimAgent AS
    SELECT
        id,
        COALESCE(agentabn, 'unknown') AS AgentABN,
        CAST(AgentACN AS DOUBLE) AS AgentACN,
        IF(agencyname = 'nan', 'unknown', agencyname) AS AgencyName,
        COALESCE(agentaddress, 'unknown') AS Address,
        COALESCE(agentcontactname, 'unknown') AS ContactName,
        COALESCE(agentemail, 'unknown') AS Email,
        COALESCE(agentfax, 'unknown') AS Fax,
        COALESCE(agentmobile, 'unknown') AS Mobile, 
        COALESCE(agentphone, 'unknown') AS Phone,
        COALESCE(agentpostcode, 'unknown') AS Postcode
    FROM `arealytics-databricks_unity_catalog`.arealyticstrusted.reiv_lease_main
    """)
    
    # Upsert data using SCD type-2 merge to the target table using dimensions, primary key, and location as parameters
    upsert_data_scd_type_2(spark, "DimAgent", 'id', config['dim_agent_table'], config['dim_agent_location'])
