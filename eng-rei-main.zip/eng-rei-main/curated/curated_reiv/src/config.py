config = {
    'dim_agent_table': "`arealytics-databricks_unity_catalog`.arealyticscurated.DimAgent",
    'dim_agent_location': "s3://arealytics-data-lake-curated/source=rei/dataflow=reiv/DimAgent/",
    'dim_calendar_table': "`arealytics-databricks_unity_catalog`.arealyticscurated.DimCalendar",
    'dim_calendar_location': "s3://arealytics-data-lake-curated/source=rei/dataflow=reiv/DimCalendar/",
    'dim_landlord_table': "`arealytics-databricks_unity_catalog`.arealyticscurated.DimLandlord",
    'dim_landlord_location': "s3://arealytics-data-lake-curated/source=rei/dataflow=reiv/DimLandlord/",
    'map_sql_file_path': "../sql/map_property.sql",
    'main_lease_note_path': "../notebooks/Lease_main",
    'utils_path': "../../utils" 
}
