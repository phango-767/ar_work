# Import the SparkSession module
from pyspark.sql import SparkSession

def upsert_data_scd_type_2(spark: SparkSession, view_name: str, unique_id_col: str, target_table: str, location: str):
    # Get column names from the view
    columns_df = spark.sql(f"DESCRIBE {view_name}")
    columns = columns_df.select("col_name").rdd.flatMap(lambda x: x).collect()

    # Exclude the unique ID column from the comparison
    comparison_columns = [col for col in columns if col != unique_id_col]

    # Build the comparison condition for changed records
    changed_columns_conditions = ' OR '.join([
        f"COALESCE(CAST(SRC.{col} AS STRING), 'unknown') != COALESCE(CAST(TAR.{col} AS STRING), 'unknown')"
        for col in comparison_columns
    ])

    # Create or replace the target Delta table
    create_table_query = f"""
    CREATE TABLE IF NOT EXISTS {target_table}
    USING DELTA
    LOCATION '{location}'
    AS
    SELECT
        {unique_id_col},
        {', '.join([f"COALESCE(CAST({col} AS STRING), 'unknown') AS {col}" for col in columns if col != unique_id_col])},
        current_timestamp() AS insertedDate,
        current_timestamp() AS updatedDate,
        true AS currentIndicator
    FROM 
        {view_name};
    """
    print("Create or Replace Table Query:\n", create_table_query)
    spark.sql(create_table_query)

    # Insert new records
    insert_new_records_query = f"""
    INSERT INTO {target_table}
    SELECT 
        SRC.{unique_id_col},
        {', '.join([f'SRC.{col}' for col in comparison_columns])},
        current_timestamp() AS insertedDate,
        current_timestamp() AS updatedDate,
        true AS currentIndicator
    FROM 
        {view_name} AS SRC
    LEFT JOIN 
        {target_table} AS TAR
        ON TAR.{unique_id_col} = SRC.{unique_id_col}
    WHERE 
        TAR.{unique_id_col} IS NULL;
    """
    print("Insert New Records Query:\n", insert_new_records_query)
    spark.sql(insert_new_records_query)

    # Create the SQL query for changed records
    create_changed_records_query = f"""
    CREATE OR REPLACE TABLE ChangedRecords AS
    SELECT 
        SRC.{unique_id_col},
        {', '.join([f'SRC.{col}' for col in comparison_columns])},
        current_timestamp() AS mergeTime
    FROM 
        {view_name} AS SRC
    INNER JOIN 
        {target_table} AS TAR
        ON TAR.{unique_id_col} = SRC.{unique_id_col}
    WHERE 
        TAR.currentIndicator = true
        AND ({changed_columns_conditions});
    """
    print("Create Changed Records Query:\n", create_changed_records_query)
    spark.sql(create_changed_records_query)

    # Update existing records
    update_existing_records_query = f"""
    UPDATE 
        {target_table}
    SET 
        currentIndicator = false,
        updatedDate = current_timestamp()
    WHERE 
        {unique_id_col} IN (SELECT {unique_id_col} FROM ChangedRecords);
    """
    print("Update Existing Records Query:\n", update_existing_records_query)
    spark.sql(update_existing_records_query)

    # Insert new versions of changed records
    insert_changed_records_query = f"""
    INSERT INTO {target_table}
    SELECT 
        {unique_id_col},
        {', '.join([col for col in comparison_columns])},
        mergeTime AS insertedDate,
        mergeTime AS updatedDate,
        true AS currentIndicator
    FROM 
        ChangedRecords
    """
    print("Insert New Versions of Changed Records Query:\n", insert_changed_records_query)
    spark.sql(insert_changed_records_query)

    # Drop the temporary table
    drop_temp_table_query = "DROP TABLE IF EXISTS ChangedRecords"
    print("Drop Temporary Table Query:\n", drop_temp_table_query)
    spark.sql(drop_temp_table_query)