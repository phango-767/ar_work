from databricks.sdk.runtime import *

def table_exists(spark, table_name):
    try:
        spark.sql(f"DESCRIBE TABLE {table_name}")
        return True
    except:
        return False

def upsert_data(spark, dataset_type, unique_cols):
    location = f"s3://arealytics-data-lake-curated/source=rei/dataflow=reiv/{dataset_type}"
    table_name = f"`arealytics-databricks_unity_catalog`.arealyticscurated.{dataset_type}"
    view_name = f"{dataset_type}"

    on_conditions = " AND ".join([f"target.{col} = source.{col}" for col in unique_cols])

    if table_exists(spark, table_name):
        # Fetch column names from the view
        view_columns = spark.sql(f"DESCRIBE {view_name}").select("col_name").rdd.flatMap(lambda x: x).collect()

        # Exclude unique columns and system columns from the dynamic update condition
        dynamic_conditions = " OR ".join(
            [f"target.{col} != source.{col}" for col in view_columns if col not in unique_cols + ['insertedDate', 'updatedDate', 'currentIndicator']]
        )

        # Constructing the column list for INSERT
        insert_columns = ', '.join(view_columns)  # Columns from the view
        value_columns = ', '.join([f"source.{col}" for col in view_columns])  # Prefixed with 'source.'

        # Merge SQL Query
        merge_sql = f"""
        MERGE INTO {table_name} AS target
        USING (SELECT *, current_timestamp() as mergeTime FROM {view_name}) AS source
        ON {on_conditions}
        WHEN MATCHED AND ({dynamic_conditions}) THEN 
            UPDATE SET 
                target.updatedDate = source.mergeTime, 
                target.currentIndicator = false
        WHEN NOT MATCHED THEN 
            INSERT ({insert_columns}, insertedDate, updatedDate, currentIndicator)
            VALUES ({value_columns}, current_timestamp(), current_timestamp(), true)
        """
        print("Merge SQL Query: ", merge_sql)  # Debugging print statement

        spark.sql(merge_sql)

    else:
        create_table_sql = f"""
        CREATE TABLE {table_name}
        USING DELTA
        LOCATION '{location}'
        AS
        SELECT *, current_timestamp() as insertedDate, current_timestamp() as updatedDate, true as currentIndicator FROM {view_name}
        """
        spark.sql(create_table_sql)
        spark.sql(f"ALTER TABLE {table_name} SET TBLPROPERTIES ('mergeSchema' = 'true')")
