import sys
sys.path.append('../../')
import os
import logging
from pyspark.sql import SparkSession
from config import config
from etl import dim_agent, dim_calendar, dim_landlord, map_property
from utils import scd_merge
import importlib
import subprocess

# Initialize logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

def main():
    """Main function to orchestrate the ETL process."""
    try:

        # process MapProperty
        logger.info("Performing Pid Matching")
        map_property.process_map_property(spark, config['map_sql_file_path'])
        
        # run databricks notebook 
        logger.info("Load Main Lease Table")
        dbutils.notebook.run(config['main_lease_note_path'], 400)

        logger.info("ETL process completed successfully")

    except Exception as e:
        logger.error(f"ETL process failed: {e}", exc_info=True)
        sys.exit(1)

if __name__ == "__main__":
    main()
