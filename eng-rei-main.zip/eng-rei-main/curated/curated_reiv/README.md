## Reiv Curated

- `src/` Contains all source code, including ETL scripts, utility functions, and User-Defined Functions (UDFs)
- `etl/` Contains ETL scripts specific to each data entity like agents, calendars, and landlords.
- `utils/` Utility scripts for common functions, like delta merges and slowly changing dimensions.
- `notebooks/` Hosts our notebooks for exploratory data analysis and report generation.
- `sql/` Comprises SQL scripts, crucial for data manipulation and querying.
- `config/` Includes configuration files centralizing settings and parameters.
- `main/` Contains the main script that orchestrates the ETL process.
- `docs/` Houses documentation files for the project.

### Getting Started
#### Prerequisites
Before you begin, ensure you have the following installed:

- Access Databricks
- Python 3.x
- Apache Spark

#### Installation
1. In Databricks

Clone the repo to the workspace

2. On your local

Clone the Repository:

`git clone [repository-url]
cd eng-rei/curated`

Install Dependencies:
`pip install -r requirements.txt`

####  Running the Pipeline
To execute the main ETL process, run the main.py script located in the main/ directory:

### Components
**ETL Scripts:**
- `dim_agent.py`, `dim_calendar.py`, `dim_landlord.py`: Scripts for creating and merging dimension tables in the data warehouse.
- `map_property.py`: Processes property mapping data.
Utility Scripts
- `delta_merge.py`, `scd_merge.py`: Utilities for handling data merges and slowly changing dimensions.
- `spacy_entity_extraction.py`: A script for entity extraction using SpaCy.

### Docs
All busiss logic is defined by the business users and can be tracked here - https://docs.google.com/spreadsheets/d/1kysjgPtu_BbbTcJooKSRH9Pll3R1q163MF9j-IYxAf0/edit#gid=2074547253