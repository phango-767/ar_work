# Databricks notebook source
# Import necessary modules
import sys
sys.path.append('./')
from pyspark.sql import SparkSession
from pyspark.sql.functions import udf
from pyspark.sql.types import IntegerType
import importlib

import udf_total_term

udf_total_term = importlib.reload(udf_total_term)
spark.udf.register("parse_and_compute", udf_total_term.parse_and_compute_udf)


# COMMAND ----------

# MAGIC %sql
# MAGIC -- create or replace table `arealytics-databricks_unity_catalog`.arealyticscurated.reiq_leasesnapshot as
# MAGIC SELECT
# MAGIC pid.PropertyID AS  PropertyID,
# MAGIC Cast(NULL as string) AS PropertyName,
# MAGIC INITCAP(geo.formatted_address) AS Address,
# MAGIC INITCAP(geo.suburb)  AS City,
# MAGIC INITCAP(Cast(NULL as string))  AS State,
# MAGIC geo.postal_code  AS Zip,
# MAGIC -- main.tenantfirmname,
# MAGIC -- main.tenantnamefull,
# MAGIC CASE 
# MAGIC     WHEN main.tenantnamefull  is not null THEN INITCAP(trim(main.tenantnamefull))
# MAGIC     WHEN main.tenantfirmname  is not null THEN INITCAP(trim(main.tenantfirmname))
# MAGIC     ELSE "Unknown Tenant"
# MAGIC END AS AltTenantName,
# MAGIC     CASE 
# MAGIC         WHEN REGEXP_EXTRACT(main.premisestenancyno, 'Level\\s*(\\d+)', 1) IS NOT NULL 
# MAGIC         AND TRIM(REGEXP_EXTRACT(main.premisestenancyno, 'Level\\s*(\\d+)', 1)) != '' 
# MAGIC         THEN REGEXP_EXTRACT(main.premisestenancyno, 'Level\\s*(\\d+)', 1)
# MAGIC         ELSE NULL
# MAGIC     END AS Level,
# MAGIC REGEXP_SUBSTR(geo.unit, '(\\b\\d+)') AS Suite,
# MAGIC ------------------------------------------------------------------------------------------------------------------------------------------------    
# MAGIC --------------------------------this will be done in trusted from the geo coded results
# MAGIC
# MAGIC CASE
# MAGIC     WHEN LOWER(TRIM(main.rentperiod)) LIKE '%week%' AND 52 * CAST(REPLACE(REGEXP_EXTRACT(main.rentamount, '([0-9,.]+)'), ',', '') AS INTEGER) > 2000
# MAGIC     THEN ROUND(52 * CAST(REPLACE(REGEXP_EXTRACT(main.rentamount, '([0-9,.]+)'), ',', '') AS INTEGER), 1)
# MAGIC
# MAGIC     WHEN LOWER(TRIM(main.rentperiod)) LIKE '%month%' AND 12 * CAST(REPLACE(REGEXP_EXTRACT(main.rentamount, '([0-9,.]+)'), ',', '') AS INTEGER) > 2000
# MAGIC     THEN ROUND(12 * CAST(REPLACE(REGEXP_EXTRACT(main.rentamount, '([0-9,.]+)'), ',', '') AS INTEGER), 1)
# MAGIC
# MAGIC     WHEN LOWER(TRIM(main.rentperiod)) LIKE '%year%' AND CAST(REPLACE(REGEXP_EXTRACT(main.rentamount, '([0-9,.]+)'), ',', '') AS INTEGER) > 2000
# MAGIC     THEN ROUND(CAST(REPLACE(REGEXP_EXTRACT(main.rentamount, '([0-9,.]+)'), ',', '') AS INTEGER), 1)
# MAGIC
# MAGIC         ELSE
# MAGIC CASE
# MAGIC     WHEN LOWER(TRIM(main.rentamount)) LIKE '%week%' AND 52 * CAST(REPLACE(REGEXP_EXTRACT(main.rentamount, '([0-9,.]+)'), ',', '') AS INTEGER) > 2000
# MAGIC     THEN ROUND(52 * CAST(REPLACE(REGEXP_EXTRACT(main.rentamount, '([0-9,.]+)'), ',', '') AS INTEGER), 1)
# MAGIC
# MAGIC     WHEN LOWER(TRIM(main.rentamount)) LIKE '%month%' AND 12 * CAST(REPLACE(REGEXP_EXTRACT(main.rentamount, '([0-9,.]+)'), ',', '') AS INTEGER) > 2000
# MAGIC     THEN ROUND(12 * CAST(REPLACE(REGEXP_EXTRACT(main.rentamount, '([0-9,.]+)'), ',', '') AS INTEGER), 1)
# MAGIC
# MAGIC     WHEN (LOWER(TRIM(main.rentamount)) LIKE '%year%' OR LOWER(TRIM(main.rentamount)) LIKE '%annum%') AND CAST(REPLACE(REGEXP_EXTRACT(main.rentamount, '([0-9,.]+)'), ',', '') AS INTEGER) > 2000
# MAGIC     THEN ROUND(CAST(REPLACE(REGEXP_EXTRACT(main.rentamount, '([0-9,.]+)'), ',', '') AS INTEGER), 1)
# MAGIC
# MAGIC     ELSE NULL
# MAGIC     END
# MAGIC END  AS FaceRentAnnual,
# MAGIC CASE 
# MAGIC     WHEN sqm.extracted_sqm > 10
# MAGIC     THEN sqm.extracted_sqm
# MAGIC     ELSE NULL
# MAGIC END AS Leasedsqm, -- this need move to trusted
# MAGIC
# MAGIC CASE
# MAGIC     WHEN lower(trim(main.leaseoutgoingsperc)) rlike ".*included.*" 
# MAGIC         OR lower(trim(main.leaseoutgoingsperc)) rlike ".*nil.*" 
# MAGIC         OR lower(trim(main.leaseoutgoingsperc)) rlike ".*gross.*" 
# MAGIC         OR lower(trim(main.leaseoutgoingsperc)) like "0%" 
# MAGIC         OR lower(trim(main.leaseoutgoingsperc)) rlike ".*lessor.*" THEN 4
# MAGIC     WHEN trim(main.leaseoutgoingsperc) rlike ".*%.*" 
# MAGIC         OR trim(main.leaseoutgoingsperc) rlike ".*\\$.*"
# MAGIC         OR lower(trim(main.leaseoutgoingsperc)) rlike ".*tenant.*" 
# MAGIC         OR lower(trim(main.leaseoutgoingsperc)) rlike ".*net.*" 
# MAGIC         OR lower(trim(main.leaseoutgoingsperc)) rlike ".*lessee.*"   
# MAGIC         -- WHEN lower(trim(main.leaseoutgoingsperc)) rlike ".*(|tenant|lessor).*" THEN       
# MAGIC         THEN 10
# MAGIC     ELSE NULL
# MAGIC END AS LeaseRateType,
# MAGIC CASE 
# MAGIC     WHEN parse_and_compute(main.tentermoptions).result <= 0 THEN NULL 
# MAGIC     ELSE parse_and_compute(main.tentermoptions).result
# MAGIC END AS RenewalOptionsNoOfMonths,
# MAGIC Cast(NULL as string) AS OutgoingsPerSqm,
# MAGIC CASE 
# MAGIC     WHEN CAST(REGEXP_EXTRACT(main.rentreviewamount2, r'(\d+(\.\d+)?)') AS INTEGER) BETWEEN 2 AND 9 THEN CAST(REGEXP_EXTRACT(main.rentreviewamount2, r'(\d+(\.\d+)?)') AS INTEGER)
# MAGIC         ELSE NULL
# MAGIC END AS EscalationRate,
# MAGIC     date_format(cast(main.created  as date), 'dd/MM/yyyy') AS RecordedDate,
# MAGIC     -- reformat_iso_date_udf(Cast(main.created as DATE)) AS RecordedDate1,
# MAGIC     -- main.created,
# MAGIC     1 AS LeaseSublease,
# MAGIC     1 AS LeaseTransType,
# MAGIC
# MAGIC  Cast(NULL as string) AS SuiteComments,
# MAGIC
# MAGIC -- main.tenantabn, main.tenantacn, main.tenantabnacn, main.lessorabn, main.lessoracn, main.lessorabnacn,
# MAGIC   IF(
# MAGIC   main.lessornamefull IS NULL AND
# MAGIC   main.lessorabn IS NULL AND
# MAGIC   main.lessoracn IS NULL AND
# MAGIC   main.lessorabnacn IS NULL AND
# MAGIC   main.tenantnamefull IS NULL AND
# MAGIC   main.tenantfirmname IS NULL AND
# MAGIC   main.tenantabn IS NULL AND
# MAGIC   main.tenantacn IS NULL AND
# MAGIC   main.tenantabnacn IS NULL AND
# MAGIC   main.tentermoptions IS NULL AND
# MAGIC   main.renewalfinaldate IS NULL AND
# MAGIC   main.premisespermitteduse IS NULL AND
# MAGIC   main.leaseoutgoingsperc IS NULL AND
# MAGIC   main.deposit IS NULL,
# MAGIC   NULL,
# MAGIC   CONCAT(
# MAGIC     IF(main.lessornamefull IS NOT NULL, CONCAT('Lessor Name: [', INITCAP(main.lessornamefull), ']'), ''), 
# MAGIC     IF(main.lessornamefull IS NOT NULL, '\n', ''),
# MAGIC     IF(main.lessorabn IS NOT NULL, CONCAT('Lessor ABN: [', INITCAP(main.lessorabn), ']'), ''), 
# MAGIC     IF(main.lessorabn IS NOT NULL, '\n', ''),
# MAGIC     IF(main.lessoracn IS NOT NULL, CONCAT('Lessor ACN: [', INITCAP(main.lessoracn), ']'), ''), 
# MAGIC     IF(main.lessoracn IS NOT NULL, '\n', ''),
# MAGIC     IF(main.lessorabnacn IS NOT NULL, CONCAT('Lessor ABN/ACN: [', INITCAP(main.lessorabnacn), ']'), ''), 
# MAGIC     IF(main.lessorabnacn IS NOT NULL, '\n', ''),
# MAGIC     IF(main.tenantnamefull IS NOT NULL OR main.tenantfirmname IS NOT NULL, CONCAT('Lessee Name: [', COALESCE(INITCAP(main.tenantnamefull),INITCAP(main.tenantfirmname)), ']'), ''), 
# MAGIC     IF(main.tenantnamefull IS NOT NULL OR main.tenantfirmname IS NOT NULL, '\n', ''),
# MAGIC     IF(main.tenantabn IS NOT NULL, CONCAT('Lessee ABN: [', INITCAP(main.tenantabn), ']'), ''), 
# MAGIC     IF(main.tenantabn IS NOT NULL, '\n', ''),
# MAGIC     IF(main.tenantacn IS NOT NULL, CONCAT('Lessee ACN: [', INITCAP(main.tenantacn), ']'), ''), 
# MAGIC     IF(main.tenantacn IS NOT NULL, '\n', ''),
# MAGIC     IF(main.tenantabnacn IS NOT NULL, CONCAT('Lessee ABN/ACN: [', INITCAP(main.tenantabnacn), ']'), ''), 
# MAGIC     IF(main.tenantabnacn IS NOT NULL, '\n', ''),
# MAGIC     IF(main.tentermoptions IS NOT NULL, CONCAT('RenewalOptions: [', INITCAP(main.tentermoptions), ']'), ''), 
# MAGIC     IF(main.tentermoptions IS NOT NULL, '\n', ''),
# MAGIC     IF(main.renewalfinaldate IS NOT NULL, CONCAT('OptionDate: [', INITCAP(main.renewalfinaldate), ']'), ''), 
# MAGIC     IF(main.renewalfinaldate IS NOT NULL, '\n', ''),
# MAGIC     IF(main.premisespermitteduse IS NOT NULL, CONCAT('SpaceType: [', INITCAP(main.premisespermitteduse), ']'), ''), 
# MAGIC     IF(main.premisespermitteduse IS NOT NULL, '\n', ''),
# MAGIC     IF(main.leaseoutgoingsperc IS NOT NULL, CONCAT('OutgoingsDescription: [', INITCAP(main.leaseoutgoingsperc), ']'), ''), 
# MAGIC     IF(main.leaseoutgoingsperc IS NOT NULL, '\n', ''),
# MAGIC     IF(main.deposit IS NOT NULL, CONCAT('Deposit: [', INITCAP(main.deposit), ']'), ''), 
# MAGIC     IF(main.deposit IS NOT NULL, '\n', '')
# MAGIC   )
# MAGIC ) AS TransactionComments,
# MAGIC -- main.AgreementDate,
# MAGIC
# MAGIC main.agreementDate  as ExecutionDate,
# MAGIC --   TO_DATE(reformat_date_udf(main.AgreementDate ), 'dd/MM/yyyy') as execdate,
# MAGIC ------------------------------------------------------------------------------------------------------------------------------------------------
# MAGIC --------------------------------this needs to be done via python in cleaning and strandard phase by me
# MAGIC
# MAGIC
# MAGIC CASE 
# MAGIC     WHEN DATE_FORMAT(CAST(main.agencyperiodenddate  AS DATE), 'yyyy-MM-dd') < CURRENT_DATE THEN 1 -- HISTORIC
# MAGIC     ELSE 2 -- ACTIVE
# MAGIC END AS LeaseStatus,
# MAGIC CASE 
# MAGIC   WHEN lower(trim(main.permittedusetype)) LIKE '%retail%' THEN 7
# MAGIC   WHEN lower(trim(main.permittedusetype)) LIKE '%industrial%' THEN 8
# MAGIC   WHEN lower(trim(main.permittedusetype)) = 'office' THEN 9
# MAGIC   WHEN main.permittedusetype IS NULL AND lower(pd.PropertyUse) LIKE '%retail%' THEN 7
# MAGIC   WHEN main.permittedusetype IS NULL AND lower(pd.PropertyUse) LIKE '%industrial%' THEN 8
# MAGIC   WHEN main.permittedusetype IS NULL AND pd.PropertyUse = 'office' THEN 9
# MAGIC   WHEN main.permittedusetype IS NULL AND pd.PropertyUse = 'Special Use' THEN 11
# MAGIC   WHEN main.permittedusetype IS NULL AND pd.PropertyUse = 'Land' THEN 4
# MAGIC   ELSE NULL
# MAGIC END AS SpaceGeneralUse,
# MAGIC     Cast(NULL as string) AS ConfirmationNotes,
# MAGIC     Cast(NULL as string) AS SignDate,
# MAGIC     Cast(Null as string) AS BankGuaranteeAmount,
# MAGIC     CASE 
# MAGIC             WHEN main.rentamount is not null and lower(trim(main.rentamount )) like "%gst%"
# MAGIC             THEN 1
# MAGIC             ELSE 0
# MAGIC     END  AS GSTIncluded,
# MAGIC     Cast(NULL as string) AS IsCondo,
# MAGIC     Cast(NULL as string) AS Fitout,
# MAGIC     4 AS TransactionOriginationTypeID,
# MAGIC     CASE 
# MAGIC         WHEN main.rentamount IS NOT NULL THEN 1
# MAGIC         ELSE 0
# MAGIC     END AS IsStartingRateConfirmed,
# MAGIC     5 as ShareLevelID,
# MAGIC     CASE 
# MAGIC         WHEN  main.agencyperiodenddate is not null then 1
# MAGIC         ELSE 0
# MAGIC     END AS IsExpDateConfirmed,
# MAGIC Case
# MAGIC     when lower(trim(main.rentreviewtypecb)) like "%fixed%" or lower(trim(main.rentreviewdate2)) like "%fixed%" 
# MAGIC     then "Fixed"
# MAGIC       when lower(trim(main.rentreviewtypecb)) like "%index%" or lower(trim(main.rentreviewdate2)) like "%index%" 
# MAGIC     then "CPI"
# MAGIC       when lower(trim(main.rentreviewtypecb)) like "%market%" or lower(trim(main.rentreviewdate2)) like "%market%" 
# MAGIC     then "Market"
# MAGIC     when lower(trim(main.rentreviewdate2)) like "%cpi%" and lower(trim(main.rentreviewdate2)) like "%%%" 
# MAGIC     then "Fixed/CPI"
# MAGIC     else null
# MAGIC     end as EscalationType,
# MAGIC     -- Cast(NULL as string) AS rentincreasedescription,
# MAGIC     CASE 
# MAGIC             WHEN main.agencyperiodenddate is not null and main.agencyperiodstartdate is not null THEN 1
# MAGIC             ELSE 0
# MAGIC     END AS IsTermsConfirmed,
# MAGIC     Cast(NULL as string) AS ConfirmedTenantID,
# MAGIC     Cast(NULL as INTEGER) AS DealingNumber,
# MAGIC     CASE 
# MAGIC         WHEN main.agencyperiodstartdate is not null then 1
# MAGIC         ELSE 0
# MAGIC     END AS IsOccupDateConfirmed,
# MAGIC     Cast(NULL as string) AS RentFreePeriod,
# MAGIC
# MAGIC       ROUND(MONTHS_BETWEEN(
# MAGIC              TO_DATE(main.agencyperiodenddate, 'dd/MM/yyyy'), 
# MAGIC              TO_DATE(main.agencyperiodstartdate , 'dd/MM/yyyy')),0)
# MAGIC             as TermMonths,
# MAGIC ------------------------------------------------------------------------------------------------------------------------------------------------
# MAGIC --------------------------------data cleaning should not be done in the curated layer this will move to trusted (by me)
# MAGIC -- main.agencyperiodstartdate ,main.agencyperiodenddate,
# MAGIC date_format(cast(main.agencyperiodstartdate as date), 'dd/MM/yyyy')  as CommencingDate,
# MAGIC date_format(cast(main.agencyperiodenddate as date), 'dd/MM/yyyy') as ExpiryDate,
# MAGIC
# MAGIC CASE
# MAGIC     WHEN 
# MAGIC           CAST(CEIL(MONTHS_BETWEEN(
# MAGIC              TO_DATE(main.agencyperiodenddate, 'dd/MM/yyyy'), 
# MAGIC              TO_DATE(main.renewalfinaldate , 'dd/MM/yyyy')))
# MAGIC             AS INTEGER) > 0
# MAGIC     THEN
# MAGIC           CAST(CEIL(MONTHS_BETWEEN(
# MAGIC              TO_DATE(main.agencyperiodenddate, 'dd/MM/yyyy'), 
# MAGIC              TO_DATE(main.renewalfinaldate , 'dd/MM/yyyy')))
# MAGIC             AS STRING)
# MAGIC     ELSE NULL
# MAGIC END as NoticePeriodMin,
# MAGIC Cast(NULL as string) AS NoticePeriodMax,
# MAGIC 1 as ListingTypeId,
# MAGIC CAST(NULL as string) as folio,
# MAGIC CAST(NULL as string) as StageID,
# MAGIC CAST(NULL as string) as Status,
# MAGIC CAST(NULL as string) as ExceptionReason,
# MAGIC CAST(NULL as string) as CreatedDate,
# MAGIC CAST(NULL as string) as CreatedBy,
# MAGIC CAST(NULL as string) as ModifiedDate,
# MAGIC CAST(NULL as string) as ModifiedBy,
# MAGIC CAST(NULL as string) as LeaseID,
# MAGIC CAST(NULL as string) as IsActive,
# MAGIC CAST(NULL as string) as BatchID,
# MAGIC CAST(NULL as string) as HidedBy,
# MAGIC CAST(NULL as string) as IsHidden,
# MAGIC CAST(NULL as string) as HidedDate,
# MAGIC CAST(NULL as string) as HideReasonID,
# MAGIC CAST(NULL as string) as HideReasonComments,
# MAGIC CAST(NULL as string) as SubHideReasonID,
# MAGIC CAST(NULL as string) as MismatchedTaggedBy,
# MAGIC CAST(NULL as string) as IsMismatched,
# MAGIC Geo.latitude,
# MAGIC Geo.longitude,
# MAGIC CAST(NULL as string) as `Location`,
# MAGIC CAST(main.id as string) as `UID`,
# MAGIC CAST(NULL as string) as `Url`,
# MAGIC CAST(NULL as string) as AgentName1,
# MAGIC CAST(NULL as string) as AgentEmail1,
# MAGIC CAST(NULL as string) as AgentName2,
# MAGIC CAST(NULL as string) as AgentEmail2,
# MAGIC 33 AS ProviderID,
# MAGIC ROW_NUMBER() OVER (
# MAGIC     PARTITION BY date_format(cast(main.agencyperiodstartdate as date), 'dd/MM/yyyy') , date_format(cast(main.agencyperiodenddate as date), 'dd/MM/yyyy'), coalesce(main.tenantfirmname,main.tenantnamefull), pid.PropertyID
# MAGIC       ORDER BY main.updated DESC
# MAGIC ) AS rn
# MAGIC from `arealytics-databricks_unity_catalog`.arealyticstrusted.reiq_leasesnapshot as main
# MAGIC
# MAGIC LEFT JOIN `arealytics-databricks_unity_catalog`.arealyticstrusted.reiq_lease_sqm as sqm
# MAGIC ON sqm.id = main.id
# MAGIC LEFT JOIN `arealytics-databricks_unity_catalog`.arealyticstrusted.reiq_geocoded_data  as geo
# MAGIC ON geo.id = main.id 
# MAGIC -- LEFT JOIN `arealytics-databricks_unity_catalog`.arealyticstrusted.permittedusetype  as use
# MAGIC -- ON use.id = main.id 
# MAGIC
# MAGIC LEFT JOIN `arealytics-databricks_unity_catalog`.arealyticstrusted.reiq_pid_link AS pid
# MAGIC on pid.id = main.id
# MAGIC
# MAGIC left join  `arealytics-databricks_unity_catalog`.arealyticstrusted.Property_detail Pd
# MAGIC on pd.PropertyID = pid.PropertyID
# MAGIC
# MAGIC -- WHERE
# MAGIC -- maagencyname
# MAGIC where geo.latitude IS NOT NULL 
# MAGIC and geo.postal_code in (SELECT DISTINCT Zip FROM `arealytics-databricks_unity_catalog`.arealyticstrusted.reiq_in_market_codes)
# MAGIC and lower(main.premisespermitteduse) != 'car parking'
# MAGIC QUALIFY rn = 1;
# MAGIC
# MAGIC -- select * from  `arealytics-databricks_unity_catalog`.arealyticscurated.reiq_leasesnapshot ;
# MAGIC
# MAGIC -- main.premisespostcode -- 26 281
# MAGIC -- geo.postal_code -- 27 227
# MAGIC --   geo.latitude IS NOT NULL --
# MAGIC --  pid.PropertyID IS NOT NULL -- 18 488

# COMMAND ----------

# MAGIC %md
# MAGIC ### Export data

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE OR REPLACE TEMP VIEW Reiq_export AS
# MAGIC SELECT
# MAGIC     PropertyID AS `PropertyID`,
# MAGIC     PropertyName AS `Property Name`,
# MAGIC     Address,
# MAGIC     City,
# MAGIC     State,
# MAGIC     Zip,
# MAGIC     AltTenantName AS `Alt Tenant Name`,
# MAGIC     Level,
# MAGIC     Suite,
# MAGIC     LeasedSqm AS `Leased Sqm`,
# MAGIC     CommencingDate AS `Commencing Date`,
# MAGIC     ExpiryDate AS `Expiry Date`,
# MAGIC     FaceRentAnnual AS `Face Rent - Annual`,
# MAGIC     LeaseRateType AS `Lease Rate Type`,
# MAGIC     OutgoingsPerSqm AS `Outgoings (per sqm)`,
# MAGIC     EscalationRate AS `Escalation Rate %`,
# MAGIC     TermMonths AS `Term (months)`,
# MAGIC     RenewalOptionsNoOfMonths AS `Renewal Options (No. of Months)`,
# MAGIC     RecordedDate AS `Recorded Date`,
# MAGIC     LeaseSublease AS `Lease/Sublease`,
# MAGIC     LeaseTransType AS `Lease Trans Type`,
# MAGIC     TransactionComments AS `Transaction Comments`,
# MAGIC     SuiteComments AS `Suite Comments`,
# MAGIC     ExecutionDate AS `Execution Date`,
# MAGIC     SpaceGeneralUse AS `Space General Use`,
# MAGIC     LeaseStatus AS `Lease Status`,
# MAGIC     ConfirmationNotes,
# MAGIC     SignDate AS `SignDate`,
# MAGIC     BankGuaranteeAmount AS `BankGuaranteeAmount`,
# MAGIC     GSTIncluded AS `GSTIncluded`,
# MAGIC     IsCondo,
# MAGIC     Fitout,
# MAGIC     TransactionOriginationTypeID AS `TransactionOriginationTypeID`,
# MAGIC     IsStartingRateConfirmed AS `IsStartingRateConfirmed`,
# MAGIC     ShareLevelID AS `ShareLevelID`,
# MAGIC     IsExpDateConfirmed AS `IsExpDateConfirmed`,
# MAGIC     EscalationType,
# MAGIC     IsTermsConfirmed AS `IsTermsConfirmed`,
# MAGIC     ConfirmedTenantID AS `ConfirmedTenantID`,
# MAGIC     DealingNumber AS `DealingNumber`,
# MAGIC     IsOccupDateConfirmed AS `IsOccupDateConfirmed`,
# MAGIC     RentFreePeriod AS `RentFreePeriod`,
# MAGIC     NoticePeriodMin AS `NoticePeriodMin`,
# MAGIC     NoticePeriodMax AS `NoticePeriodMax`,
# MAGIC     ListingTypeID AS `ListingTypeID`,
# MAGIC     Folio,
# MAGIC     StageID,
# MAGIC     Status,
# MAGIC     ExceptionReason,
# MAGIC     CreatedDate,
# MAGIC     CreatedBy,
# MAGIC     ModifiedDate,
# MAGIC     ModifiedBy,
# MAGIC     LeaseID,
# MAGIC     IsActive,
# MAGIC     BatchID,
# MAGIC     ProviderID,
# MAGIC     HidedBy AS `HidedBy`,
# MAGIC     IsHidden AS `IsHidden`,
# MAGIC     HidedDate AS `HidedDate`,
# MAGIC     HideReasonID AS `HideReasonID`,
# MAGIC     HideReasonComments AS `HideReasonComments`,
# MAGIC     SubHideReasonID AS `SubHideReasonID`,
# MAGIC     MismatchedTaggedBy AS `MismatchedTaggedBy`,
# MAGIC     IsMismatched AS `IsMismatched`,
# MAGIC     Longitude,
# MAGIC     Latitude,
# MAGIC     cast(NULL as string) as Location,
# MAGIC     UID AS `UID`,
# MAGIC     Url AS `Url`,
# MAGIC     AgentName1 AS `AgentName1`,
# MAGIC     AgentEmail1 AS `AgentEmail1`,
# MAGIC     AgentName2 AS `AgentName2`,
# MAGIC     AgentEmail2 AS `AgentEmail2`,
# MAGIC     cast(NULL as string) as `Face Rent - per sqm`,
# MAGIC     cast(NULL as string) as `Space Type`,
# MAGIC     cast(NULL as string) as `LeaseFolio`,
# MAGIC     cast(NULL as string) as `Asking lease Rate/sqm/Year`,
# MAGIC     cast(NULL as string) as `Asking lease Rate/sqm/Month`,
# MAGIC     cast(NULL as string) as `Head Title`
# MAGIC FROM
# MAGIC     `arealytics-databricks_unity_catalog`.arealyticscurated.reiq_leasesnapshot 
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT 
# MAGIC   TRIM(TRAILING ', ' FROM
# MAGIC   CONCAT_WS(', ',
# MAGIC       CONCAT_WS('/', 
# MAGIC       NULLIF(TRIM(COALESCE(TRIM(b.premisestenancyno), '')), ''),
# MAGIC       COALESCE(
# MAGIC           -- Use premisesstreet2 if available; otherwise, use premisesstreet1
# MAGIC           NULLIF(TRIM(COALESCE(b.premisesstreet2, '')), ''),
# MAGIC           NULLIF(TRIM(COALESCE(b.premisesstreet1, '')), '')
# MAGIC       )
# MAGIC       ),
# MAGIC       NULLIF(TRIM(COALESCE(b.premisessuburb, '')), ''),
# MAGIC       CONCAT_WS(' ',
# MAGIC       COALESCE(b.premisesstate, 'QLD'),
# MAGIC       TRIM(COALESCE(CAST(FLOOR(b.premisespostcode) AS STRING), ''))
# MAGIC       )
# MAGIC   )
# MAGIC   ) AS raw_address,
# MAGIC a.* 
# MAGIC FROM `arealytics-databricks_unity_catalog`.arealyticscurated.reiq_leasesnapshot as a
# MAGIC left join `arealytics-databricks_unity_catalog`.arealyticstrusted.reiq_leasesnapshot as b
# MAGIC on a.UID = b.id

# COMMAND ----------

from pyspark.sql import SparkSession

# Database and JDBC parameters
driver = "org.mariadb.jdbc.Driver"
database_host = "empirical01-uat-ore.cbilzzla5ot8.us-west-2.rds.amazonaws.com"
database_port = "3306"
database_name = "Empirical_DataStage"
table = "LeaseComp_Stage_REIV_For_Grouping"
user = 'dbuser-databricks' 
password = 'DBUserDatabricks#633'

# JDBC URL construction
url = f"jdbc:mysql://{database_host}:{database_port}/{database_name}?useSSL=false"

# Load data from a Spark SQL query
df = spark.sql("""
select *
from
reiq_export
""")

# Write DataFrame to MySQL database, overwriting existing table
df.write \
  .format("jdbc") \
  .mode("overwrite") \
  .option("url", url) \
  .option("dbtable", table) \
  .option("user", user) \
  .option("password", password) \
  .option("driver", driver) \
  .save()

print("Data exported and table overwritten successfully in MySQL database.")

