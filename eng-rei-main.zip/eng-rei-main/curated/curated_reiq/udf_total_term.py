# Import necessary modules 
from pyspark.sql.functions import udf
from pyspark.sql.types import StringType, IntegerType, StructType, StructField
import re

# Function to parse and compute the Lease term description
def parse_and_compute(s: str):
    if not isinstance(s, str):
        return None  # Safely handle non-string inputs including None

    # Create an empty list for expression
    e = []
    for x in s.split():
        # Check if character contains a digit
        if any(c.isdigit() for c in x):
            # Extract digits from a character and append to e list
            e.append(int(re.sub(r'\D', '', x)))
        
        # If the word contains year, convert to month and update list e
        elif 'year' in x.lower() and e: 
            e[-1] *= 12
        
        # If the word contains years, convert to month and update list e
        elif 'years' in x.lower() and e: 
            e[-1] *= 12
        
        # When word contains "x", "of", "by", "for", append * to e
        elif x in ['x', 'of', 'by', 'for'] and e:
            e.append('*')
        
        # When word contains "+" or "and" or "&", append + to e
        elif x in ['+', 'and', '&'] and e: # figure out how/ where to incorporate 'with'
            e.append('+')

    # Compute result manually instead of using eval
    expression = ' '.join(map(str, e))
    
    # Evaluate a term and get the sum
    try:
        result = sum(eval(term) for term in expression.split('+') if term.strip('*'))
    except SyntaxError:
        result = 0  # Default to 0 in case of syntax error
    
    # Create the full expression variable
    full_expression = f"{expression} = {result}"
    
    # Return a tuple consisting of full expression and result
    return (full_expression, result)

# Define the schema for the UDF
schema = StructType([
    StructField("full_expression", StringType(), False),
    StructField("result", IntegerType(), False),
])

# Register UDF and make it public in the code
parse_and_compute_udf = udf(parse_and_compute, schema)
# spark.udf.register("parse_and_compute", parse_and_compute_udf)
