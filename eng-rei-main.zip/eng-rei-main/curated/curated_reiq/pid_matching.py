# Databricks notebook source
# MAGIC %sql
# MAGIC CREATE OR REPLACE TABLE `arealytics-databricks_unity_catalog`.arealyticstrusted.reiq_Lease_Temp AS
# MAGIC SELECT
# MAGIC id,
# MAGIC     formatted_address,
# MAGIC     REGEXP_SUBSTR(street_number, '\\d+') AS Street_Number_cleaned,
# MAGIC     street_number,
# MAGIC     CAST(
# MAGIC         SPLIT(street_number, '-')[0] AS INT
# MAGIC     ) AS StreetNumberMin,
# MAGIC     CAST(
# MAGIC         CASE 
# MAGIC             WHEN street_number LIKE '%-%' THEN
# MAGIC                 SPLIT(street_number, '-')[1]
# MAGIC             ELSE
# MAGIC                 NULL
# MAGIC         END AS INT
# MAGIC     ) AS StreetNumberMax,
# MAGIC     suburb,
# MAGIC     Unit,
# MAGIC     postal_code,
# MAGIC     latitude,
# MAGIC     longitude,
# MAGIC     CASE 
# MAGIC         WHEN unit = '00 00' OR unit IN ('00', '', '0') THEN NULL 
# MAGIC         ELSE REGEXP_EXTRACT(unit, '(\\d+)', 1)
# MAGIC     END as Cleaned_Unit,
# MAGIC     REGEXP_REPLACE(street_name, CONCAT('\\s+(', suffix_list.suffix_regex, ')$'), '') as Cleaned_Street_Name,
# MAGIC     CAST(NULL as INT) as PropertyID
# MAGIC FROM 
# MAGIC     `arealytics-databricks_unity_catalog`.arealyticstrusted.reiq_geocoded_data_v2
# MAGIC CROSS JOIN 
# MAGIC     (SELECT concat_ws('|', collect_list(suffix),'Cres','Parade') as suffix_regex FROM `arealytics-databricks_unity_catalog`.arealyticstrusted.propertysuffixmap) as suffix_list;
# MAGIC
# MAGIC -----------------------------------------
# MAGIC CREATE OR REPLACE TABLE `arealytics-databricks_unity_catalog`.arealyticstrusted.reiq_temp AS
# MAGIC WITH RankedMatches AS (
# MAGIC     SELECT 
# MAGIC     lt.id,
# MAGIC     -- lt.created,
# MAGIC     -- lt.code,
# MAGIC     A.ParentID AS PropertyID,
# MAGIC     LT.formatted_address,
# MAGIC     A.AddressText AS AL_address,
# MAGIC     LT.postal_code AS `reiq_ZipCode`, 
# MAGIC     A.ZipCode AS `AL_ZipCode`,
# MAGIC     LT.suburb AS `reiq_City`,
# MAGIC     CTY.CityName AS `AL_City`,
# MAGIC     LT.Cleaned_Street_Name AS `reiq_StreetName`,
# MAGIC     A.AddressStreetName AS `AL_StreetName`,
# MAGIC     P.CondoTypeID,
# MAGIC     LT.StreetNumberMin AS reiq_StreetNumberMin,
# MAGIC     LT.StreetNumberMax AS reiq_StreetNumberMax,
# MAGIC     A.StreetNumberMin AS AL_StreetNumberMin,
# MAGIC     A.StreetNumberMax AS AL_StreetNumberMax,
# MAGIC     ROW_NUMBER() OVER (
# MAGIC         PARTITION BY LT.id
# MAGIC         ORDER BY (COALESCE(A.StreetNumberMax, A.StreetNumberMin) - A.StreetNumberMin) ASC
# MAGIC     ) AS rn
# MAGIC     FROM `arealytics-databricks_unity_catalog`.arealyticstrusted.reiq_Lease_Temp LT 
# MAGIC     LEFT JOIN `arealytics-databricks_unity_catalog`.arealyticstrusted.Address A ON A.ParentTableID=1 
# MAGIC         AND A.IsActive=1 AND LT.postal_code = A.ZipCode 
# MAGIC         AND lower(LT.Cleaned_Street_Name)=lower(A.AddressStreetName)
# MAGIC         AND 
# MAGIC         (
# MAGIC 		LT.Street_Number_cleaned =  A.StreetNumberMin
# MAGIC 		OR 
# MAGIC         LT.Street_Number_cleaned =  A.StreetNumberMax
# MAGIC         OR
# MAGIC         LT.StreetNumberMin BETWEEN A.StreetNumberMin AND COALESCE(A.StreetNumberMax, A.StreetNumberMin))
# MAGIC         -- AND LT.Cleaned_Street_Name=A.AddressStreetName AND (LT.street_number = A.StreetNumberMin OR LT.street_number BETWEEN A.StreetNumberMin AND A.StreetNumberMax)
# MAGIC     LEFT JOIN `arealytics-databricks_unity_catalog`.arealyticstrusted.Property_detail P ON P.PropertyID=A.ParentID
# MAGIC     LEFT JOIN `arealytics-databricks_unity_catalog`.arealyticstrusted.PropertySummary PS on PS.PropertyID=P.PropertyID 
# MAGIC     LEFT JOIN `arealytics-databricks_unity_catalog`.arealyticstrusted.City CTY ON CTY.CityID=A.CityID AND LT.suburb= CTY.CityName
# MAGIC     LEFT JOIN `arealytics-databricks_unity_catalog`.arealyticstrusted.propertysuffixmap as suff on p.StreetSuffix1 = suff.SuffixID
# MAGIC     WHERE LT.Cleaned_Unit is null and (P.CondoTypeID is null or P.CondoTypeID <> 2) and PS.ResearchTypeID not in (4,0)
# MAGIC )
# MAGIC SELECT * FROM RankedMatches
# MAGIC -- where id= '102409'
# MAGIC WHERE rn = 1;
# MAGIC
# MAGIC UPDATE `arealytics-databricks_unity_catalog`.arealyticstrusted.reiq_Lease_Temp lt
# MAGIC SET lt.PropertyID = (
# MAGIC     SELECT MAX(t.PropertyID)
# MAGIC     FROM `arealytics-databricks_unity_catalog`.arealyticstrusted.reiq_temp t 
# MAGIC     WHERE lt.id = t.id
# MAGIC     -- AND lt.code = t.code
# MAGIC )
# MAGIC WHERE lt.PropertyID IS NULL;
# MAGIC
# MAGIC ------------------------ PASS 2
# MAGIC
# MAGIC CREATE OR REPLACE TABLE `arealytics-databricks_unity_catalog`.arealyticstrusted.reiq_temp AS
# MAGIC WITH RankedMatches AS (
# MAGIC     SELECT 
# MAGIC     lt.id,
# MAGIC     -- lt.created,
# MAGIC     -- lt.code,
# MAGIC     A.ParentID AS PropertyID,
# MAGIC     LT.formatted_address,
# MAGIC     A.AddressText AS AL_address,
# MAGIC     LT.postal_code AS `reiq_ZipCode`, 
# MAGIC     A.ZipCode AS `AL_ZipCode`,
# MAGIC     LT.suburb AS `reiq_City`,
# MAGIC     CTY.CityName AS `AL_City`,
# MAGIC     LT.Cleaned_Street_Name AS `reiq_StreetName`,
# MAGIC     A.AddressStreetName AS `AL_StreetName`,
# MAGIC     P.CondoTypeID,
# MAGIC     LT.StreetNumberMin AS reiq_StreetNumberMin,
# MAGIC     LT.StreetNumberMax AS reiq_StreetNumberMax,
# MAGIC     A.StreetNumberMin AS AL_StreetNumberMin,
# MAGIC     A.StreetNumberMax AS AL_StreetNumberMax,
# MAGIC     ROW_NUMBER() OVER (
# MAGIC         PARTITION BY LT.id
# MAGIC         ORDER BY (COALESCE(A.StreetNumberMax, A.StreetNumberMin) - A.StreetNumberMin) ASC
# MAGIC     ) AS rn
# MAGIC     FROM `arealytics-databricks_unity_catalog`.arealyticstrusted.reiq_Lease_Temp LT 
# MAGIC LEFT JOIN 
# MAGIC     `arealytics-databricks_unity_catalog`.arealyticstrusted.Address A 
# MAGIC ON 
# MAGIC     A.ParentTableID=1 AND A.IsActive=1 
# MAGIC     AND LT.postal_code = A.ZipCode AND lower(LT.Cleaned_Street_Name)=lower(A.AddressStreetName)
# MAGIC     -- AND LT.StreetNumberMin BETWEEN A.StreetNumberMin AND COALESCE(A.StreetNumberMax, A.StreetNumberMin)
# MAGIC     AND 
# MAGIC         (
# MAGIC 		LT.Street_Number_cleaned =  A.StreetNumberMin
# MAGIC 		OR 
# MAGIC         LT.Street_Number_cleaned =  A.StreetNumberMax
# MAGIC         OR
# MAGIC         LT.StreetNumberMin BETWEEN A.StreetNumberMin AND COALESCE(A.StreetNumberMax, A.StreetNumberMin))
# MAGIC LEFT JOIN 
# MAGIC     `arealytics-databricks_unity_catalog`.arealyticstrusted.Property_detail P 
# MAGIC ON 
# MAGIC     P.PropertyID = A.ParentID AND (P.CondoUnit IS NULL OR P.CondoUnit = LT.unit)
# MAGIC LEFT JOIN 
# MAGIC     `arealytics-databricks_unity_catalog`.arealyticstrusted.PropertySummary PS 
# MAGIC ON 
# MAGIC     PS.PropertyID = P.PropertyID 
# MAGIC LEFT JOIN 
# MAGIC     `arealytics-databricks_unity_catalog`.arealyticstrusted.City CTY 
# MAGIC ON 
# MAGIC     CTY.CityID = A.CityID AND LT.suburb = CTY.CityName
# MAGIC LEFT JOIN `arealytics-databricks_unity_catalog`.arealyticstrusted.propertysuffixmap as suff on p.StreetSuffix1 = suff.SuffixID
# MAGIC WHere  
# MAGIC LT.Cleaned_Unit IS NOT NULL 
# MAGIC and PS.ResearchTypeID not in (4,0)
# MAGIC AND P.CondoUnit IS NOT NULL
# MAGIC )
# MAGIC SELECT * FROM RankedMatches
# MAGIC -- where id= '102409'
# MAGIC WHERE rn = 1;
# MAGIC
# MAGIC UPDATE `arealytics-databricks_unity_catalog`.arealyticstrusted.reiq_Lease_Temp lt
# MAGIC SET lt.PropertyID = (
# MAGIC     SELECT MAX(t.PropertyID)
# MAGIC     FROM `arealytics-databricks_unity_catalog`.arealyticstrusted.reiq_temp t 
# MAGIC     WHERE lt.id = t.id
# MAGIC     -- AND lt.code = t.code
# MAGIC )
# MAGIC WHERE lt.PropertyID IS NULL;
# MAGIC
# MAGIC ------------------- PASS 3
# MAGIC
# MAGIC CREATE OR REPLACE TABLE `arealytics-databricks_unity_catalog`.arealyticstrusted.reiq_temp AS
# MAGIC WITH RankedMatches AS (
# MAGIC     SELECT 
# MAGIC     lt.id,
# MAGIC     -- lt.created,
# MAGIC     -- lt.code,
# MAGIC     A.ParentID AS PropertyID,
# MAGIC     LT.formatted_address,
# MAGIC     A.AddressText AS AL_address,
# MAGIC     LT.postal_code AS `reiqZipCode`, 
# MAGIC     A.ZipCode AS `AL_ZipCode`,
# MAGIC     LT.suburb AS `reiq_City`,
# MAGIC     CTY.CityName AS `AL_City`,
# MAGIC     LT.Cleaned_Street_Name AS `reiq_StreetName`,
# MAGIC     A.AddressStreetName AS `AL_StreetName`,
# MAGIC     P.CondoTypeID,
# MAGIC     LT.StreetNumberMin AS reiq_StreetNumberMin,
# MAGIC     LT.StreetNumberMax AS reiq_StreetNumberMax,
# MAGIC     A.StreetNumberMin AS AL_StreetNumberMin,
# MAGIC     A.StreetNumberMax AS AL_StreetNumberMax,
# MAGIC     ROW_NUMBER() OVER (
# MAGIC         PARTITION BY LT.id
# MAGIC         ORDER BY (COALESCE(A.StreetNumberMax, A.StreetNumberMin) - A.StreetNumberMin) ASC
# MAGIC     ) AS rn
# MAGIC     FROM `arealytics-databricks_unity_catalog`.arealyticstrusted.reiq_Lease_Temp LT 
# MAGIC LEFT JOIN 
# MAGIC     `arealytics-databricks_unity_catalog`.arealyticstrusted.Address A 
# MAGIC ON 
# MAGIC     A.ParentTableID=1 AND A.IsActive=1 AND LT.postal_code = A.ZipCode AND lower(LT.Cleaned_Street_Name) = lower(A.AddressStreetName)
# MAGIC     AND 
# MAGIC         (
# MAGIC 		LT.Street_Number_cleaned =  A.StreetNumberMin
# MAGIC 		OR 
# MAGIC         LT.Street_Number_cleaned =  A.StreetNumberMax
# MAGIC         OR
# MAGIC         LT.StreetNumberMin BETWEEN A.StreetNumberMin AND COALESCE(A.StreetNumberMax, A.StreetNumberMin))
# MAGIC LEFT JOIN 
# MAGIC     `arealytics-databricks_unity_catalog`.arealyticstrusted.Property_detail P 
# MAGIC ON 
# MAGIC     P.PropertyID = A.ParentID AND (P.CondoUnit IS NULL OR P.CondoUnit = LT.unit)
# MAGIC LEFT JOIN 
# MAGIC     `arealytics-databricks_unity_catalog`.arealyticstrusted.PropertySummary PS 
# MAGIC ON 
# MAGIC     PS.PropertyID = P.PropertyID 
# MAGIC LEFT JOIN 
# MAGIC     `arealytics-databricks_unity_catalog`.arealyticstrusted.City CTY 
# MAGIC ON 
# MAGIC     CTY.CityID = A.CityID AND LT.suburb = CTY.CityName
# MAGIC LEFT JOIN `arealytics-databricks_unity_catalog`.arealyticstrusted.propertysuffixmap as suff on p.StreetSuffix1 = suff.SuffixID
# MAGIC
# MAGIC where PS.ResearchTypeID not in (4,0)
# MAGIC )
# MAGIC
# MAGIC SELECT * FROM RankedMatches
# MAGIC -- where id= '102409'
# MAGIC WHERE rn = 1;
# MAGIC
# MAGIC UPDATE `arealytics-databricks_unity_catalog`.arealyticstrusted.reiq_Lease_Temp lt
# MAGIC SET lt.PropertyID = (
# MAGIC     SELECT MAX(t.PropertyID)
# MAGIC     FROM `arealytics-databricks_unity_catalog`.arealyticstrusted.reiq_temp t 
# MAGIC     WHERE lt.id = t.id
# MAGIC     -- AND lt.code = t.code
# MAGIC )
# MAGIC WHERE lt.PropertyID IS NULL;
# MAGIC
# MAGIC create or replace table `arealytics-databricks_unity_catalog`.arealyticstrusted.reiq_pid_link as
# MAGIC select * from `arealytics-databricks_unity_catalog`.arealyticstrusted.reiq_Lease_Temp;
# MAGIC
# MAGIC drop table  `arealytics-databricks_unity_catalog`.arealyticstrusted.reiq_Lease_Temp;
# MAGIC drop table  `arealytics-databricks_unity_catalog`.arealyticstrusted.reiq_Temp

# COMMAND ----------

# MAGIC %sql
# MAGIC select count(*) from `arealytics-databricks_unity_catalog`.arealyticstrusted.reiq_pid_link 
# MAGIC where PropertyID is not null

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT
# MAGIC geo.id,
# MAGIC     pid.propertyPid,
# MAGIC     main.premisesstreet1,
# MAGIC     main.premisessuburb,
# MAGIC     formatted_address,
# MAGIC     REGEXP_SUBSTR(geo.street_number, '\\d+') AS Street_Number_cleaned,
# MAGIC     geo.street_number,
# MAGIC     CAST(
# MAGIC         SPLIT(geo.street_number, '-')[0] AS INT
# MAGIC     ) AS StreetNumberMin,
# MAGIC     CAST(
# MAGIC         CASE 
# MAGIC             WHEN geo.street_number LIKE '%-%' THEN
# MAGIC                 SPLIT(geo.street_number, '-')[1]
# MAGIC             ELSE
# MAGIC                 NULL
# MAGIC         END AS INT
# MAGIC     ) AS StreetNumberMax,
# MAGIC     geo.suburb,
# MAGIC     geo.Unit,
# MAGIC     geo.postal_code,
# MAGIC     geo.latitude,
# MAGIC     geo.longitude,
# MAGIC     CASE 
# MAGIC         WHEN geo.unit = '00 00' OR geo.unit IN ('00', '', '0') THEN NULL 
# MAGIC         ELSE REGEXP_EXTRACT(geo.unit, '(\\d+)', 1)
# MAGIC     END as Cleaned_Unit,
# MAGIC     -- REGEXP_REPLACE(street_name, CONCAT('\\s+(', suffix_list.suffix_regex, ')$'), '') as Cleaned_Street_Name,
# MAGIC     CAST(NULL as INT) as PropertyID
# MAGIC FROM 
# MAGIC     `arealytics-databricks_unity_catalog`.arealyticstrusted.reiq_geocoded_data geo
# MAGIC
# MAGIC     LEFT JOIN  `arealytics-databricks_unity_catalog`.arealyticstrusted.reiq_leasesnapshot as main
# MAGIC     ON geo.id = main.id
# MAGIC
# MAGIC     left jooin`arealytics-databricks_unity_catalog`.arealyticstrusted.reiq_pid_link as pid
# MAGIC     on pid.id = main.id
# MAGIC
# MAGIC     LEFT JOIN `arealytics-databricks_unity_catalog`.arealyticstrusted.Address A 
# MAGIC     on a.parentid = pid.propertyPid
# MAGIC
# MAGIC
