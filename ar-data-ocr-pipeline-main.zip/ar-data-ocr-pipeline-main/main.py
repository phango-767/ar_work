import asyncio
import aiohttp
import json
import ast
import logging
from datetime import datetime
from multiprocessing import Pool
from glob import glob
import os

output_dir = 'urls_results'
os.makedirs(output_dir,exist_ok=True)

logging.basicConfig(filename='errors/ocr.log', level=logging.DEBUG, 
                    format='%(asctime)s %(levelname)s %(name)s %(message)s')


async def process_url(api_key, prompt, image_url, session):
    """
    Process a single URL using the OpenAI API.

    Args:
        api_key (str): The OpenAI API key.
        prompt (str): The prompt to send to the API.
        image_url (str): The URL of the image to process.
        session (aiohttp.ClientSession): The aiohttp client session.

    Returns:
        dict: A dictionary containing the image URL and the OCR results.
    """
    try:
        response = await session.post(
            'https://api.openai.com/v1/chat/completions',
            headers={'Authorization': f'Bearer {api_key}'},
            json={
                'model': 'gpt-4o',
                'messages': [
                    {"role": "user", "content": [
                        {"type": "text", "text": prompt},
                        {"type": "image_url", "image_url": {"url": image_url}}
                    ]}
                ],
                'max_tokens': 3000
            }
        )
        data = await response.json()
        #print(f"Raw API Response for {image_url}: {json.dumps(data, indent=2)}")

        if 'choices' in data and data['choices']:
            gpt_response = data['choices'][0]['message']['content']
            clean_response = gpt_response.replace('```json', '').replace('```', '').replace('\n', '')
            try:
                parsed_response = json.loads(clean_response)
            except json.JSONDecodeError:
                logging.error(f"Failed to decode JSON for URL {image_url}: {clean_response}")

                parsed_response = clean_response
            return {"image_url": image_url, "ocr_results": parsed_response}
        else:
            return {"image_url": image_url, "ocr_results": "No valid response"}
    except Exception as e:
        logging.error(f"Error processing URL {image_url}: {str(e)}")
        return {"image_url": image_url, "ocr_results": f"Error: {str(e)}"}


async def process_calls(api_key, request_json):
    """
    Process a batch of URLs using the OpenAI API.

    Args:
        api_key (str): The OpenAI API key.
        request_json (dict): A dictionary containing the batch ID, prompt, and list of URLs.

    Returns:
        list: A list of dictionaries containing the image URLs and OCR results.
    """
    async with aiohttp.ClientSession() as session:
        replies = []
        calls = request_json['calls']

        json_urls = ast.literal_eval(calls[0])
        prompt = calls[1]
        logging.info(f"Running batch {request_json['id']}...")
        tasks = [process_url(api_key, prompt, url, session) for url in json_urls]
        call_results = await asyncio.gather(*tasks)
        #print(f"Call Results: call_results")
        # Serialize the reply for each call into a JSON string
        serialized_replies = json.dumps(call_results, separators=(',', ':'))
        replies.append(serialized_replies)

        logging.info(f"Finished batch {request_json['id']}...")
        
        #print(f"Final Results: replies")
        return replies


def get_tenant_names(request_json):
    """
    Process a batch of URLs using the OpenAI API and save the results to a JSON file.

    Args:
        request_json (dict): A dictionary containing the batch ID, prompt, and list of URLs.

    Returns:
        list: A list of dictionaries containing the image URLs and OCR results.
    """
    api_key = "sk-v1-grhnMQB2gDtKKTngg5vVT3BlbkFJGidfL9jKAGSUZJ2GKqFC"


    print(datetime.now().time())
    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)
    replies = loop.run_until_complete(process_calls(api_key, request_json))
    loop.close()

    with open(f"urls_results/batch_{request_json['id']}.json", 'w', encoding='utf-8') as f:
        json.dump(replies, f, ensure_ascii=False)

    return replies


if __name__ == '__main__':
    batches = glob(f"urls/*.json")
    json_files = list()


    for path in batches:
        json_files.append(json.load(open(path)))

    with Pool(len(batches)) as p:
        results = p.map(get_tenant_names, json

with open(f"urls_results/consolidated.json", 'w', encoding='utf-8') as f:
    json.dump(results, f, ensure_ascii=False)