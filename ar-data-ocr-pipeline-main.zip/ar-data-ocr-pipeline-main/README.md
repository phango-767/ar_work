# ar-data-ocr-pipeline

This code is a client for the OpenAI OCR API, which allows you to send images to the API and receive the extracted text in response. The code is designed to process batches of images and save the results to JSON files.

## REQUIREMENTS

Python 3.7+

aiohttp library

json library

ast library

logging library

datetime library

multiprocessing library

glob library

OpenAI API key (obtainable from the OpenAI website)

## USAGE

Install the required libraries by running pip install aiohttp json ast logging datetime multiprocessing glob

Create a directory called urls and add JSON files containing the image URLs and prompts to be processed. Each JSON file should have the following format:

```
{
    "id": "batch_id",
    "calls": [
        ["image_url1", "image_url2", ...],
        "prompt"
    ]
}
```

Run the code by executing python main.py

The code will process each batch of images and save the results to a JSON file in the urls_results directory. The file will have the same name as the original JSON file, but with a .json extension.

The code will also save a consolidated JSON file containing all the results in the urls_results directory.

## CONFIGURATION

output_dir: The directory where the results will be saved. Default: urls_results

api_key: The OpenAI API key. Default: xxxxxxxxxxx

logging.basicConfig: The logging configuration. Default: filename='errors/ocr.log', level=logging.DEBUG, format='%(asctime)s %(levelname)s %(name)s %(message)s'

## NOTES

The code uses the aiohttp library to make asynchronous requests to the OpenAI API.

The code uses the multiprocessing library to process multiple batches of images in parallel.

The code uses the glob library to find all JSON files in the urls directory.

The code assumes that the OpenAI API key is valid and has the necessary permissions to make requests to the API.

The code assumes that the image URLs are valid and can be accessed by the OpenAI API.
