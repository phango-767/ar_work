from pyspark.sql import SparkSession
from pyspark.sql.functions import current_date
from datetime import datetime

def create_raw_table(UserActivity_df, spark):
    """
    Conditionally create or replace a raw table from the DataFrame based on today's date,
    only if there is no data for today already present.
    """
    # Add a DateInserted column with today's date to the DataFrame
    UserActivity_df = UserActivity_df.withColumn("DateInserted", current_date())

    # Create a temporary view of the updated DataFrame
    UserActivity_df.createOrReplaceTempView("temp_user_activity_df")

    # Check if there is data for today's date in the target table
    today = datetime.now().strftime('%Y-%m-%d')
    check_data_exists_query = f"""
    SELECT COUNT(*) as cnt FROM `arealytics-databricks_unity_catalog`.arealyticstrusted.pro_userActivityRaw
    WHERE DateInserted = '{today}'
    """
    
    result = spark.sql(check_data_exists_query).collect()
    data_exists_for_today = result[0]["cnt"] > 0

    if not data_exists_for_today:
        # If there's no data for today, replace the table with today's data
        UserActivity_df.write.format("delta") \
            .mode("overwrite") \
            .option("overwriteSchema", "true") \
            .saveAsTable("`arealytics-databricks_unity_catalog`.arealyticstrusted.pro_userActivityRaw")
        print("Table created or replaced as there was no data for today.")
    else:
        print("Data for today already exists in the table. No action taken.")