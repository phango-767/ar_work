from delta.tables import DeltaTable
from pyspark.sql import functions as F

def create_or_update_trusted(df, spark, table_name):
    """
    Creates a Delta table if it doesn't exist, or replaces the table entirely with 
    data for the current day, removing any historical data.

    Args:
        df (pyspark.sql.DataFrame): The DataFrame to be written to the Delta table.
        table_name (str): The name of the Delta table.
    """

    full_table_name = f"`arealytics-databricks_unity_catalog`.arealyticstrusted.pro_{table_name}_trusted"
    current_date = F.current_date().cast("string")

    if DeltaTable.isDeltaTable(spark, full_table_name):
        delta_table = DeltaTable.forName(spark, full_table_name)

        # Drop the existing table
        delta_table.drop()

    # Create the Delta table with the new data
    df.withColumn("DateInserted", F.lit(current_date)) \
      .write.format("delta").mode("overwrite").saveAsTable(full_table_name)

    print(f"Table {table_name} updated with data for today.")