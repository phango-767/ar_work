from pyspark.sql.types import StructType, StructField, StringType, MapType
from pyspark.sql.functions import from_json, col, explode

def parse_column(df, column_name):
    # Dynamically generate schema for the specified column
    parsed_df = df.withColumn(f"parsed_{column_name}", from_json(col(column_name), MapType(StringType(), StringType())))
    keys_df = parsed_df.select(explode(col(f"parsed_{column_name}"))).select("key")
    unique_keys = set(keys_df.rdd.map(lambda row: row[0]).collect())

    if "PropertyID" in unique_keys:
        unique_keys = {column if column != "PropertyID" else "PID" for column in unique_keys}
    
    if "pageSize" in unique_keys:
        unique_keys = {column if column != "pageSize" else "PageSize2" for column in unique_keys}

    # Define a schema dynamically based on unique keys
    column_fields = [StructField(key, StringType(), True) for key in unique_keys]
    column_schema = StructType(column_fields)

    # Parse the specified column using the specified schema
    df_parsed_column = df.withColumn(column_name, from_json(col(column_name), column_schema))

    # Extract all fields from the parsed column
    df_unflattened_column = df_parsed_column.select(
        "UserActivityID",
        "ParentTableID",
        col(f"{column_name}.*")
    )
    
    return df_unflattened_column