def mysql_user_activity_load(spark):
    driver = "org.mariadb.jdbc.Driver"

    database_host = "empirical01-uat-ore.cbilzzla5ot8.us-west-2.rds.amazonaws.com"
    database_port = "3306" 
    database_name = "Empirical_Prod"
    # table = "<table-name>"
    user = "dbuser-databricks"
    password = "x-x-x-x"

    url = f"jdbc:mysql://{database_host}:{database_port}/{database_name}"
    url2 = f"jdbc:mysql://{database_host}:{database_port}/Empirical_Tenants"

    # Load UserActivity table and create temporary view
    UserActivity_df = spark.read.jdbc(url, "UserActivity", properties={"user": user, "password": password})
    UserActivity_df.createOrReplaceTempView("UserActivity")

    return UserActivity_df