import sys
import importlib
sys.path.append('src')

# from databricks.sdk.runtime import spark
# from pyspark.sql import SparkSession
from load_from_db import mysql_user_activity_load
from create_raw import create_raw_table
from json_unpack import parse_column
from create_trusted import create_or_update_trusted


try:
    print("Loading data from MySQL")
    UserActivity_df = mysql_user_activity_load(spark)
    print("Data loaded successfully")

    print("Creating raw table.")
    create_raw_table(UserActivity_df, spark)

    print("Parsing Columns")
    parsed_user_criteria_df = parse_column(UserActivity_df, "UserCriteria")
    parsed_details_df = parse_column(UserActivity_df, "Details")
    print("Parsing Completed")

    print("Creating or updating trusted tables")
    create_or_update_trusted(parsed_user_criteria_df, spark,  "useractivity_UserCriteria")
    create_or_update_trusted(parsed_details_df, spark,  "useractivity_Details")
    print("Trusted tables updated")

except Exception as e:
    print(f"An error occurred: {e}")