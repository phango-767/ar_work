# Arealytics Dataform Sandbox

## Table of Contents

- [About](#about)
- [Getting Started](#getting_started)
- [Usage](#usage)
- [Contributing](../CONTRIBUTING.md)

## About <a name = "about"></a>

within our organization. It leverages Dataform to define, schedule, and deploy data transformation jobs that move data from raw ingestion stages through to refined analytics-ready models. This setup is intended to support scalable, efficient data management practices in a structured SQL data warehouse environment.

## Getting Started <a name = "getting_started"></a>

These instructions will help you get a copy of the project up and running on your local machine for development and testing purposes. See the Deployment section for notes on how to deploy the project on a live system.

### Prerequisites

Before you begin, ensure you have the following installed:

Git
Dataform CLI
You can install Dataform CLI using npm:

```
npm install -g @dataform/cli
```

### Installing

1. Clone the Git repository:
```
git clone <repository-url>
cd <repository-name>

```

2.Install necessary dependencies:
```
npm install

```

3.dataform init
```
npm install

```

4.Start developing by editing or adding SQLX files in the respective directories.

## Folder Structure <a name = "folder_structure"></a>

The project's folder structure is organized as follows to facilitate easy navigation and clear separation of concerns:

/definitions - Contains SQLX files defining our datasets.
/data_source_name (e.g., REA, REIV)
/raw - Raw data processing.
/trusted - Intermediate data transformations.
/curated - Refined, analytics-ready data models.
/includes - Reusable SQL and JavaScript code.
/environments.json - Configuration settings for different environments (TODO).
/tests - Data validation and quality tests (TODO).
/docs - Documentation for different data sources and processes (TODO).

## Usage <a name = "usage"></a>

To use the system, refer to the SQLX files in the /definitions directory to understand the data models and transformations. Run individual scripts or schedule jobs through Dataform to process and move data through stages:

1.Ensure all tests pass:
```
dataform test

```

2.Commit all changes and merge them into the main branch.
3.Run
```
dataform run

```
