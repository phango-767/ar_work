function createSheetsExternalTableSQL(
    dataset,
    name,
    format,
    folderId,
    sheetRange
) {
    const sheetUrl = `https://docs.google.com/spreadsheets/d/${folderId}/`;
    return `
CREATE OR REPLACE EXTERNAL TABLE \`${dataset}.${name}\`
OPTIONS (
    format = '${format}',
    uris = ['${sheetUrl}'],
    skip_leading_rows = 1,
    sheet_range = '${sheetRange}'
)
`;
}

module.exports = {
    createSheetsExternalTableSQL
};