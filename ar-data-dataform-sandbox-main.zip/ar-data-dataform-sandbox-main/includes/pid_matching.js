function generateMatchingSQL(
    dataset,
    sourceTableName,
    outputTableName,
    uid,
    streetNumber,
    streetName,
    city,
    unit,
    postcode
) {
    const source_table = `${dataset}.${sourceTableName}`;
    const output_table = `${dataset}.${outputTableName}`;
    const generateSuffixSQL = `SELECT STRING_AGG(CONCAT(s.suffix, '|', SuffixName), '|') AS suffix_regex FROM ar_rep_Empirical_Prod.Suffix`;

    // Helper function to create SQL part for cleaned street number
    function generateStreetNumberSQL(field) {
        return `(COALESCE(SAFE_CAST(SPLIT(${field}, '-')[0] AS int64), SAFE_CAST(REGEXP_SUBSTR(${field}, '\\\\d+') AS int64)))`;
    }

    // Helper function to create SQL part for maximum street number
    function generateMaxStreetNumberSQL(field) {
        return `(SAFE_CAST(CASE WHEN ${field} LIKE '%-%' THEN SPLIT(${field}, '-')[1] ELSE NULL END AS int64))`;
    }

    // Initial SQL to create the property address mapping table
    const createMappingTableSQL = `
CREATE OR REPLACE TABLE ${output_table} AS
SELECT
    ${uid} AS uid,
    REGEXP_SUBSTR(${streetNumber}, '\\\\d+') AS streetNumber,
    ${generateStreetNumberSQL(streetNumber)} AS streetNumberMin,
    ${generateMaxStreetNumberSQL(streetNumber)} AS streetNumberMax,
 TRIM(REGEXP_REPLACE(INITCAP(${streetName}), CONCAT('\\\\s+(', suffix_list.suffix_regex, ')$'), '')) AS streetName,
    ${city} AS city,
    TRIM(REGEXP_EXTRACT(${unit}, '(\\\\d+)', 1)) AS Unit,
    TRIM(SAFE_CAST(safe_cast(${postcode} AS int64) AS STRING)) AS postcode,
    CAST(NULL AS int64) AS propertyID,
    CAST(NULL AS string) AS layerPassed,
    CAST(NULL AS string) AS phasePassed
FROM
    ${source_table}
CROSS JOIN (${generateSuffixSQL} as s) AS suffix_list;
`;

    // Function to generate SQL for address matching and updates
    function generateAddressMatchingAndUpdatingSQL() {
        // Helper function to generate the common join conditions and filters
        function generateJoinAndFilterSQL() {
            return `
LEFT JOIN ar_rep_Empirical_Prod.Address A ON A.ParentTableID = 1 AND A.IsActive = 1 AND LT.postcode = A.ZipCode
    AND TRIM(LOWER(LT.streetName)) = TRIM(LOWER(A.AddressStreetName))
    AND (
        (LT.streetNumberMin BETWEEN A.streetNumberMinN AND COALESCE(A.streetNumberMaxN, A.streetNumberMinN) AND LT.streetNumberMax <= A.streetNumberMaxN)
        OR (LT.streetNumberMax BETWEEN A.streetNumberMinN AND COALESCE(A.streetNumberMaxN, A.streetNumberMinN) AND LT.streetNumberMin >= A.streetNumberMinN)
        OR LT.streetNumberMin = A.streetNumberMinN
        OR LT.streetNumberMax = A.streetNumberMaxN
        OR LT.streetNumberMin = A.streetNumberMaxN)
LEFT JOIN ar_qld_property.vw_PropertyDetail P ON P.PropertyID = A.ParentID AND (P.CondoUnit IS NULL OR P.CondoUnit = LT.unit)
LEFT JOIN ar_rep_Empirical_Prod.PropertySummary PS ON PS.PropertyID = P.PropertyID
LEFT JOIN ar_rep_Empirical_Prod.City CTY ON CTY.CityID = A.CityID AND LT.city = CTY.CityName
LEFT JOIN ar_rep_Empirical_Prod.Suffix AS suff ON P.StreetSuffix1 = suff.SuffixID
`;
        }

        // SQL template for creating a temporary property map table and updating the main table
        const passes = [{
                passNumber: 1,
                unitCondition: 'LT.unit IS NULL',
                additionalCondition: 'AND (P.CondoTypeID IS NULL OR P.CondoTypeID <> 2) AND PS.ResearchTypeID <> 4'
            },
            {
                passNumber: 2,
                unitCondition: 'LT.unit IS NOT NULL',
                additionalCondition: 'AND PS.ResearchTypeID <> 4 AND P.CondoUnit IS NOT NULL'
            },
            {
                passNumber: 3,
                unitCondition: '',
                additionalCondition: 'PS.ResearchTypeID <> 4'
            }
        ]

        return passes.map(({
            passNumber,
            unitCondition,
            additionalCondition
        }) => `
-- Pass ${passNumber}
CREATE OR REPLACE TABLE ar_curated.temp_property_map AS
WITH RankedMatches AS (
    SELECT
        LT.uid AS id,
        A.ParentID AS PropertyID,
        A.AddressText AS AL_address,
        LT.postcode AS ZipCode,
        A.ZipCode AS AL_ZipCode,
        LT.city AS City,
        CTY.CityName AS AL_City,
        LT.streetName AS StreetName,
        A.AddressStreetName AS AL_StreetName,
        P.CondoTypeID,
        LT.streetNumberMin AS streetNumberMin,
        LT.streetNumberMax AS streetNumberMax,
        A.streetNumberMin AS AL_streetNumberMin,
        A.streetNumberMax AS AL_streetNumberMax,
        ROW_NUMBER() OVER (PARTITION BY cast(LT.uid as int64) ORDER BY (COALESCE(SAFE_CAST(A.streetNumberMax AS int64), SAFE_CAST(A.streetNumberMin AS int64)) - SAFE_CAST(A.streetNumberMin AS int64)) ASC) AS rn
        
    FROM
        ${output_table} LT
    ${generateJoinAndFilterSQL()}
    WHERE
        ${unitCondition} ${additionalCondition}
)
SELECT
    *
FROM
    RankedMatches
WHERE
    rn = 1;

UPDATE
    ${output_table} LT
SET
    LT.PropertyID = (
        SELECT MAX(t.PropertyID)
        FROM ar_curated.temp_property_map t
        WHERE LT.uid = t.id
    )
WHERE
    LT.PropertyID IS NULL;

DROP TABLE IF EXISTS ar_curated.temp_property_map;
`).join('');
    }

    return createMappingTableSQL + generateAddressMatchingAndUpdatingSQL();
}

module.exports = {
    generateMatchingSQL
};
