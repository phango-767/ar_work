function renderleaseViewSQL(table, dimensions) {
const mappings = {
    "PropertyID": "PropertyID",
    "Property Name": "PropertyName",
    "Alt Tenant Name": "AltTenantName",
    "Leased Sqm": "LeasedSqm",
    "Commencing Date": "CommencingDate",
    "Expiry Date": "ExpiryDate",
    "Face Rent - Annual": "FaceRentAnnual",
    "Lease Rate Type": "LeaseRateType",
    "Outgoings (per sqm)": "OutgoingsPerSqm",
    "Escalation Rate %": "EscalationRate",
    "Term (months)": "TermMonths",
    "Renewal Options (No. of Months)": "RenewalOptionsNoOfMonths",
    "Recorded Date": "RecordedDate",
    "Lease/Sublease": "LeaseSublease",
    "Lease Trans Type": "LeaseTransType",
    "Transaction Comments": "TransactionComments",
    "Suite Comments": "SuiteComments",
    "Execution Date": "ExecutionDate",
    "Space General Use": "SpaceGeneralUse",
    "Lease Status": "LeaseStatus",
    "SignDate": "SignDate",
    "BankGuaranteeAmount": "BankGuaranteeAmount",
    "GSTIncluded": "GSTIncluded",
    "TransactionOriginationTypeID": "TransactionOriginationTypeID",
    "IsStartingRateConfirmed": "IsStartingRateConfirmed",
    "ShareLevelID": "ShareLevelID",
    "IsExpDateConfirmed": "IsExpDateConfirmed",
    "IsTermsConfirmed": "IsTermsConfirmed",
    "ConfirmedTenantID": "ConfirmedTenantID",
    "DealingNumber": "DealingNumber",
    "RentFreePeriod": "RentFreePeriod",
    "NoticePeriodMin": "NoticePeriodMin",
    "NoticePeriodMax": "NoticePeriodMax",
    "ListingTypeID": "ListingTypeID",
    "HidedBy": "HidedBy",
    "IsHidden": "IsHidden",
    "HidedDate": "HidedDate",
    "HideReasonID": "HideReasonID",
    "HideReasonComments": "HideReasonComments",
    "SubHideReasonID": "SubHideReasonID",
    "MismatchedTaggedBy": "MismatchedTaggedBy",
    "IsMismatched": "IsMismatched",
    "UID": "UID",
    "Url": "Url",
    "AgentName1": "AgentName1",
    "AgentEmail1": "AgentEmail1",
    "AgentName2": "AgentName2",
    "AgentEmail2": "AgentEmail2",
    "Address": "Address",
    "City": "City",
    "State": "State",
    "Zip": "Zip",
    "Level": "Level",
    "Suite": "Suite",
    "ConfirmationNotes": "ConfirmationNotes",
    "IsCondo": "IsCondo",
    "Fitout": "Fitout",
    "EscalationType": "EscalationType",
    "IsOccupDateConfirmed": "IsOccupDateConfirmed",
    "Folio": "Folio",
    "StageID": "StageID",
    "Status": "Status",
    "ExceptionReason": "ExceptionReason",
    "CreatedDate": "CreatedDate",
    "CreatedBy": "CreatedBy",
    "ModifiedDate": "ModifiedDate",
    "ModifiedBy": "ModifiedBy",
    "LeaseID": "LeaseID",
    "IsActive": "IsActive",
    "BatchID": "BatchID",
    "ProviderID": "ProviderID",
    "Longitude": "Longitude",
    "Latitude": "Latitude",
    "Location": "Location",
    "Space Type": "SpaceType",
    "LeaseFolio": "LeaseFolio",
    "Asking lease Rate/sqm/Year": "AskingLeaseRateSqmYear",
    "Asking lease Rate/sqm/Month": "AskingLeaseRateSqmMonth",
    "Head Title": "HeadTitle"
};


  return `
    select
    ${dimensions.map(field => {
      if (mappings[field]) {
        return `${mappings[field]} AS \`${field}\``;
      } else if (field === 'Location' || field.startsWith('CAST(NULL')) {
        return `CAST(NULL AS STRING) AS ${field.replace('CAST(NULL AS STRING) AS ', '')}`;
      } else {
        return `${field}`;
      }
    }).join(",\n")}
    from ${table}
  `;
}

module.exports = { renderleaseViewSQL };

