function renderreiqTransformationsSQLTable(tableRef1,tableRef2,tableRef3,tableRef4)
{
    return `
SELECT
  geo.PropertyID AS PropertyID,
  CAST(NULL AS STRING) AS PropertyName,
  geo.Address AS Address,
  geo.City AS City,
  usearch_raw_leases.fetch_state(geo.Address,cast(geo.Lat as float64 )) AS State,
  geo.Zip AS Zip,
CASE 
    WHEN main.tenantnamefull  is not null 
    THEN INITCAP(trim(main.tenantnamefull))
    ELSE INITCAP(trim(main.tenantfirmname))
END AS AltTenantName,
REGEXP_SUBSTR(geo.suite, r'\d+') AS Suite,
  
  CASE
    WHEN LOWER(TRIM(main.rentperiod)) LIKE '%week%' AND 52 * CAST(REPLACE(REGEXP_EXTRACT(main.rentamount, r'([0-9,.]+)'), ',', '') AS NUMERIC) > 2000
    THEN ROUND(52 * CAST(REPLACE(REGEXP_EXTRACT(main.rentamount, r'([0-9,.]+)'), ',', '') AS NUMERIC), 1)
    WHEN LOWER(TRIM(main.rentperiod)) LIKE '%month%' AND 12 * CAST(REPLACE(REGEXP_EXTRACT(main.rentamount, r'([0-9,.]+)'), ',', '') AS NUMERIC) > 2000
    THEN ROUND(12 * CAST(REPLACE(REGEXP_EXTRACT(main.rentamount, r'([0-9,.]+)'), ',', '') AS NUMERIC), 1)
    WHEN LOWER(TRIM(main.rentperiod)) LIKE '%year%' AND CAST(REPLACE(REGEXP_EXTRACT(main.rentamount, r'([0-9,.]+)'), ',', '') AS NUMERIC) > 2000
    THEN ROUND(CAST(REPLACE(REGEXP_EXTRACT(main.rentamount, r'([0-9,.]+)'), ',', '') AS NUMERIC), 1)
    ELSE CASE
      WHEN LOWER(TRIM(main.rentamount)) LIKE '%week%' AND 52 * CAST(REPLACE(REGEXP_EXTRACT(main.rentamount, r'([0-9,.]+)'), ',', '') AS NUMERIC) > 2000
      THEN ROUND(52 * CAST(REPLACE(REGEXP_EXTRACT(main.rentamount, r'([0-9,.]+)'), ',', '') AS NUMERIC), 1)
      WHEN LOWER(TRIM(main.rentamount)) LIKE '%month%' AND 12 * CAST(REPLACE(REGEXP_EXTRACT(main.rentamount, r'([0-9,.]+)'), ',', '') AS NUMERIC) > 2000
      THEN ROUND(12 * CAST(REPLACE(REGEXP_EXTRACT(main.rentamount, r'([0-9,.]+)'), ',', '') AS NUMERIC), 1)
      WHEN (LOWER(TRIM(main.rentamount)) LIKE '%year%' OR LOWER(TRIM(main.rentamount)) LIKE '%annum%') AND CAST(REPLACE(REGEXP_EXTRACT(main.rentamount, r'([0-9,.]+)'), ',', '') AS NUMERIC) > 2000
      THEN ROUND(CAST(REPLACE(REGEXP_EXTRACT(main.rentamount, r'([0-9,.]+)'), ',', '') AS NUMERIC), 1)
      ELSE NULL
    END
  END AS FaceRentAnnual,
  geo.Leasedsqm AS Leasedsqm,
  -- main.leaseoutgoingsperc AS RATE,
CASE
    WHEN REGEXP_CONTAINS(LOWER(TRIM(main.leaseoutgoingsperc)), r'(?i)\bincluded\b|\bnil\b|\bgross\b|\b') THEN 4
    WHEN REGEXP_CONTAINS(TRIM(main.leaseoutgoingsperc), r'%|\$') 
         OR REGEXP_CONTAINS(LOWER(TRIM(main.leaseoutgoingsperc)), r'(?i)\b|\bnet\b|\b') THEN 10
    ELSE NULL
END AS LeaseRateType
,

  CAST(NULL AS STRING) AS OutgoingsPerSqm,
  CASE 
    WHEN CAST(REGEXP_EXTRACT(main.rentreviewamount2, r'(\d+(\.\d+)?)') AS INT64) BETWEEN 2 AND 9 THEN CAST(REGEXP_EXTRACT(main.rentreviewamount2, r'(\d+(\.\d+)?)') AS INT64)
    ELSE NULL
  END AS EscalationRate,
  FORMAT_DATE('%d/%m/%Y', CAST(main.created AS DATE)) AS RecordedDate,
  1 AS LeaseSublease,
  1 AS LeaseTransType,
  NULL AS SuiteComments,
  IF(
  main.lessornamefull IS NULL AND
  main.lessorabn IS NULL AND
  main.lessoracn IS NULL AND
  main.lessorabnacn IS NULL AND
  main.tenantnamefull IS NULL AND
  main.tenantfirmname IS NULL AND
  main.tenantabn IS NULL AND
  main.tenantacn IS NULL AND
  main.tenantabnacn IS NULL AND
  main.tentermoptions IS NULL AND
  main.renewalfinaldate IS NULL AND
  main.premisespermitteduse IS NULL AND
  main.leaseoutgoingsperc IS NULL AND
  main.deposit IS NULL,
  NULL,
  CONCAT(
    IF(main.lessornamefull IS NOT NULL, CONCAT('Lessor Name: [', INITCAP(main.lessornamefull), ']'), ''), 
    IF(main.lessornamefull IS NOT NULL, '\n', ''),
    IF(main.lessorabn IS NOT NULL, CONCAT('Lessor ABN: [', INITCAP(main.lessorabn), ']'), ''), 
    IF(main.lessorabn IS NOT NULL, '\n', ''),
    IF(main.lessoracn IS NOT NULL, CONCAT('Lessor ACN: [', INITCAP(main.lessoracn), ']'), ''), 
    IF(main.lessoracn IS NOT NULL, '\n', ''),
    IF(main.lessorabnacn IS NOT NULL, CONCAT('Lessor ABN/ACN: [', INITCAP(main.lessorabnacn), ']'), ''), 
    IF(main.lessorabnacn IS NOT NULL, '\n', ''),
    IF(main.tenantnamefull IS NOT NULL OR main.tenantfirmname IS NOT NULL, CONCAT('Lessee Name: [', COALESCE(INITCAP(main.tenantnamefull),INITCAP(main.tenantfirmname)), ']'), ''), 
    IF(main.tenantnamefull IS NOT NULL OR main.tenantfirmname IS NOT NULL, '\n', ''),
    IF(main.tenantabn IS NOT NULL, CONCAT('Lessee ABN: [', INITCAP(main.tenantabn), ']'), ''), 
    IF(main.tenantabn IS NOT NULL, '\n', ''),
    IF(main.tenantacn IS NOT NULL, CONCAT('Lessee ACN: [', INITCAP(main.tenantacn), ']'), ''), 
    IF(main.tenantacn IS NOT NULL, '\n', ''),
    IF(main.tenantabnacn IS NOT NULL, CONCAT('Lessee ABN/ACN: [', INITCAP(main.tenantabnacn), ']'), ''), 
    IF(main.tenantabnacn IS NOT NULL, '\n', ''),
    IF(main.tentermoptions IS NOT NULL, CONCAT('RenewalOptions: [', INITCAP(main.tentermoptions), ']'), ''), 
    IF(main.tentermoptions IS NOT NULL, '\n', ''),
    IF(main.renewalfinaldate IS NOT NULL, CONCAT('OptionDate: [', INITCAP(main.renewalfinaldate), ']'), ''), 
    IF(main.renewalfinaldate IS NOT NULL, '\n', ''),
    IF(main.premisespermitteduse IS NOT NULL, CONCAT('SpaceType: [', INITCAP(main.premisespermitteduse), ']'), ''), 
    IF(main.premisespermitteduse IS NOT NULL, '\n', ''),
    IF(main.leaseoutgoingsperc IS NOT NULL, CONCAT('OutgoingsDescription: [', INITCAP(main.leaseoutgoingsperc), ']'), ''), 
    IF(main.leaseoutgoingsperc IS NOT NULL, '\n', ''),
    IF(main.deposit IS NOT NULL, CONCAT('Deposit: [', INITCAP(main.deposit), ']'), ''), 
    IF(main.deposit IS NOT NULL, '\n', '')
  )
) AS TransactionComments,
  FORMAT_DATE('%d/%m/%Y', CAST(main.AgreementDate AS DATE)) AS ExecutionDate, 
  main.AgreementDate AS ExecutionDate,

  CASE
    WHEN geo.SpaceGeneralUse IS NOT NULL
    THEN geo.SpaceGeneralUse
    ELSE spac.UseTypeName
  END AS SpaceGeneralUse,
  CASE 
    WHEN CAST(main.agencyperiodenddate AS DATE) < CURRENT_DATE() THEN 1
    ELSE 2
  END AS LeaseStatus,
  CAST(NULL AS STRING) AS ConfirmationNotes,
  CAST(NULL AS STRING) AS SignDate,
  CAST(NULL AS STRING) AS BankGuaranteeAmount,
  CASE 
    WHEN main.rentamount IS NOT NULL AND LOWER(TRIM(main.rentamount)) LIKE '%gst%'
    THEN 1
    ELSE 0
  END AS GSTIncluded,
  CAST(NULL AS STRING) AS IsCondo,
  CAST(NULL AS STRING) AS Fitout,
  4 AS TransactionOriginationTypeID,
  CASE 
    WHEN main.rentamount IS NOT NULL THEN 1
    ELSE 0
  END AS IsStartingRateConfirmed,
  5 AS ShareLevelID,
  CASE 
    WHEN main.agencyperiodenddate IS NOT NULL THEN 1
    ELSE 0
  END AS IsExpDateConfirmed,
  CASE
    WHEN LOWER(TRIM(main.rentreviewtypecb)) LIKE '%fixed%' OR LOWER(TRIM(main.rentreviewdate2)) LIKE '%fixed%' THEN 'Fixed'
    WHEN LOWER(TRIM(main.rentreviewtypecb)) LIKE '%index%' OR LOWER(TRIM(main.rentreviewdate2)) LIKE '%index%' THEN 'CPI'
    WHEN LOWER(TRIM(main.rentreviewtypecb)) LIKE '%market%' OR LOWER(TRIM(main.rentreviewdate2)) LIKE '%market%' THEN 'Market'
    WHEN LOWER(TRIM(main.rentreviewdate2)) LIKE '%cpi%' AND LOWER(TRIM(main.rentreviewdate2)) LIKE '%%%' THEN 'Fixed/CPI'
    ELSE NULL
  END AS EscalationType,
  CASE 
    WHEN main.agencyperiodenddate IS NOT NULL AND main.agencyperiodstartdate IS NOT NULL THEN 1
    ELSE 0
  END AS IsTermsConfirmed,
  CAST(NULL AS STRING) AS ConfirmedTenantID,
  CAST(main.id AS INT64) AS ID,
  NULL AS DealingNumber,
  CASE 
    WHEN main.agencyperiodstartdate IS NOT NULL THEN 1
    ELSE 0
  END AS IsOccupDateConfirmed,
  CAST(NULL AS STRING) AS RentFreePeriod,
CASE 
  WHEN LENGTH(REGEXP_REPLACE(TRIM(main.agencyperiodstartdate), '[^0-9]', '')) BETWEEN 5 AND 8 THEN
    -- Check if the date is in 'd/m/yyyy' or 'dd/mm/yyyy' format
    CASE 
      WHEN REGEXP_CONTAINS(TRIM(main.agencyperiodstartdate), r'^\d{1,2}/\d{1,2}/\d{4}$') THEN
         FORMAT_DATE('%d/%m/%Y',PARSE_DATE('%e/%m/%Y', TRIM(main.agencyperiodstartdate)))
      -- Check if the date is in 'dd Mmm yyyy' format
      WHEN REGEXP_CONTAINS(TRIM(main.agencyperiodstartdate), r'^\d{1,2} \w{3} \d{4}$') THEN
         FORMAT_DATE('%d/%m/%Y',PARSE_DATE('%d %b %Y', TRIM(main.agencyperiodstartdate)))
      ELSE
        NULL
    END
  ELSE
    NULL
END AS CommencingDate,
CASE 
  WHEN LENGTH(REGEXP_REPLACE(TRIM(main.agencyperiodenddate), '[^0-9]', '')) BETWEEN 5 AND 8 THEN
    -- Check if the date is in 'd/m/yyyy' or 'dd/mm/yyyy' format
    CASE 
      WHEN REGEXP_CONTAINS(TRIM(main.agencyperiodenddate), r'^\d{1,2}/\d{1,2}/\d{4}$') THEN
         FORMAT_DATE('%d/%m/%Y',PARSE_DATE('%e/%m/%Y', TRIM(main.agencyperiodenddate)))
      -- Check if the date is in 'dd Mmm yyyy' format
      WHEN REGEXP_CONTAINS(TRIM(main.agencyperiodenddate), r'^\d{1,2} \w{3} \d{4}$') THEN
         FORMAT_DATE('%d/%m/%Y',PARSE_DATE('%d %b %Y', TRIM(main.agencyperiodenddate)))
      ELSE
        NULL
    END
  ELSE
    NULL
END AS ExpiryDate,
CASE 
  WHEN LENGTH(REGEXP_REPLACE(TRIM(main.agencyperiodstartdate), '[^0-9]', '')) BETWEEN 5 AND 8 AND
       LENGTH(REGEXP_REPLACE(TRIM(main.agencyperiodenddate), '[^0-9]', '')) BETWEEN 5 AND 8 THEN
    CASE 
      -- Handle zero-padded dates like "30/09/2022"
      WHEN REGEXP_CONTAINS(TRIM(main.agencyperiodstartdate), r'^\d{2}/\d{2}/\d{4}$') AND 
           REGEXP_CONTAINS(TRIM(main.agencyperiodenddate), r'^\d{2}/\d{2}/\d{4}$') THEN
        CEIL(DATE_DIFF(PARSE_DATE('%d/%m/%Y', TRIM(main.agencyperiodenddate)), PARSE_DATE('%d/%m/%Y', TRIM(main.agencyperiodstartdate)), MONTH))
      -- Handle space-padded dates like " 1/ 9/2022" or "10/ 9/2022"
      WHEN REGEXP_CONTAINS(TRIM(main.agencyperiodstartdate), r'^\d{1,2}/\d{1,2}/\d{4}$') AND
           REGEXP_CONTAINS(TRIM(main.agencyperiodenddate), r'^\d{1,2}/\d{1,2}/\d{4}$') THEN
        CEIL(DATE_DIFF(PARSE_DATE('%e/%m/%Y', TRIM(main.agencyperiodenddate)), PARSE_DATE('%e/%m/%Y', TRIM(main.agencyperiodstartdate)), MONTH))
      -- Check if the date is in 'dd Mmm yyyy' format
      WHEN REGEXP_CONTAINS(TRIM(main.agencyperiodstartdate), r'^\d{1,2} \w{3} \d{4}$') AND 
           REGEXP_CONTAINS(TRIM(main.agencyperiodenddate), r'^\d{1,2} \w{3} \d{4}$') THEN
        CEIL(DATE_DIFF(PARSE_DATE('%d %b %Y', TRIM(main.agencyperiodenddate)), PARSE_DATE('%d %b %Y', TRIM(main.agencyperiodstartdate)), MONTH))
      ELSE
        NULL
    END
  ELSE
    NULL
END AS TermMonths,
  --  PARSE_DATE('%d/%m/%y', REPLACE(TRIM(main.agencyperiodstartdate), ' ', '')) as parsed,
  -- FORMAT_DATE('%d/%m/%Y', CAST(main.agencyperiodstartdate AS DATE)) AS CommencingDate,
  -- FORMAT_DATE('%d/%m/%Y', CAST(main.agencyperiodenddate AS DATE)) AS ExpiryDate,
  -- CASE
  --   WHEN CEIL(DATE_DIFF(CAST(main.agencyperiodenddate AS DATE), CAST(main.renewalfinaldate AS DATE), MONTH)) > 0
  --   THEN CAST(CEIL(DATE_DIFF(CAST(main.agencyperiodenddate AS DATE), CAST(main.renewalfinaldate AS DATE), MONTH)) AS STRING)

CASE 
  WHEN LENGTH(REGEXP_REPLACE(TRIM(main.renewalfinaldate), '[^0-9]', '')) BETWEEN 5 AND 8 AND
       LENGTH(REGEXP_REPLACE(TRIM(main.agencyperiodenddate), '[^0-9]', '')) BETWEEN 5 AND 8 THEN
    CASE 
      -- Handle zero-padded dates like "30/09/2022"
      WHEN REGEXP_CONTAINS(TRIM(main.renewalfinaldate), r'^\d{2}/\d{2}/\d{4}$') AND 
           REGEXP_CONTAINS(TRIM(main.agencyperiodenddate), r'^\d{2}/\d{2}/\d{4}$') THEN
        CEIL(DATE_DIFF(PARSE_DATE('%d/%m/%Y', TRIM(main.agencyperiodenddate)), PARSE_DATE('%d/%m/%Y', TRIM(main.renewalfinaldate)), MONTH))
      -- Handle space-padded dates like " 1/ 9/2022" or "10/ 9/2022"
      WHEN REGEXP_CONTAINS(TRIM(main.renewalfinaldate), r'^\d{1,2}/\d{1,2}/\d{4}$') AND
           REGEXP_CONTAINS(TRIM(main.agencyperiodenddate), r'^\d{1,2}/\d{1,2}/\d{4}$') THEN
        CEIL(DATE_DIFF(PARSE_DATE('%e/%m/%Y', TRIM(main.agencyperiodenddate)), PARSE_DATE('%e/%m/%Y', TRIM(main.renewalfinaldate)), MONTH))
      -- Check if the date is in 'dd Mmm yyyy' format
      WHEN REGEXP_CONTAINS(TRIM(main.renewalfinaldate), r'^\d{1,2} \w{3} \d{4}$') AND 
           REGEXP_CONTAINS(TRIM(main.agencyperiodenddate), r'^\d{1,2} \w{3} \d{4}$') THEN
        CEIL(DATE_DIFF(PARSE_DATE('%d %b %Y', TRIM(main.agencyperiodenddate)), PARSE_DATE('%d %b %Y', TRIM(main.renewalfinaldate)), MONTH))
      ELSE
        NULL
    END
  ELSE
    NULL
END AS NoticePeriodMin,
  CAST(NULL AS STRING) AS NoticePeriodMax,
  1 AS ListingTypeId,
  CAST(geo.Lat AS BIGNUMERIC) AS Lat,
  CAST(geo.Long AS BIGNUMERIC) AS Long,
  33 AS ProviderID

FROM ${(tableRef1)}

LEFT JOIN ${(tableRef2)}
ON cast(main.id as string) = geo.ID
LEFT JOIN ${(tableRef3)}
ON cast(spac.PropertyID as string) = geo.PropertyID
WHERE geo.zip in (SELECT DISTINCT zip FROM ${(tableRef4)} ) --39 433

`;

}

module.exports = {renderreiqTransformationsSQLTable

}











