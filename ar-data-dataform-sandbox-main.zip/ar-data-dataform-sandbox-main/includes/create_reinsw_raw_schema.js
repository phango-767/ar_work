const rawschema = [
    'Bond_Amount_0',
    'Option_Term_Renewal_1',
    'Outgoings_Checkbox_2',
    'Outgoings_Percentage_Increases_3',
    'Outgoings_Percentage_To_Be_Paid_4',
    'Outgoings_Special_Conditions_5',
    'Parties_Landlord_Name_Address_ABN_6',
    'Parties_Tenant_Name_Address_ABN_7',
    'Permitted_Use_8',
    'Premises_AddressFull_9',
    'Premises_Title_10',
    'Principal2_Director_NameFull_Signature_11',
    'Principal2_NameFull_Signature_12',
    'Principal_Director_NameFull_Signature_13',
    'Principal_NameFull_Signature_14',
    'Rent_Amount_15',
    'Rent_Commencement_Date_16',
    'Rent_Commencement_Date_2_17',
    'Rent_Commencement_Date_3_18',
    'Rent_Frequency_19',
    'Rent_Review_CPI_CB_20',
    'Rent_Review_CPI_Commencement_Anniversary_CB_21',
    'Rent_Review_Fixed_Amount_CB_22',
    'Rent_Review_Fixed_Percentage_23',
    'Rent_Review_Fixed_Percentage_CB_24',
    'Rent_Review_Fixed_Percentage_Commencement_Anniversary_CB_25',
    'Rent_Review_Fixed_Percentage_Other_CB_26',
    'Rent_Review_Market_CB_27',
    'Rent_Review_Market_Commencement_Anniversary_CB_28',
    'Tenant2_Director_NameFull_Signature_29',
    'Tenant2_NameFull_Signature_30',
    'Tenant_Company_Name_31',
    'Tenant_Director_NameFull_Signature_32',
    'Tenant_NameFull_33',
    'Tenant_NameFull_Signature_34',
    'Term_Duration_35',
    'Term_End_Date_Day_36',
    'Term_End_Date_Month_37',
    'Term_End_Date_Year_38',
    'Term_Start_Date_Day_39',
    'Term_Start_Date_Month_40',
    'Term_Start_Date_Year_41',
    'created_42',
    'form_id_43',
    'postcode_44',
    'updated_45'
]

function renderrawschemaSQL(table900, table910, rawschema) {
    return `SELECT
  ${rawschema.join(", ")}
FROM ${(table900)}
UNION ALL
SELECT
  ${rawschema.join(", ")}
FROM ${(table910)}
`



}

module.exports = {
    renderrawschemaSQL,
    rawschema
}
