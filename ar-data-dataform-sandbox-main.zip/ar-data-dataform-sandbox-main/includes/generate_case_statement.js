function generateDynamicCaseStatement(field, conditions) {
    const caseParts = conditions.map(condition => {
        return `WHEN ${condition.condition} THEN ${condition.result}`;
    }).join("\n            ");

    return `
        CASE
            ${caseParts}
            ELSE NULL
        END AS ${field}
    `;
}

function safeCastToInt(field) {
    return `SAFE_CAST(safe_cast(${field} AS float64) AS int64)`;
};

module.exports = { generateDynamicCaseStatement, safeCastToInt };
