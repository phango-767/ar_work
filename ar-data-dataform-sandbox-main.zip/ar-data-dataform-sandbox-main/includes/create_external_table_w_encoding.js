function generateExternalTableSQL(
    dataset,
    tableName,
    format,
    folderPath,
    fileName,
    options = {}
) {
    // Default options for CSV
    const csvOptions = {
        skipLeadingRows: options.skipLeadingRows !== undefined ? options.skipLeadingRows : 1,
        allowQuotedNewlines: options.allowQuotedNewlines !== undefined ? options.allowQuotedNewlines : true,
        allowJaggedRows: options.allowJaggedRows !== undefined ? options.allowJaggedRows : true,
        encoding: options.encoding || 'UTF-8' // Default to UTF-8 if not specified
    };

    const uri = `gs://${folderPath}/${fileName}.${format}`;

    // Start the SQL statement
    let sql = `
CREATE OR REPLACE EXTERNAL TABLE \`${dataset}.${tableName}\`
OPTIONS (
    format = '${format}',
    uris = ['${uri}']`;

    // Append CSV-specific options only if the format is 'CSV'
    if (format.toLowerCase() === 'csv') {
        sql += `,
    skip_leading_rows = ${csvOptions.skipLeadingRows},
    allow_quoted_newlines = ${csvOptions.allowQuotedNewlines ? 'TRUE' : 'FALSE'},
    allow_jagged_rows = ${csvOptions.allowJaggedRows ? 'TRUE' : 'FALSE'},
    encoding = '${csvOptions.encoding}'`;
    }

    sql += `
)`;
    return sql;
}

module.exports = {
    generateExternalTableSQL
};