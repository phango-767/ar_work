function generateTermSQL(sourceSchema, sourceTable, idField, startDateField, endDateField, promptPrefix, model) {
    const sql = `
SELECT
  ${idField},
  ${startDateField},
  ${endDateField},
  ml_generate_text_llm_result AS Gemini_Response
FROM ML.GENERATE_TEXT(
  MODEL ${model},
  (
    SELECT
      t.${idField},
      t.${startDateField},
      t.${endDateField},
      CONCAT(
        '${promptPrefix}',
        'Commencement Date: ', t.${startDateField}, '\\n',
        'End Date: ', IFNULL(t.${endDateField}, 'Ongoing'), '\\n',
        'Please calculate the term in months between these two dates', '\\n'
      ) AS prompt
    FROM ${sourceSchema}.${sourceTable} t
  ),
  STRUCT(
    TRUE AS flatten_json_output
  )
)`;

    return sql.trim();
}

module.exports = {
    generateTermSQL
};