function loadBQData(dataset, table, sourceUri) {
    return `bq load --autodetect --source_format=NEWLINE_DELIMITED_JSON --max_bad_records=5 ${dataset}.${table} ${sourceUri}`;
}


module.exports = {
    loadBQData

}
