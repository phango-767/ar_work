function generateSCD2SQL(
    dataset,
    sourceTableName,
    targetTableName,
    primaryKey
) {
    const sourceTable = `${dataset}.${sourceTableName}`;
    const targetTable = `${dataset}.${targetTableName}`;

    // Template to fetch column metadata for dynamic SCD check
    const fetchMetadataSQL = `
        -- Declare a variable to store an array of column names
            DECLARE column_names ARRAY<STRING>;

            -- Populate the column_names variable with the names of all columns from the specified table
            SET column_names = (
            SELECT ARRAY_AGG(column_name)
            FROM ${dataset}.INFORMATION_SCHEMA.COLUMNS
            WHERE table_name = '${sourceTableName}'
            );

            -- Optionally, use the variable in a SELECT statement to display the column names
            SELECT
            FORMAT(ARRAY_TO_STRING(column_names, ', ')) AS result;
    `;

    // Template for inserting new records
    const insertNewSQL = `
        INSERT INTO ${targetTable}
        SELECT SRC.*, CURRENT_TIMESTAMP() AS inserted_date, NULL AS updated_date, 1 AS current_indicator
        FROM ${sourceTable} AS SRC
        LEFT JOIN ${targetTable} AS TAR ON TAR.${primaryKey} = SRC.${primaryKey}
        WHERE TAR.${primaryKey} IS NULL;
    `;

    // Function to generate dynamic SQL for identifying changes
    const generateIdentifyChangesSQL = (columns) => {
        const changesConditions = columns.map(({ column_name, data_type }) => {
            if (['STRING', 'BYTES'].includes(data_type)) {
                return `COALESCE(SRC.${column_name}, '') != COALESCE(TAR.${column_name}, '')`;
            } else if (['INT64', 'FLOAT64', 'NUMERIC', 'BIGNUMERIC', 'BOOLEAN'].includes(data_type)) {
                return `COALESCE(SRC.${column_name}, 0) != COALESCE(TAR.${column_name}, 0)`;
            } else if (['DATE', 'DATETIME', 'TIMESTAMP', 'TIME'].includes(data_type)) {
                return `COALESCE(SRC.${column_name}, TIMESTAMP '0001-01-01 00:00:00 UTC') != COALESCE(TAR.${column_name}, TIMESTAMP '0001-01-01 00:00:00 UTC')`;
            } else {
                return `COALESCE(SRC.${column_name}, 'N/A') != COALESCE(TAR.${column_name}, 'N/A')`; // Default fall-back for other types
            }
        }).join(' OR ');

        return `
            CREATE OR REPLACE TEMP TABLE changes AS
            SELECT SRC.*
            FROM ${sourceTable} AS SRC
            INNER JOIN ${targetTable} AS TAR ON TAR.${primaryKey} = SRC.${primaryKey} AND TAR.current_indicator = 1
            WHERE ${changesConditions};
        `;
    };

    // Template for retiring old versions
    const retireOldSQL = `
        UPDATE ${targetTable} AS TAR
        SET current_indicator = 0, updated_date = CURRENT_TIMESTAMP()
        WHERE EXISTS (
            SELECT 1 FROM changes WHERE changes.${primaryKey} = TAR.${primaryKey}
        ) AND TAR.current_indicator = 1;
    `;

    // Template for inserting updated records
    const insertUpdatedSQL = `
        INSERT INTO ${targetTable}
        SELECT *, CURRENT_TIMESTAMP() AS inserted_date, NULL AS updated_date, 1 AS current_indicator
        FROM changes;
    `;

    // Compile all SQL parts into a single string
    const fullSQL = `${insertNewSQL}\n${changesSQL}\n${retireOldSQL}\n${insertUpdatedSQL}`;
    return fullSQL;
}

module.exports = {
    generateSCD2SQL
};
