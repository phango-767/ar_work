function generateColumnsMetadata(dataset, sourceTableName) {
    
    const column_names = `
-- Declare a variable to store an array of column names
DECLARE column_names ARRAY<STRING>;

-- Populate the column_names variable with the names of all columns from the specified table
SET column_names = (
  SELECT ARRAY_AGG(column_name)
  FROM \`${dataset}\`.INFORMATION_SCHEMA.COLUMNS
  WHERE table_name = '${sourceTableName}'
);

SELECT ARRAY_TO_STRING(column_names, ', ') AS column_names;
`;

    return column_names;
}