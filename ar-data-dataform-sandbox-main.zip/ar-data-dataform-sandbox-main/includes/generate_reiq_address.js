function reiqaddressSQLTable(tableRef, address1, address2, suburb, state, postcode, uniqueID) {
  return `        
WITH AddressParts AS (
  SELECT
    ${uniqueID},
    ARRAY_CONCAT(
      CASE WHEN LENGTH(TRIM(${address1})) > 0 THEN [TRIM(${address1})] ELSE [] END,
      CASE WHEN LENGTH(TRIM(${address2})) > 0 THEN [TRIM(${address2})] ELSE [] END,
      CASE WHEN LENGTH(TRIM(${suburb})) > 0 THEN [TRIM(${suburb})] ELSE [] END,
      [CONCAT(COALESCE(${state}, 'QLD'), ' ', TRIM(CAST(FLOOR(${postcode}) AS STRING)))]
    ) AS address_parts

    ,${address1}
    ,${address2}
    ,${suburb}
    ,${state}
    ,${postcode}

FROM  ${tableRef} 
)

SELECT
  id
  ,CASE 
    WHEN TRIM(ARRAY_TO_STRING(address_parts, ', ')) = ''
    THEN NULL
    ELSE ARRAY_TO_STRING(address_parts, ', ') 
    END AS full_address
    ,${address1}
    ,${address2}
    ,${suburb}
    ,${state}
    ,${postcode}
FROM
  AddressParts 
  `;
}

  module.exports = {
                    reiqaddressSQLTable 
                    };
