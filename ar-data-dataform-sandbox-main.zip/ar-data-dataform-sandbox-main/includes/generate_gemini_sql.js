function generateSQL(sourceSchema, sourceTable, uniqueField, descriptionField, promptPrefix, model) {
  const sql = `

SELECT
  ${uniqueField},
  ml_generate_text_llm_result AS Gemini_Response,
  prompt AS Prompt
FROM ML.GENERATE_TEXT(
  MODEL ${model},
  (
    SELECT
      t.${uniqueField},
      t.${descriptionField},
      CONCAT(
        '${promptPrefix}',
        SUBSTRING(t.${descriptionField}, 0, 200)
      ) AS prompt
    FROM ${sourceSchema}.${sourceTable} t
  ),
  STRUCT(
    TRUE AS flatten_json_output
  )
)`;

  return sql.trim();
};

module.exports = { 
    generateSQL
};