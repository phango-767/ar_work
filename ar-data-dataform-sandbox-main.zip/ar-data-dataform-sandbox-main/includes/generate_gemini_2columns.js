function generateTermSQL(sourceSchema, sourceTable, idField, commencementDateField, termField, furtherTermField, promptPrefix, model) {
  const sql = `
SELECT
  ${idField},
  ${commencementDateField},
  ${termField},
  ${furtherTermField},
  ml_generate_text_llm_result AS Gemini_Response
FROM ML.GENERATE_TEXT(
  MODEL ${model},
  (
    SELECT
      t.${idField},
      t.${commencementDateField},
      t.${termField},
      t.${furtherTermField},
      CONCAT(
        '${promptPrefix}',
        'Commencement Date: ', t.${commencementDateField}, '\\n',
        'Term: ', IFNULL(t.${termField}, t.${furtherTermField}), '\\n'
      ) AS prompt
    FROM ${sourceSchema}.${sourceTable} t
  ),
  STRUCT(
    TRUE AS flatten_json_output
  )
)`;

  return sql.trim();
}

module.exports = {
  generateTermSQL
};