function loadNDJsonTableSQL(
    dataset,
    tableName,
    format,
    folderPath,
    fileName,
    options = {}
) {
    // Construct the URI without appending the format as an extension
    const uri = `gs://${folderPath}/${fileName}`;

    // Start the SQL statement
    let sql = `
CREATE OR REPLACE EXTERNAL TABLE \`${dataset}.${tableName}\`
OPTIONS (
    format = '${format}',
    uris = ['${uri}']`;

    // Handle format-specific options
    if (format.toLowerCase() === 'csv') {
        const csvOptions = {
            skipLeadingRows: options.skipLeadingRows !== undefined ? options.skipLeadingRows : 1,
            allowQuotedNewlines: options.allowQuotedNewlines !== undefined ? options.allowQuotedNewlines : true,
            allowJaggedRows: options.allowJaggedRows !== undefined ? options.allowJaggedRows : true
        };

        sql += `,
    skip_leading_rows = ${csvOptions.skipLeadingRows},
    allow_quoted_newlines = ${csvOptions.allowQuotedNewlines ? 'TRUE' : 'FALSE'},
    allow_jagged_rows = ${csvOptions.allowJaggedRows ? 'TRUE' : 'FALSE'}`;
    } else if (format.toLowerCase() === 'json' || format.toLowerCase() === 'newline_delimited_json') {
        // JSON-specific options can be added here if needed
    }

    // Close the SQL statement
    sql += `
)`;

    return sql;
}

module.exports = {
    loadNDJsonTableSQL
};
