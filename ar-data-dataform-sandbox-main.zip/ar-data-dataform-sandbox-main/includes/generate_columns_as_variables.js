const filter900 = [
  "'string_field_0'", "'string_field_2'", "'string_field_3'", "'string_field_76'", "'string_field_78'", "'string_field_75'", 
  "'string_field_72'", "'string_field_73'", "'string_field_71'", "'string_field_68'", "'string_field_59'", "'string_field_61'", 
  "'string_field_19'", "'string_field_12'", "'string_field_222'", "'string_field_94'", "'string_field_56'", "'string_field_57'", 
  "'string_field_97'", "'string_field_74'", "'string_field_89'", "'string_field_88'", "'string_field_116'", "'string_field_60'", 
  "'string_field_105'", "'string_field_110'", "'string_field_102'", "'string_field_111'", "'string_field_188'", "'string_field_107'", 
  "'string_field_117'", "'string_field_106'", "'string_field_67'", "'string_field_129'", "'string_field_137'", "'string_field_114'", 
  "'string_field_115'", "'string_field_10'", "'string_field_120'", "'string_field_223'", "'string_field_268'", "'string_field_17'", 
  "'string_field_69'", "'string_field_8'", "'string_field_79'", "'string_field_109'"
];

const filter910 = [
  "'string_field_0'", "'string_field_2'", "'string_field_3'", "'string_field_104'", "'string_field_103'", "'string_field_105'", 
  "'string_field_108'", "'string_field_107'", "'string_field_109'", "'string_field_95'", "'string_field_96'", "'string_field_97'", 
  "'string_field_88'", "'string_field_119'", "'string_field_481'", "'string_field_91'", "'string_field_125'", "'string_field_94'", 
  "'string_field_100'", "'string_field_98'", "'string_field_80'", "'string_field_81'", "'string_field_115'", "'string_field_79'", 
  "'string_field_114'", "'string_field_23'", "'string_field_20'", "'string_field_21'", "'string_field_251'", "'string_field_258'", 
  "'string_field_252'", "'string_field_113'", "'string_field_86'", "'string_field_117'", "'string_field_127'", "'string_field_17'", 
  "'string_field_11'", "'string_field_121'", "'string_field_254'", "'string_field_16'", "'string_field_15'", "'string_field_78'", 
  "'string_field_90'", "'string_field_8'", "'string_field_106'", "'string_field_22'"
];



function renderScript(tableName,leasecolumns,leaseoriginal,filter) {
    return `
    DECLARE sql_query STRING DEFAULT "CREATE OR REPLACE TABLE \`${tableName}\` AS SELECT ";
    DECLARE i INT64 DEFAULT 0;

    -- Loop through the old and new column names
    FOR row IN (
      SELECT 
        REPLACE(REPLACE(REPLACE(REPLACE(col_name, ' ', ''), '(', ''), ')', ''), '.', '') AS old_name,  
        REPLACE(REPLACE(REPLACE(REPLACE(col_value, ' ', ''), '(', ''), ')', ''), '.', '') AS new_name   
      FROM ${(leasecolumns)}
  WHERE col_name IN ( ${(filter)} )
    ORDER BY col_value
    )
    DO
      -- Append each column rename to the SQL query with backticks and index suffix
      SET sql_query = sql_query || "\`" || row.old_name ||  "\` AS \`" || row.new_name || "_" || i ||  "\`,\\n";  
      SET i = i + 1;
    END FOR;

    -- Remove the last comma and newline, then add the FROM clause
    SET sql_query = CONCAT(SUBSTR(sql_query, 1, LENGTH(sql_query) - 2), " FROM ${(leaseoriginal)};");

    -- Execute the dynamic SQL query
    EXECUTE IMMEDIATE sql_query;

    DELETE FROM \`ar-sandbox-data-lakehouse.reinsw_trusted_leases.leases_900_renamed\` 
    WHERE LOWER(TRIM(form_id_43)) = "form_id" AND LOWER(TRIM(created_42)) = "created" 
    AND LOWER(TRIM(updated_45)) = "updated" AND LOWER(TRIM(Bond_Amount_0)) = "bond_amount" 
    AND LOWER(TRIM(Outgoings_Checkbox_2)) = "outgoings_checkbox" AND LOWER(TRIM(Option_Term_Renewal_1)) = "option_term_renewal" 
    AND LOWER(TRIM(postcode_44)) = "postcode"
  `;
}

module.exports = {
    renderScript, filter900, filter910,
};
