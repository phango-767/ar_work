const addressFunction = "`ar-sandbox-data-lakehouse.ar_raw_firebase.FullAddress`"
function parseaddressSQLTable(tableRef, addressColumn, uidcolumn, addressFunction) {
  return `
    WITH ParsedAddressesCTE AS (
      SELECT 
        ${uidcolumn} as id,
        ${addressColumn} as raw_address,
        ${addressFunction}(${addressColumn}) AS full_address
      FROM
        ${tableRef}
    )
    
    SELECT
      id,
      raw_address,
      full_address,
      JSON_EXTRACT_SCALAR(full_address, '$.formatted_address') AS formatted_address,
      JSON_EXTRACT_SCALAR(full_address, '$.unit') AS unit,
      JSON_EXTRACT_SCALAR(full_address, '$.street_number') AS street_number,
      JSON_EXTRACT_SCALAR(full_address, '$.street_name') AS street_name,
      JSON_EXTRACT_SCALAR(full_address, '$.suburb') AS suburb,
      JSON_EXTRACT_SCALAR(full_address, '$.postal_code') AS postal_code,
      JSON_EXTRACT_SCALAR(full_address, '$.latitude') AS latitude,
      JSON_EXTRACT_SCALAR(full_address, '$.longitude') AS longitude
    FROM
      ParsedAddressesCTE
  `;
}

module.exports = { parseaddressSQLTable,addressFunction };
